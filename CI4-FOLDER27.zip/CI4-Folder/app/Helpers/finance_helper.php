<?php

function formatINR($amount)
{
    return '₹'.number_format($amount,0,'.',',');
}

function calculateDue($fee, $paid)
{
    return $fee - $paid;
}

// For remaining due for a student across all payments
function getRemainingDue($studentId)
{
    $db = \Config\Database::connect();
    $builder = $db->table('student_fees');
    $row = $builder
        ->select('SUM(fee_amount) as total_fee, SUM(paid_amount) as total_paid')
        ->where('student_id',$studentId)
        ->get()->getRow();

    return $row ? ($row->total_fee - $row->total_paid) : 0;
}

function generateReceiptNo($studentId)
{
    
     return 'REC-'.date('Y').'-'.str_pad($studentId,4,'0',STR_PAD_LEFT);
}
