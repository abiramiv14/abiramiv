<!DOCTYPE html>
<html>
<head>
    <title>Apply Leave</title>
</head>
<body>

<h2>Apply Leave</h2>

<form method="post" action="<?= base_url('leave/store') ?>">
    <label>Leave Type</label><br>
    <select name="type" required>
        <option value="casual">Casual</option>
        <option value="medical">Medical</option>
        <option value="earned">Earned</option>
    </select><br><br>

    <label>From Date</label><br>
    <input type="date" name="from_date" required><br><br>

    <label>To Date</label><br>
    <input type="date" name="to_date" required><br><br>

    <button type="submit">Submit</button>
</form>

<a href="<?= base_url('leave') ?>">Back</a>

</body>
</html>
