<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold text-dark">Add New Course</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="/admin/dashboard" class="text-muted text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="/admin/courses" class="text-muted text-decoration-none">Courses</a></li>
                <li class="breadcrumb-item active" aria-current="page">Add New</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                
                <?php if(session()->getFlashdata('errors')): ?>
                    <div class="alert alert-danger border-0 bg-danger bg-opacity-10 text-danger mb-4">
                        <i class="bi bi-exclamation-octagon-fill me-2"></i> 
                        <?php foreach(session()->getFlashdata('errors') as $error) echo $error.'<br>'; ?>
                    </div>
                <?php endif; ?>

                <form id="courseform" action="/admin/courses/store" method="POST">
                    
                    <div class="row g-3">
                        <!-- Course Code -->
                        <div class="col-md-6">
                            <label class="form-label text-muted small fw-bold">COURSE CODE</label>
                            <input type="text" name="course_code" id="code" class="form-control" 
                                   placeholder="e.g. CS101" required value="<?= old('course_code') ?>" autofocus>
                            <small class="text-muted" style="font-size: 0.75rem;">Format: ABC123</small>
                        </div>

                        <!-- Credits -->
                        <div class="col-md-6">
                            <label class="form-label text-muted small fw-bold">CREDITS</label>
                            <select name="credits" class="form-control" required>
                                <option value="">Select Credits</option>
                                <?php for($i=1;$i<=10;$i++): ?>
                                    <option value="<?= $i ?>" <?= old('credits')==$i?'selected':'' ?>><?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <!-- Course Name -->
                        <div class="col-12">
                            <label class="form-label text-muted small fw-bold">COURSE NAME</label>
                            <input type="text" name="course_name" class="form-control name" placeholder="Course Title" required value="<?= old('course_name') ?>">
                        </div>

                        <!-- Department -->
                        <div class="col-md-6">
                            <label class="form-label text-muted small fw-bold">DEPARTMENT</label>
                            <select name="department" class="form-control" required>
                                <option value="">Select Department</option>
                                <?php 
                                $departments = ['ECE','EEE','MECH','CSE','CIVIL'];
                                foreach($departments as $dept):
                                ?>
                                    <option value="<?= $dept ?>" <?= old('department')==$dept?'selected':'' ?>><?= $dept ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Semester -->
                        <div class="col-md-6">
                            <label class="form-label text-muted small fw-bold">SEMESTER</label>
                            <select name="semester" class="form-control" required>
                                <option value="">Select Semester</option>
                                <?php for($i=1;$i<=8;$i++): ?>
                                    <option value="<?= $i ?>" <?= old('semester')==$i?'selected':'' ?>><?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <!-- Buttons -->
                        <div class="col-12 mt-4 text-end">
                            <a href="/admin/courses" class="btn btn-light border me-2">Cancel</a>
                            <button type="submit" class="btn btn-primary px-4">Save Course</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- JS Validation and Focus -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
 $(document).ready(function () {
    $("#code").focus();
    $("#code").on("input", function () {
        let value = $(this).val().replace(/[^a-zA-Z0-9]/g, "").substring(0, 6);
        if (value.length <= 3) value = value.replace(/[^a-zA-Z]/g, "");
        else { let first = value.substring(0, 3).replace(/[^a-zA-Z]/g, ""); let second = value.substring(3).replace(/[^0-9]/g, ""); value = first + second; }
        $(this).val(value.toUpperCase());
    });
    $(".name").on("input", function () {
        let value = $(this).val().replace(/[^a-zA-Z ]/g, "").substring(0, 30);
        $(this).val(value);
    });
});
</script>

<?= $this->endSection() ?>