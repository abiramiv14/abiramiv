<h2>Edit Course Allocation</h2>

<?php if(session()->getFlashdata('success')): ?>
<p style="color:green"><?= session()->getFlashdata('success') ?></p>
<?php endif; ?>
<?php if(session()->getFlashdata('error')): ?>
<p style="color:red"><?= session()->getFlashdata('error') ?></p>
<?php endif; ?>

<form method="post" action="<?= base_url('allocations/update/'.$allocation['id']) ?>">
    <?= csrf_field() ?>

    <label>Course:</label><br>
    <select name="course_id" required>
        <?php foreach($courses as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $allocation['course_id']==$c['id'] ? 'selected' : '' ?>>
                <?= $c['course_code'] ?> - <?= $c['course_name'] ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Faculty:</label><br>
    <select name="faculty_id" required>
        <?php foreach($faculties as $f): ?>
            <option value="<?= $f['id'] ?>" <?= $allocation['faculty_id']==$f['id'] ? 'selected' : '' ?>>
                <?= $f['user_id'] ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Semester:</label><br>
    <select name="semester" required>
        <?php for($i=1; $i<=8; $i++): ?>
            <option value="<?= $i ?>" <?= $allocation['semester']==$i ? 'selected' : '' ?>><?= $i ?></option>
        <?php endfor; ?>
    </select><br><br>

    <button type="submit">Update Allocation</button>
</form>
