<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<div class="container mt-4">

<h2>Product Management</h2>

<div class="mb-3">
    <input type="text" id="search" placeholder="Search by name/code">
    <select id="filterStatus">
        <option value="All">All Status</option>
        <option value="Active">Active</option>
        <option value="Inactive">Inactive</option>
    </select>
    <button id="searchBtn" class="btn btn-primary btn-sm">Search</button>
</div>

<div class="mb-2">
    <select id="bulkActionSelect">
        <option value="">Bulk Action</option>
        <option value="delete">Delete</option>
        <option value="restore">Restore</option>
        <option value="activate">Activate</option>
        <option value="deactivate">Deactivate</option>
    </select>
    <button id="applyBulk" class="btn btn-secondary btn-sm">Apply</button>
</div>
<a href="/products/create" class="btn btn-primary mb-3">
    ➕ Add Product
</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th><input type="checkbox" id="checkAll"></th>
            <th>Code</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($products as $p): ?>
        <tr id="row-<?= $p['id'] ?>">
            <td><input type="checkbox" class="rowCheck" value="<?= $p['id'] ?>"></td>
            <td contenteditable="true" class="inline-edit" data-id="<?= $p['id'] ?>" data-field="product_code"><?= $p['product_code'] ?></td>
            <td contenteditable="true" class="inline-edit" data-id="<?= $p['id'] ?>" data-field="product_name"><?= $p['product_name'] ?></td>
            <td contenteditable="true" class="inline-edit" data-id="<?= $p['id'] ?>" data-field="category"><?= $p['category'] ?></td>
            <td contenteditable="true" class="inline-edit" data-id="<?= $p['id'] ?>" data-field="price"><?= $p['price'] ?></td>
            <td contenteditable="true" class="inline-edit" data-id="<?= $p['id'] ?>" data-field="stock"><?= $p['stock'] ?></td>
            <td>
                <div class="form-check form-switch">
                    <input type="checkbox" class="form-check-input toggle-status" data-id="<?= $p['id'] ?>" <?= $p['status']=='Active'?'checked':'' ?>>
                </div>
            </td>
            <td>
                <button class="btn btn-danger btn-sm delete-btn" data-id="<?= $p['id'] ?>">Delete</button>
                <button class="btn btn-success btn-sm restore-btn" data-id="<?= $p['id'] ?>">Restore</button>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>

<script>
$(document).ready(function(){

    // Inline edit
    $('.inline-edit').blur(function(){
        var id = $(this).data('id');
        var field = $(this).data('field');
        var value = $(this).text();

        $.post('/products/inlineEdit', {id:id, field:field, value:value}, function(res){
            if(!res.success) alert('Error saving data');
        }, 'json');
    });

    // Toggle status
    $('.toggle-status').change(function(){
        var id = $(this).data('id');
        $.get('/products/toggleStatus/'+id, function(res){
            if(!res.success) alert('Error updating status');
        }, 'json');
    });

    // Delete
    $('.delete-btn').click(function(){
        var id = $(this).data('id');
        if(confirm('Delete product?')){
            $.get('/products/delete/'+id, function(res){
                if(res.success) $('#row-'+id).fadeOut();
            }, 'json');
        }
    });

    // Restore
    $('.restore-btn').click(function(){
        var id = $(this).data('id');
        $.get('/products/restore/'+id, function(res){
            if(res.success) location.reload();
        }, 'json');
    });

    // Bulk actions
    $('#checkAll').click(function(){
        $('.rowCheck').prop('checked', this.checked);
    });

    $('#applyBulk').click(function(){
        var ids = $('.rowCheck:checked').map(function(){ return this.value; }).get();
        var action = $('#bulkActionSelect').val();
        if(!action || ids.length==0){ alert('Select action and rows'); return; }

        $.post('/products/bulkAction', {action:action, ids:ids}, function(res){
            if(res.success) location.reload();
        }, 'json');
    });

    // Search / filter
    $('#searchBtn').click(function(){
        var search = $('#search').val();
        var status = $('#filterStatus').val();
        window.location.href = '/products?search='+search+'&status='+status;
    });

});
</script>
