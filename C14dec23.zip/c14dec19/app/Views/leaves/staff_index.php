<!DOCTYPE html>
<html>
<head>
    <title>My Leave Requests</title>
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <!-- Optional: DataTables Responsive CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">

    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        header {
            background-color: #2c3e50;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .profile-dropdown {
            position: relative;
            display: inline-block;
        }
        .profile-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: #fff;
            min-width: 120px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .profile-dropdown-content a {
            color: #333;
            padding: 8px 12px;
            text-decoration: none;
            display: block;
        }
        .profile-dropdown-content a:hover { background-color: #f2f2f2; }
        .profile-dropdown:hover .profile-dropdown-content { display: block; }

        table.dataTable tbody tr td { text-align: center; }
        .pending { color: orange; font-weight: bold; }
        .approved { color: green; font-weight: bold; }
        .rejected { color: red; font-weight: bold; }
        .disabled { color: gray; pointer-events: none; }
    </style>
</head>
<body>

<header>
    <div>
        <h3>College ERP - Leave Management</h3>
    </div>
    <div class="profile-dropdown">
        <?= session()->get('username') ?> (<?= session()->get('role') ?>)
        <div class="profile-dropdown-content">
            <a href="<?= base_url('logout') ?>">Logout</a>
        </div>
    </div>
</header>

<div style="padding: 20px;">
    <h2>My Leave Requests</h2>
    <a href="<?= base_url('leave/create') ?>" style="margin-bottom: 10px; display:inline-block;">Apply Leave</a>

    <table id="leaveTable" class="display responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>S.No</th>
                <th>Leave Type</th>
                <th>From</th>
                <th>To</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($myLeaves)): ?>
                <?php $i = 1; foreach ($myLeaves as $leave): ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td><?= esc($leave['type']) ?></td>
                    <td><?= esc($leave['from_date']) ?></td>
                    <td><?= esc($leave['to_date']) ?></td>
                    <td class="<?= esc($leave['status']) ?>"><?= ucfirst($leave['status']) ?></td>
                    <td>
                        <?php if ($leave['status'] == 'pending'): ?>
                            <a href="<?= site_url('leave/edit/'.$leave['id']) ?>">Edit</a> |
                            <a href="<?= site_url('leave/delete/'.$leave['id']) ?>" onclick="return confirm('Delete this leave?')">Delete</a>
                        <?php else: ?>
                            <span class="disabled">Edit</span> |
                            <span class="disabled">Delete</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>

<script>
$(document).ready(function() {
    $('#leaveTable').DataTable({
        responsive: true,
        pageLength: 10,
        order: [[ 0, 'asc' ]]
    });
});
</script>

</body>
</html>
