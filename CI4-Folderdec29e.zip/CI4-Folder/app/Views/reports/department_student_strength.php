<!DOCTYPE html>
<html>
<head>
    <title>Department-wise Student Strength</title>
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
</head>
<body>

<h2>Department-wise Student Strength</h2>
<div id="chartdiv1" style="width: 100%; height: 500px;"></div>

<script>
am5.ready(function() {

    var root = am5.Root.new("chartdiv1");
    root.setThemes([ am5themes_Animated.new(root) ]);
root._logo.dispose();
root.logo=null;
    var chart = root.container.children.push(
        am5xy.XYChart.new(root, {
            panX: false,
            panY: false,
            wheelX: "none",
            wheelY: "none"
        })
    );

    // Cursor for tooltip
    chart.set("cursor", am5xy.XYCursor.new(root, {}));

    // X-axis → Department
    var xAxis = chart.xAxes.push(
        am5xy.CategoryAxis.new(root, {
            categoryField: "department",
            renderer: am5xy.AxisRendererX.new(root, { minGridDistance: 30 })
        })
    );
    xAxis.children.push(am5.Label.new(root, {
        text: "Department Name",
        x: am5.p50,
        centerX: am5.p50,
        paddingTop: 10
    }));

    // Y-axis → Student Count
    var yAxis = chart.yAxes.push(
        am5xy.ValueAxis.new(root, { renderer: am5xy.AxisRendererY.new(root, {}) })
    );
    yAxis.children.push(am5.Label.new(root, {
        text: "Number of Students",
        rotation: -90,
        y: am5.p50,
        centerY: am5.p50
    }));

    // Column series
    var series = chart.series.push(
        am5xy.ColumnSeries.new(root, {
            name: "Students",
            xAxis: xAxis,
            yAxis: yAxis,
            valueYField: "count",
            categoryXField: "department",
            tooltip: am5.Tooltip.new(root, {
                labelText: "{categoryX}: {valueY}"
            })
        })
    );

    series.columns.template.setAll({
        cornerRadiusTL: 5,
        cornerRadiusTR: 5,
        tooltipText: "{categoryX}: {valueY}",
        interactive: true
    });

    // PHP → JS data
    var data = [
        <?php foreach($chartData as $row){ ?>
        { department: "<?= $row['department_name'] ?>", count: <?= $row['total'] ?> },
        <?php } ?>
    ];

    xAxis.data.setAll(data);
    series.data.setAll(data);

    series.appear(1000);
    chart.appear(1000, 100);
});
</script>

</body>
</html>
