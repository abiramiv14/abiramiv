<!DOCTYPE html>
<html>
<head>
    <title>Incident List</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:95%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#dc3545; color:#fff; }
        .editing-row { background-color: #fff3cd !important; }
        .edit-field { width:100%; padding:3px; display:none; }
        .action-btn { cursor:pointer; border:none; background:none; }
    </style>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
</head>
<body>

<h2 style="text-align:center;">Incident Reports</h2>
<div style="width:80%; margin:20px auto; text-align:right;">
    <a href="<?= base_url('/incidents/add') ?>" style="padding:10px 15px; background:#28a745; color:#fff; text-decoration:none; border-radius:4px;">
        + Add Incident
    </a>
</div>

<table id="incidentTable">
    <thead>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Description</th>
        <th>Department</th>
        <th>Priority</th>
        <th>Date</th>
        <th>Actions</th>
    </tr>
    </thead>
    <tbody>
<?php foreach ($incidents as $row): ?>
<tr data-id="<?= $row['incident_id'] ?>">
    <td><?= $row['incident_id'] ?></td>

    <td><span class="text"><?= $row['title'] ?></span>
        <input type="text" name="title" class="edit-field" value="<?= $row['title'] ?>"></td>

    <td><span class="text"><?= $row['description'] ?></span>
        <input type="text" name="description" class="edit-field" value="<?= $row['description'] ?>"></td>

    <td><span class="text"><?= $row['department'] ?></span>
        <input type="text" name="department" class="edit-field" value="<?= $row['department'] ?>"></td>

    <td><span class="text"><?= $row['priority'] ?></span>
        <input type="text" name="priority" class="edit-field" value="<?= $row['priority'] ?>"></td>

    <td><span class="text"><?= $row['incident_date'] ?></span>
        <input type="text" name="incident_date" class="edit-field" value="<?= $row['incident_date'] ?>"></td>

    <td>
        <button class="action-btn edit-btn"><i class="fa fa-pen" style="color:blue;"></i></button>
        <button class="action-btn save-btn" style="display:none;"><i class="fa fa-check" style="color:green;"></i></button>
        <button class="action-btn cancel-btn" style="display:none;"><i class="fa fa-times" style="color:orange;"></i></button>
        <a href="<?= base_url('incidents/delete/'.$row['incident_id']) ?>" onclick="return confirm('Delete this incident?')">
            <i class="fa fa-trash" style="color:red;"></i>
        </a>
    </td>
</tr>
<?php endforeach; ?>
    </tbody>
</table>

<script>
$(document).ready(function(){
    $('#incidentTable').DataTable();

    // Edit
    $(document).on('click', '.edit-btn', function(){
        let row = $(this).closest('tr');
        row.addClass('editing-row');
        row.find('.text').hide();
        row.find('.edit-field').show();
        row.find('.edit-btn').hide();
        row.find('.save-btn, .cancel-btn').show();
    });

    // Cancel
    $(document).on('click', '.cancel-btn', function(){
        let row = $(this).closest('tr');
        row.removeClass('editing-row');
        row.find('.edit-field').each(function(){
            $(this).val($(this).siblings('.text').text());
        });
        row.find('.edit-field').hide();
        row.find('.text').show();
        row.find('.edit-btn').show();
        row.find('.save-btn, .cancel-btn').hide();
    });

    // Save
    $(document).on('click', '.save-btn', function(){
        let row = $(this).closest('tr');
        let id = row.data('id');
        let data = {};
        row.find('.edit-field').each(function(){
            data[$(this).attr('name')] = $(this).val();
        });

        // AJAX POST request to update
        $.post("<?= base_url('incidents/update') ?>/"+id, data, function(response){
            row.find('.edit-field').each(function(){
                $(this).siblings('.text').text($(this).val());
            });
            row.removeClass('editing-row');
            row.find('.edit-field').hide();
            row.find('.text').show();
            row.find('.edit-btn').show();
            row.find('.save-btn, .cancel-btn').hide();
        });
    });
});
</script>

</body>
</html>
