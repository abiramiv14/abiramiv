<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>

    <style>
        body {
            font-family: Arial;
            background: #f4f4f4;
        }

        form {
            width: 400px;
            margin: 40px auto;
            padding: 25px;
            background: #fff;
            border-radius: 5px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 12px;
            box-sizing: border-box;
        }

        button {
            padding: 10px;
            width: 100%;
            background: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .error {
            color: red;
            font-size: 13px;
        }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Validation JS -->
    <script src="<?= base_url('assets/js/student.js') ?>"></script>
</head>

<body>

<form id="studentForm" method="post" action="<?= base_url('/students/save') ?>" novalidate>
    <h2>Student Registration</h2>

    <input type="text" name="student_name" id="student_name" placeholder="Student Name">
    <input type="email" name="email" id="email" placeholder="Email">
    <input type="text" name="phone" id="phone" placeholder="Phone">
    <input type="text" name="course" id="course" placeholder="Course">
    <input type="text" name="city" id="city" placeholder="City">

    <button type="submit">Register</button>
</form>

</body>
</html>
