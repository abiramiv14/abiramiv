<?php
namespace App\Models\task1;
use CodeIgniter\Model;
class CourseModel extends Model
{
    protected $table="course_registrations";
    protected $primaryKey= "course_id";
    protected $allowedFields = [
        'student_name',
        'course_name',
        'semester',
        'fees',
        'email'
    ];
}
