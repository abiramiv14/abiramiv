<!DOCTYPE html>
<html>
<head>
    <title>Upload Students Excel</title>
    <style>
        body { font-family: Arial; background: #f4f6f8; }
        .container {
            width: 500px;
            margin: 100px auto;
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            text-align: center;
        }
        button {
            background:#007bff;
            color:#fff;
            padding:10px 20px;
            border:none;
            border-radius:4px;
            cursor:pointer;
        }
        .error { color:red; margin-bottom:10px; }
    </style>

    <!-- XLSX JS LIB -->
    <script src="https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js"></script>
</head>
<body>

<div class="container">
    <h2>Upload Students (.xlsx)</h2>

    <?php if(session()->getFlashdata('error')): ?>
        <div class="error"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <form id="uploadForm" method="post" action="<?= base_url('student/upload') ?>" enctype="multipart/form-data">
        <!-- Hidden CSV file input -->
        <input type="hidden" name="original_xlsx" id="original_xlsx">
        <input type="file" id="excelFile" accept=".xlsx" required>
        <br><br>
        <button type="button" onclick="convertUpload()">Upload</button>
    </form>
</div>

<script>
function convertUpload() {
    const fileInput = document.getElementById('excelFile');
    const file = fileInput.files[0];
    if (!file) { alert("Select a file"); return; }

    // Save original XLSX filename
    document.getElementById('original_xlsx').value = file.name;

    // Convert XLSX to CSV
    const reader = new FileReader();
    reader.onload = function(e) {
        const data = new Uint8Array(e.target.result);
        const wb = XLSX.read(data, {type:'array'});
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const csv = XLSX.utils.sheet_to_csv(sheet);

        // Create CSV blob and append as file input
        const blob = new Blob([csv], {type:'text/csv'});
        const csvFile = new File([blob], "students.csv", {type:'text/csv'});

        const dt = new DataTransfer();
        dt.items.add(csvFile);

        const input = document.createElement('input');
        input.type = 'file';
        input.name = 'csv_file';
        input.files = dt.files;

        document.getElementById('uploadForm').appendChild(input);
        document.getElementById('uploadForm').submit();
    };
    reader.readAsArrayBuffer(file);
}
</script>

</body>
</html>
