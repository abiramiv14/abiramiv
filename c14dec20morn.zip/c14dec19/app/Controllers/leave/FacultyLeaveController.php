<?php
namespace App\Controllers\leave;

use CodeIgniter\Controller;
use App\Models\leave\FacultyModel;
use App\Models\leave\DatasModel;
use App\Models\leave\Usermodel;

class FacultyLeaveController extends Controller
{
    protected $facultyModel;
    protected $datasModel;
    protected $userModel;

    public function __construct() {
        $this->facultyModel = new FacultyModel();
        $this->datasModel = new DatasModel();
        $this->userModel = new Usermodel();
    }

    // List all leaves for staff
    public function index() {
        $userId = session()->get('id');
       $data['myLeaves'] = $this->facultyModel->where('facul_name', $userId)->groupBy('id')->findAll();

        return view('leaves/staff_index', $data);
    }

    // Show create leave form
    public function create() {
        return view('leaves/staff_create');
    }

    // Store new leave
    public function store() {
        $userId = session()->get('id');
        $deptName = session()->get('dept_name');

        // Get HOD id of the department
        $hod = $this->userModel->where('role', 'hod')->where('dept_name', $deptName)->first();
        $hodId = $hod ? $hod['id'] : null;

        // Insert into 'datas' table
        $dataId = $this->datasModel->insert([
            'from_id' => $userId,
            'to_id'   => $hodId
        ], true); // true returns inserted ID

        // Insert into 'faculty' table
        $this->facultyModel->insert([
            'facul_name' => $userId,
            'dept_name'  => $deptName,
            'type'       => $this->request->getPost('type'),
            'from_date'  => $this->request->getPost('from_date'),
            'to_date'    => $this->request->getPost('to_date'),
            'status'     => 'pending',
            
            'data_id'    => $dataId
        ]);

        return redirect()->to('leave');
    }

    // Show edit form
    public function edit($id) {
        $leave = $this->facultyModel->find($id);
        if(!$leave || $leave['status'] != 'pending') {
            return redirect()->to('leave');
        }
        $data['leave'] = $leave;
        return view('leaves/staff_edit', $data);
    }

    // Update leave
    public function update($id) {
        $leave = $this->facultyModel->find($id);
        if(!$leave || $leave['status'] != 'pending') {
            return redirect()->to('leave');
        }

        $this->facultyModel->update($id, [
            'type'      => $this->request->getPost('type'),
            'from_date' => $this->request->getPost('from_date'),
            'to_date'   => $this->request->getPost('to_date')
        ]);

        return redirect()->to('leave');
    }

    // Delete leave
    public function delete($id) {
        $leave = $this->facultyModel->find($id);
        if(!$leave || $leave['status'] != 'pending') {
            return redirect()->to('leave');
        }

        // Optional: also delete linked 'datas' row
        if(isset($leave['data_id'])) {
            $this->datasModel->delete($leave['data_id']);
        }

        $this->facultyModel->delete($id);
        return redirect()->to('leave');
    }
}
