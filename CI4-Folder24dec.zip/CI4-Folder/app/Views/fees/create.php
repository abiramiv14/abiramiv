<h2>Add Payment</h2>
<form method="post" action="<?= base_url('fees/store') ?>">
    <label>Student:</label>
    <select name="student_id">
        <?php foreach($students as $s): ?>
            <option value="<?= $s['id'] ?>"><?= $s['name'] ?></option>
        <?php endforeach; ?>
    </select><br>
    <label>Semester:</label>
    <input type="text" name="semester"><br>
    <label>Total Fee:</label>
    <input type="number" name="fee_amount"><br>
    <label>Paid Amount:</label>
    <input type="number" name="paid_amount"><br>
    <label>Payment Mode:</label>
    <select name="payment_mode">
        <option value="Cash">Cash</option>
        <option value="UPI">UPI</option>
        <option value="Bank">Bank</option>
    </select><br>
    <label>Payment Date:</label>
    <input type="date" name="payment_date"><br>
    <button type="submit">Submit</button>
</form>
