<h2>Tickets</h2>
<a href="/tickets/create">Create Ticket</a>
<table border="1">
<tr>
    <th>ID</th><th>Raised By</th><th>Issue</th><th>Description</th><th>Status</th><th>Action</th>
</tr>
<?php foreach($tickets as $t){ ?>
<tr>
    <td><?= $t['id'] ?></td>
    <td><?= $t['raised_by'] ?></td>
    <td><?= $t['issue_type'] ?></td>
    <td><?= $t['description'] ?></td>
    <td><?= $t['status'] ?></td>
    <td>
        <a href="/tickets/edit/<?= $t['id'] ?>">Edit</a>
        <a href="/tickets/delete/<?= $t['id'] ?>">Delete</a>
    </td>
</tr>
<?php } ?>
</table>
