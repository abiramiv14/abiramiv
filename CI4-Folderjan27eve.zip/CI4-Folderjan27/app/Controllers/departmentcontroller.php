<?php
namespace App\controllers;

use App\Controllers\BaseController;
use App\Models\departmentmodel;
use codeigniter\Model;

class departmentcontroller extends BaseController{
    public function index(){
        $Model= new departmentmodel();
        $data['departments']=$Model->orderby('id','DESC')
                                   ->findall();
                return view('department/list',$data);

    }
    public function save(){
        $model=new departmentmodel();
        $rules = [
            'dept_code'=>'required|dept_code|[departments.dept_code]',
            'dept-name'=>'required'
        ];
        if(!$this->validate($rules)){
            return redirect()->back()->withinput();
        }
        $model->insert([
            'dept_code'=>$this->request->getpost('dept_code'),
            'dept_name'=>$this->request->getpost('dept_name'),
            'status'=>'Active'
              ]);
            return redirect()->to('/department');
    }
        public function edit($id){
            $model= new departmentmodel();
            $data['dept']= $model->find($id);
            return view('/department/edit',$data);
        }
        public function update($id){
            $model=new department model();
            'dept_name'=>$this->request->getpost('dept-name');
            'status'=>$this->request->getpost('status')
        }
            
        
    }

