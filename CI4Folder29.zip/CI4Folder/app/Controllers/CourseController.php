<?php namespace App\Controllers;

use App\Models\CourseModel;

class CourseController extends BaseController
{
    protected $courseModel;

    public function __construct()
    {
        $this->courseModel = new CourseModel();
    }

    // List courses
    public function index()
    {
        $data['courses'] = $this->courseModel->getCourses();
        echo view('courses/index', $data);
    }

    // Create course form
    public function create()
    {
        echo view('courses/create');
    }

    // Store course
    public function store()
    {
        $validation = \Config\Services::validation();
        $validation->setRules([
            'course_code' => 'required|is_unique[courses.course_code]',
            'course_name' => 'required',
            'semester' => 'required|numeric',
            'credits' => 'required|numeric',
            'department' => 'required'
        ]);

        if(!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $this->courseModel->save([
            'course_code' => $this->request->getPost('course_code'),
            'course_name' => $this->request->getPost('course_name'),
            'department' => $this->request->getPost('department'),
            'semester' => $this->request->getPost('semester'),
            'credits' => $this->request->getPost('credits'),
            'status'      => 'Active'
        ]);

        session()->setFlashdata('success','Course added successfully.');
        return redirect()->to('/admin/courses');
    }

    // Edit course form
    public function edit($id)
    {
        $data['course'] = $this->courseModel->find($id);
        echo view('courses/edit', $data);
    }

    // Update course
    public function update($id)
    {
        $validation = \Config\Services::validation();
        $validation->setRules([
            'course_name' => 'required',
            'semester' => 'required|numeric',
            'credits' => 'required|numeric',
            'department' => 'required'
        ]);

        if(!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $this->courseModel->update($id, [
            'course_name' => $this->request->getPost('course_name'),
            'department' => $this->request->getPost('department'),
            'semester' => $this->request->getPost('semester'),
            'credits' => $this->request->getPost('credits'),
            'status' => $this->request->getPost('status'),
        ]);

        session()->setFlashdata('success','Course updated successfully.');
        return redirect()->to('/admin/courses');
    }

    // Soft Delete
    public function delete($id)
    {
        $this->courseModel->update($id, ['deleted_at' => date('Y-m-d H:i:s')]);
        session()->setFlashdata('success','Course deleted successfully.');
        return redirect()->to('/admin/courses');
    }
    public function toggleStatus()
{
    $id = $this->request->getPost('id');
    $course = $this->courseModel->find($id);

    if ($course) {
        $newStatus = ($course['status'] == 'Active') ? 'Inactive' : 'Active';
        $this->courseModel->update($id, ['status' => $newStatus]);

        return $this->response->setJSON(['status' => $newStatus]);
    }
    return $this->response->setJSON(['status' => 'error']);
}

}
