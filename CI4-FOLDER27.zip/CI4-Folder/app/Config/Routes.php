<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
/*$routes->get('/','AuthController::login');
$routes->get('login','AuthController::login');
$routes->post('loginPost','AuthController::loginPost');
$routes->get('logout','AuthController::logout');

// Fee Routes
$routes->get('fees','FeeController::index');
$routes->get('fees/create','FeeController::create');
$routes->post('fees/store','FeeController::store');
$routes->get('fees/edit/(:num)','FeeController::edit/$1');
$routes->post('fees/update/(:num)','FeeController::update/$1');
$routes->post('fees/delete/(:num)','FeeController::delete/$1'); 
$routes->get('fees/receipt/(:num)','FeeController::receipt/$1');*/





$routes->get('/', 'AuthController1::login');
$routes->post('/login', 'AuthController1::loginPost');
$routes->get('/logout', 'AuthController1::logout');

// Course Allocation CRUD
$routes->get('/course_allocation', 'CourseAllocationController::index');
$routes->get('/course_allocation/create', 'CourseAllocationController::create');
$routes->post('/course_allocation/store', 'CourseAllocationController::store');
$routes->get('/course_allocation/edit/(:num)', 'CourseAllocationController::edit/$1');
$routes->post('/course_allocation/update/(:num)', 'CourseAllocationController::update/$1');
$routes->get('/course_allocation/delete/(:num)', 'CourseAllocationController::delete/$1');
