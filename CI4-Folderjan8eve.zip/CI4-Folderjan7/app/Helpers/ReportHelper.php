<?php

if (!function_exists('generateReportNumber')) {
    function generateReportNumber()
    {
        $file = WRITEPATH . 'report_number.txt';
        
        // If file doesn't exist, start with 1000
        if (!file_exists($file)) {
            file_put_contents($file, 1000);
            return 1000;
        }
        
        // Read last number and increment
        $lastNumber = (int)file_get_contents($file);
        $newNumber = $lastNumber + 1;
        file_put_contents($file, $newNumber);
        return $newNumber;
    }
}
