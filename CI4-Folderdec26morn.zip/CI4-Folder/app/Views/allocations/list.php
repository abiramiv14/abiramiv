<h2>Course Allocations</h2>

<?php if(isAdmin()): ?>
<a href="<?= base_url('allocations/create') ?>">New Allocation</a>
<?php endif; ?>

<table border="1">
<tr>
<th>Code</th><th>Name</th><th>Year</th><th>Sem</th><th>Action</th>
</tr>

<?php foreach($allocations as $a): ?>
<tr>
<td><?= $a['course_code'] ?></td>
<td><?= $a['course_name'] ?></td>
<td><?= $a['academic_year'] ?></td>
<td><?= $a['semester'] ?></td>
<td>
<?php if (canEditAllocation($a['academic_year'])): ?>
Edit / Delete
<?php else: ?>
View Only
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
</table>
