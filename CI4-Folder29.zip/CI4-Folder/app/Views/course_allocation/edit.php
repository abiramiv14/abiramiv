<!DOCTYPE html>
<html>
<head>
    <title>Edit Allocation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Edit Allocation</h2>
    <form method="post" action="/course_allocation/update/<?= $allocation['id'] ?>">
        <div class="mb-3">
            <label>Course:</label>
            <select name="course_id" class="form-select" required>
                <?php foreach($courses as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= ($allocation['course_id']==$c['id'])?'selected':'' ?>>
                        <?= $c['course_name'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Faculty:</label>
            <select name="faculty_id" class="form-select" required>
                <?php foreach($faculty as $f): ?>
                    <option value="<?= $f['id'] ?>" <?= ($allocation['faculty_id']==$f['id'])?'selected':'' ?>>
                        <?= $f['name'] ?> (<?= $f['department'] ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Academic Year:</label>
            <select name="academic_year" class="form-select" required>
    <?php if($allocation['academic_year'] == '2025-2028'): ?>
        <option value="2025-2028" selected>2025-2028</option>
    <?php else: ?>
        <option value="<?= $allocation['academic_year'] ?>" selected disabled><?= $allocation['academic_year'] ?> (View Only)</option>
    <?php endif; ?>
</select>

        </div>
        <div class="mb-3">
            <label>Semester:</label>
            <select name="semester" class="form-select" required>
                <option value="1" <?= ($allocation['semester']==1)?'selected':'' ?>>1</option>
                <option value="2" <?= ($allocation['semester']==2)?'selected':'' ?>>2</option>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Update Allocation</button>
        <a href="/course_allocation" class="btn btn-secondary">Back</a>
    </form>
</div>
</body>
</html>
