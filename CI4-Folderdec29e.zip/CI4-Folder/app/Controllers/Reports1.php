<?php
namespace App\Controllers;

use App\Models\FeeReportModel;

class reports1 extends BaseController
{
    public function feeStatusByDepartment()
    {
        $model = new FeeReportModel();
        $data['feeData'] = $model->getFeeStatusByDepartment();

        return view('reports/fee_status_department', $data);
    }
}
