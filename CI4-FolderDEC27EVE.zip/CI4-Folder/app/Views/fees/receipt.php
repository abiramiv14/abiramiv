<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 20px;
}

h2 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
}

.receipt-container {
    max-width: 500px;
    margin: 0 auto;
    background: #fff;
    padding: 25px 30px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.receipt-container p {
    font-size: 16px;
    margin: 8px 0;
    color: #555;
}

.receipt-container b {
    color: #333;
}

button, a {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 20px;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
}

button {
    background-color: #28a745;
    color: white;
}

button:hover {
    background-color: #218838;
}

a {
    background-color: #007bff;
    color: white;
    margin-left: 10px;
}

a:hover {
    background-color: #0069d9;
}
</style>


<h2>Fee Receipt</h2>

<p><b>Receipt No:</b> <?= $fee['receipt_no'] ?></p>
<p><b>Student:</b> <?= $student['register_no'] ?> - <?= $student['department'] ?></p>
<p><b>Semester:</b> <?= $fee['semester'] ?></p>
<p><b>Total Fee:</b> <?= formatINR($fee['fee_amount']) ?></p>
<p><b>Paid Amount:</b> <?= formatINR($fee['paid_amount']) ?></p>
<p><b>Due Amount:</b> <?= formatINR($fee['due_amount']) ?></p>
<p><b>Payment Mode:</b> <?= $fee['payment_mode'] ?></p>
<p><b>Date:</b> <?= $fee['payment_date'] ?></p>

<button onclick="window.print()">Print Receipt</button>
<a href="<?= base_url('fees') ?>">Back</a>
