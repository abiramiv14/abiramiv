<?php helper(['form','url']); ?>
<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            background-color: #fff;
            padding: 50px 40px;
            border-radius: 15px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.3);
            width: 360px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .login-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 50px rgba(0,0,0,0.4);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            font-size: 28px;
            letter-spacing: 1px;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        input[type="email"], input[type="password"],input[type="text"] {
            width: 100%;
            padding: 14px 45px 14px 14px; /* padding right for toggle */
            border-radius: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 16px;
            transition: 0.3s ease;
        }

        input[type="email"]:focus, input[type="password"]:focus,input[type="text"]:focus {
            border-color: #667eea;
            box-shadow: 0 0 8px rgba(102, 126, 234, 0.4);
            outline: none;
        }

        /* Password toggle button */
        .toggle-password {
            position: absolute;
            top: 50%;
            right: 14px;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 14px;
            color: #667eea;
            font-weight: bold;
            user-select: none;
        }

        /* LOGIN BUTTON */
        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #ff758c, #ff7eb3);
            border: none;
            color: white;
            font-size: 18px;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .btn-login:hover {
            background: linear-gradient(135deg, #ff7eb3, #ff758c);
            transform: translateY(-2px);
        }

        .error-message {
            color: #e74c3c;
            margin-bottom: 15px;
            text-align: center;
            font-weight: bold;
        }

        ::placeholder {
            color: #aaa;
            font-style: italic;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body>

<div class="login-container">
    <h2>User Login</h2>

    <?php if(session()->getFlashdata('error')): ?>
        <div class="error-message"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <?= form_open('/loginCheck') ?>

    <div class="form-group">
        <?= form_input([
            'type' => 'email',
            'name' => 'email',
            'placeholder' => 'Email',
            'required' => 'required'
        ]) ?>
    </div>

    <div class="form-group">
        <?= form_password([
            'type' => 'password',
            'name' => 'password',
            'id' => 'password',
            'placeholder' => 'Password',
            'required' => 'required'
        ]) ?>
        <span class="toggle-password">Show</span>
    </div>

    <div class="form-group">
        <?= form_submit('login', 'Login', ['class' => 'btn-login']) ?>
    </div>

    <?= form_close() ?>
</div>

<script>
$(document).ready(function(){
    $('.toggle-password').click(function(){
        let passwordField = $('#password');
        let type = passwordField.attr('type') === 'password' ? 'text' : 'password';
        passwordField.attr('type', type);
        $(this).text(type === 'password' ? 'Show' : 'Hide');
    });
});
</script>

</body>
</html>
