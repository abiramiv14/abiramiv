<?php namespace App\Models;
use CodeIgniter\Model;

class UserModel1 extends Model
{
    protected $table = 'users';
    protected $allowedFields = ['name','email','password','role'];
}
