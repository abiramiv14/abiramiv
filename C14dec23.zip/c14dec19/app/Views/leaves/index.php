<!DOCTYPE html>
<html>
<head>
    <title>HOD - Faculty Leave Requests</title>
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">

    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        header {
            background-color: #2c3e50;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .profile-dropdown {
            position: relative;
            display: inline-block;
        }
        .profile-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: #fff;
            min-width: 120px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .profile-dropdown-content a {
            color: #333;
            padding: 8px 12px;
            text-decoration: none;
            display: block;
        }
        .profile-dropdown-content a:hover { background-color: #f2f2f2; }
        .profile-dropdown:hover .profile-dropdown-content { display: block; }

        table.dataTable tbody tr td { text-align: center; }
        .pending { color: orange; font-weight: bold; }
        .approved { color: green; font-weight: bold; }
        .rejected { color: red; font-weight: bold; }
        .disabled { color: gray; pointer-events: none; }
        a.action-btn { margin: 0 5px; text-decoration: none; color: #007bff; }
    </style>
</head>
<body>

<header>
    <div><h3>College ERP - Leave Management (HOD)</h3></div>
    <div class="profile-dropdown">
        <?= session()->get('username') ?> (<?= session()->get('role') ?>)
        <div class="profile-dropdown-content">
            <a href="<?= base_url('logout') ?>">Logout</a>
        </div>
    </div>
</header>

<div style="padding: 20px;">
    <h2>Faculty Leave Requests</h2>

    <table id="hodLeaveTable" class="display responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>S.No</th>
                <th>Faculty Email</th>
                <th>Department</th>
                <th>Leave Type</th>
                <th>From Date</th>
                <th>To Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($Fetched_Datas_Hod)): ?>
                <?php $i=1; foreach($Fetched_Datas_Hod as $row): ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td><?= esc($row['email']) ?></td>
                    <td><?= esc($row['dept_name']) ?></td>
                    <td><?= esc($row['type']) ?></td>
                    <td><?= esc($row['from_date']) ?></td>
                    <td><?= esc($row['to_date']) ?></td>
                    <td class="<?= esc($row['status']) ?>"><?= ucfirst($row['status']) ?></td>
                    <td>
                        <?php if($row['status'] == 'pending'): ?>
                            <a class="action-btn" href="<?= site_url('hod/approve/'.$row['id']) ?>">Approve</a>
                            <a class="action-btn" href="<?= site_url('hod/reject/'.$row['id']) ?>">Reject</a>
                        <?php else: ?>
                            <span class="disabled">No actions available</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>

<script>
$(document).ready(function() {
    $('#hodLeaveTable').DataTable({
        responsive: true,
        pageLength: 10,
        order: [[0, 'asc']]
    });
});
</script>

</body>
</html>
