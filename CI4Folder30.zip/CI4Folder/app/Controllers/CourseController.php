<?php

namespace App\Controllers;

use App\Models\CourseModel;

class CourseController extends BaseController
{
    protected $courseModel;

    public function __construct()
    {
        $this->courseModel = new CourseModel();
    }

    // Dashboard + List
    public function index()
    {
        $courses = $this->courseModel->getCourses();

        $dept = [];
        $sem  = [];
        foreach ($courses as $c) {
            $dept[$c['department']] = ($dept[$c['department']] ?? 0) + 1;
            $sem[$c['semester']]    = ($sem[$c['semester']] ?? 0) + 1;
        }

        return view('courses/index', [
            'courses' => $courses,
            'dept'    => $dept,
            'sem'     => $sem
        ]);
    }

    // ADD
   public function store()
{
    $rules = [
        'course_code' => 'required|is_unique[courses.course_code]',
        'course_name' => 'required',
        'semester'    => 'required|numeric'
    ];

    if(!$this->validate($rules)){
        return $this->response->setJSON([
            'status' => 'error',
            'errors' => $this->validator->getErrors()
        ]);
    }

    $data = [
        'course_code' => $this->request->getPost('course_code'),
        'course_name' => $this->request->getPost('course_name'),
        'department'  => $this->request->getPost('department'),
        'semester'    => $this->request->getPost('semester'),
        'credits'     => $this->request->getPost('credits'),
        'status'      => 'Active'
    ];

    $id = $this->courseModel->insert($data);

    // 🔴 THIS WAS MISSING
    $course = $this->courseModel->find($id);

    return $this->response->setJSON([
        'status' => 'success',
        'course' => $course
    ]);
}



    // INLINE UPDATE
    public function updateInline()
    {
        $id = $this->request->getPost('id');
        $data = $this->request->getPost();
        unset($data['id']);

        $this->courseModel->update($id, $data);
        return $this->response->setJSON(['status' => 'success']);
    }

    // TOGGLE STATUS
    public function toggleStatus()
{
    $id = $this->request->getPost('id');

    $course = $this->courseModel->find($id);

    $newStatus = ($course['status'] === 'Active') ? 'Inactive' : 'Active';

    $this->courseModel->update($id, ['status' => $newStatus]);

    return $this->response->setJSON([
        'status' => $newStatus   // 👈 IMPORTANT
    ]);
}

    // DELETE
    public function delete($id)
    {
        $this->courseModel->delete($id);
        return $this->response->setJSON(['status' => 'success']);
    }
}
