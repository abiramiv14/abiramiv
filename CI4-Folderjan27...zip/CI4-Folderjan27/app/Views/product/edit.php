<form method="post" action="/employee/update/<?= $employee['id'] ?>">
    Name: <input type="text" name="emp_name" value="<?= $employee['emp_name'] ?>"><br><br>
    Email: <input type="email" name="email" value="<?= $employee['email'] ?>"><br><br>

    Department:
    <select name="department_id">
        <?php foreach ($departments as $dept): ?>
        <option value="<?= $dept['id'] ?>" 
            <?= ($dept['id'] == $employee['department_id']) ? 'selected' : '' ?>>
            <?= $dept['dept_name'] ?>
        </option>
        <?php endforeach; ?>
    </select><br><br>

    Salary: <input type="text" name="salary" value="<?= $employee['salary'] ?>"><br><br>

    Status:
    <select name="status">
        <option value="Active" <?= $employee['status']=='Active'?'selected':'' ?>>Active</option>
        <option value="Inactive" <?= $employee['status']=='Inactive'?'selected':'' ?>>Inactive</option>
    </select><br><br>

    <button type="submit">Update</button>
</form>
