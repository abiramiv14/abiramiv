<!DOCTYPE html>
<html>
<head>
    <title>Registered Courses</title>

    <style>
        body { 
            font-family: Arial; 
            background:#f4f4f4; 
        }
        table { 
            border-collapse: collapse; 
            width:90%; 
            margin:40px auto; 
            background:#fff; 
        }
        th, td { 
            border:1px solid #ccc; 
            padding:10px; 
            text-align:center; 
        }
        th { 
            background:#ffc107; 
            color:#000; 
        }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>

</head>
<body>

<h2 style="text-align:center;">Registered Students</h2>

<table id="studentsTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Student Name</th>
            <th>Course Name</th>
            <th>Semester</th>
            <th>Fees</th>
            <th>Email</th>
        </tr>
    </thead>

    <tbody>
        <?php foreach ($registrations as $row): ?>
        <tr>
            <td><?= esc($row['course_id']) ?></td>
            <td><?= esc($row['student_name']) ?></td>
            <td><?= esc($row['course_name']) ?></td>
            <td><?= esc($row['semester']) ?></td>
            <td><?= esc($row['fees']) ?></td>
            <td><?= esc($row['email']) ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<script>
$(document).ready(function () {
    $('#studentsTable').DataTable({
        paging: true,
        searching: true,
        ordering: true,
        info: true
    });
});
</script>

</body>
</html>
