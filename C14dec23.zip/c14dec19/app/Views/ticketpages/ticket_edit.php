<h2>Edit Ticket</h2>
<form method="post" action="/tickets/update/<?= $ticket['id'] ?>">
    Issue Type: <input type="text" name="issue_type" value="<?= $ticket['issue_type'] ?>" required><br>
    Description: <textarea name="description" required><?= $ticket['description'] ?></textarea><br>
    Status:
    <select name="status">
        <option value="Open" <?= $ticket['status']=='Open'?'selected':''?>>Open</option>
        <option value="In Progress" <?= $ticket['status']=='In Progress'?'selected':''?>>In Progress</option>
        <option value="Closed" <?= $ticket['status']=='Closed'?'selected':''?>>Closed</option>
    </select><br>
    <button type="submit">Update</button>
</form>
