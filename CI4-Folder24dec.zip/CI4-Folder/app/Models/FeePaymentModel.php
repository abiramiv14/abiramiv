<?php
namespace App\Models;

use CodeIgniter\Model;

class FeePaymentModel extends Model
{
    protected $table = 'fee_payments';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'student_id', 'semester', 'fee_amount', 'paid_amount', 'payment_mode', 'payment_date', 'receipt_no'
    ];
}
