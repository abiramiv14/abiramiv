<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index');

$routes->get('/products', 'Product::index');

$routes->get('/products/create', 'Product::create');   // ADD form
$routes->post('/products/store', 'Product::store');    // SAVE

$routes->post('/products/inlineEdit', 'Product::inlineEdit');
$routes->get('/products/toggleStatus/(:num)', 'Product::toggleStatus/$1');
$routes->get('/products/delete/(:num)', 'Product::delete/$1');
$routes->get('/products/restore/(:num)', 'Product::restore/$1');
$routes->post('/products/bulkAction', 'Product::bulkAction');
