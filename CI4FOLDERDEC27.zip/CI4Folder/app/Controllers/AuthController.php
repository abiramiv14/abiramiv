<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class AuthController extends Controller
{
    public function loginForm()
    {
        helper(['form','url']);
        return view('login');
    }

    public function loginCheck()
    {
        helper(['form','url']);
        $model = new UserModel();

        $email    = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $user = $model->where([
            'email'    => $email,
            'password' => $password
        ])->first();

        if ($user) {
            // 🔑 SET SESSION INCLUDING ROLE
            session()->set([
                'user_id' => $user['id'],
                'email'   => $user['email'],
                'role'    => $user['role'],
                'logged_in' => true
            ]);

            // Redirect based on role
            if ($user['role'] == 'admin') {
                return redirect()->to('/admin');
            } else {
                return redirect()->to('/cart');
            }
        }

        session()->setFlashdata('error','Invalid Login');
        return redirect()->to('/');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}
