<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); height: 100vh; display: flex; align-items: center; justify-content: center; }
        .login-card { background: #fff; border-radius: 16px; box-shadow: 0 15px 35px rgba(0,0,0,0.2); overflow: hidden; width: 100%; max-width: 400px; padding: 40px; }
        .form-control { padding: 12px 15px; border-radius: 8px; border: 1px solid #e2e8f0; background: #f8fafc; }
        .form-control:focus { background: #fff; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2); border-color: #667eea; }
        .btn-primary { background: linear-gradient(to right, #667eea, #764ba2); border: none; padding: 12px; font-weight: 600; border-radius: 8px; letter-spacing: 0.5px; }
        .btn-primary:hover { opacity: 0.9; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="text-center mb-4">
            <i class="bi bi-shield-lock-fill text-primary" style="font-size: 3rem;"></i>
            <h3 class="fw-bold mt-2">Admin Login</h3>
            <p class="text-muted small">Enter your credentials to access</p>
        </div>
        
        <?php if(session()->getFlashdata('error')): ?>
            <div class="alert alert-danger border-0 bg-danger bg-opacity-10 text-danger mb-3">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <form action="/login" method="POST">
            <div class="mb-3">
                <label class="form-label text-muted small fw-bold">USERNAME</label>
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-person text-muted"></i></span>
                    <input type="text" name="username" class="form-control border-start-0 ps-0" placeholder="admin" required>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label text-muted small fw-bold">PASSWORD</label>
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-lock text-muted"></i></span>
                    <input type="password" name="password" class="form-control border-start-0 ps-0" placeholder="••••••" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 shadow-sm">Sign In</button>
        </form>
    </div>
</body>
</html>