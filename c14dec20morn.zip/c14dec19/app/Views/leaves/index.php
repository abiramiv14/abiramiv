<!DOCTYPE html>
<html>
<head>
    <title>HOD - Faculty Leave Requests</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #333;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .pending { color: orange; font-weight: bold; }
        .approved { color: green; font-weight: bold; }
        .rejected { color: red; font-weight: bold; }
    </style>
</head>
<body>

<h2>Faculty Leave Requests (HOD View)</h2>

<p>
    Logged in as: <b><?= session()->get('username') ?></b> |
    Department: <b><?= session()->get('dept_name') ?></b> |
    Role: <b><?= session()->get('role') ?></b>
</p>

<a href="<?= base_url('logout') ?>">Logout</a>

<br><br>

<table>
    <tr>
        <th>S.No</th>
        <th>Faculty Email</th>
        <th>Department</th>
        <th>Leave Type</th>
        <th>From Date</th>
        <th>To Date</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

    <?php if (!empty($Fetched_Datas_Hod)): ?>
        <?php $i = 1; ?>
        <?php foreach ($Fetched_Datas_Hod as $row): ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= esc($row['email']) ?></td>
                <td><?= esc($row['dept_name']) ?></td>
                <td><?= esc($row['type']) ?></td>
                <td><?= esc($row['from_date']) ?></td>
                <td><?= esc($row['to_date']) ?></td>
                <td class="<?= esc($row['status']) ?>">
                    <?= ucfirst($row['status']) ?>
                </td>
                <td>
                    <?php if ($row['status'] == 'pending'): ?>
    <a href="<?= base_url('hod/approve/'.$row['id']) ?>">Approve</a> |
    <a href="<?= base_url('hod/reject/'.$row['id']) ?>">Reject</a>
<?php else: ?>
    <span class="disabled">No actions available</span>
<?php endif; ?>

            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="8">No leave requests found</td>
        </tr>
    <?php endif; ?>
</table>

</body>
</html>

