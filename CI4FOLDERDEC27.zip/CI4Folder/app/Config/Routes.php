<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
/*$routes->get('/', function() {
    return view('welcome_message');  // loads dashboard.php from app/Views/
});
$routes->get('students', 'task1\StudentController::index');
$routes->post('students/save', 'task1\StudentController::save');
$routes->get('students/list', 'task1\StudentController::list');

$routes->post('students/update/(:num)', 'task1\StudentController::update/$1');
$routes->get('students/delete/(:num)', 'task1\StudentController::delete/$1');


$routes->get('/employees/create', 'task1\EmployeeController::create');
$routes->post('/employees/store', 'task1\EmployeeController::store'); 
$routes->get('/employees', 'task1\EmployeeController::index');   
$routes->post('employees/update/(:num)', 'task1\EmployeeController::update/$1');
$routes->get('employees/delete/(:num)', 'task1\EmployeeController::delete/$1');


$routes->get('/courses', 'task1\CourseController::index');
$routes->get('/courses/create', 'task1\CourseController::create'); 
$routes->post('/courses/store', 'task1\CourseController::store'); 
 
$routes->post('/courses/update/(:num)', 'task1\CourseController::update/$1');
$routes->get('/courses/delete/(:num)', 'task1\CourseController::delete/$1');


$routes->get('/products', 'task1\ProductController::index');
$routes->get('/products/create', 'task1\ProductController::create');
$routes->post('/products/store', 'task1\ProductController::store');

$routes->post('/products/update/(:num)', 'task1\ProductController::update/$1');
$routes->get('/products/delete/(:num)', 'task1\ProductController::delete/$1');



$routes->get('incidents/add', 'task1\IncidentController::add');
$routes->post('incidents/save', 'task1\IncidentController::saveIncident');
$routes->get('incidents', 'task1\IncidentController::viewIncidents');


$routes->post('incidents/update/(:num)', 'task1\IncidentController::update/$1');
$routes->get('incidents/delete/(:num)', 'task1\IncidentController::delete/$1');*/

$routes->get('/', 'AuthControllers::login');
$routes->post('/login', 'AuthControllers::loginPost');
$routes->get('/logout', 'AuthControllers::logout');

// Admin routes with auth filter
$routes->group('admin', ['filter' => 'auth'], function($routes){
    $routes->get('dashboard', 'DashboardController::index');

    // Course CRUD
    $routes->get('courses', 'CourseController::index');
    $routes->get('courses/create', 'CourseController::create');
    $routes->post('courses/store', 'CourseController::store');
    $routes->get('courses/edit/(:num)', 'CourseController::edit/$1');
    $routes->post('courses/update/(:num)', 'CourseController::update/$1');
    $routes->get('courses/delete/(:num)', 'CourseController::delete/$1');
});
