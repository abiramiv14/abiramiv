<h2>Course Allocations</h2>

<?php if(session()->getFlashdata('success')): ?>
<p style="color:green"><?= session()->getFlashdata('success') ?></p>
<?php endif; ?>
<?php if(session()->getFlashdata('error')): ?>
<p style="color:red"><?= session()->getFlashdata('error') ?></p>
<?php endif; ?>

<?php if(isAdmin()): ?>
<a href="<?= base_url('allocations/create') ?>">New Allocation</a><br><br>
<?php endif; ?>

<table border="1" cellpadding="5">
<tr>
<th>Course Code</th>
<th>Course Name</th>
<th>Faculty</th>
<th>Academic Year</th>
<th>Semester</th>
<th>Actions</th>
</tr>

<?php foreach($allocations as $alloc): ?>
<tr>
<td><?= $alloc['course_code'] ?></td>
<td><?= $alloc['course_name'] ?></td>
<td><?= $alloc['faculty_name'] ?></td>
<td><?= $alloc['academic_year'] ?></td>
<td><?= $alloc['semester'] ?></td>
<td>
<?php if(canEditAllocation($alloc['academic_year'])): ?>
<a href="<?= base_url('allocations/edit/'.$alloc['id']) ?>">Edit</a> | 
<form method="post" action="<?= base_url('allocations/delete/'.$alloc['id']) ?>" style="display:inline;">
<?= csrf_field() ?>
<button type="submit" onclick="return confirm('Delete?')">Delete</button>
</form>
<?php else: ?>
View Only
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
</table>
