<?php
namespace App\Controllers\leave;

use CodeIgniter\Controller;
use App\Models\leave\FacultyModel;

class HodController extends Controller
{
    protected $facultyModel;

    public function __construct() {
        $this->facultyModel = new FacultyModel();
    }

    public function approve($id)
    {
        $this->facultyModel->update($id, ['status' => 'approved']);
        return redirect()->back(); // go back to previous page
    }

    public function reject($id)
    {
        $this->facultyModel->update($id, ['status' => 'rejected']);
        return redirect()->back();
    }
}
