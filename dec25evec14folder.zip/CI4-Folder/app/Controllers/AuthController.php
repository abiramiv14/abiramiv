<?php namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\UserModel;
use App\Models\StudentModel;

class AuthController extends Controller
{
    public function login()
    {
        return view('auth/login');
    }

    public function loginPost()
    {
        $userModel = new UserModel();
        $studentModel = new StudentModel();

        $user = $userModel
            ->where('email',$this->request->getPost('email'))
            ->where('password',$this->request->getPost('password'))
            ->first();

        if(!$user){
            return redirect()->back()->with('error','Invalid Login');
        }

        session()->set([
            'user_id' => $user['id'],
            'role' => $user['role']
        ]);

        if($user['role']=='student'){
            $student = $studentModel->where('user_id',$user['id'])->first();
            session()->set('student_id',$student['id']);
        }

        return redirect()->to('/fees');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
