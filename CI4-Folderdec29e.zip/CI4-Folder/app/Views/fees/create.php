<!DOCTYPE html>
<html>
<head>
    <title>Create Fee Payment</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            padding: 30px;
        }

        .profile-dropdown {
            float: right;
            margin-bottom: 20px;
        }

        .profile-dropdown select {
            padding: 8px;
            border-radius: 4px;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        form {
            max-width: 500px;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        label {
            font-weight: bold;
        }

        select, input {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            width: 100%;
            background: #28a745;
            color: #fff;
            border: none;
            padding: 12px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #218838;
        }

        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="profile-dropdown">
    <select onchange="if(this.value){window.location=this.value}">
        <option value="">Profile</option>
        <option value="<?= base_url('logout') ?>">Logout</option>
    </select>
</div>

<h2>Create Fee Payment</h2>

<?php if(session()->getFlashdata('error')): ?>
    <p class="error"><?= session()->getFlashdata('error') ?></p>
<?php endif; ?>

<?php if(session()->getFlashdata('success')): ?>
    <script>alert("<?= session()->getFlashdata('success') ?>")</script>
<?php endif; ?>

<form method="post" action="<?= base_url('fees/store') ?>">
    <?= csrf_field() ?>

    <label>Student</label>
    <select name="student_id" required>
        <?php foreach($students as $s): ?>
            <option value="<?= $s['id'] ?>">
                <?= $s['register_no']." - ".$s['department'] ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Semester</label>
    <input type="number" name="semester" required>

    <label>Total Fee</label>
    <input type="number" name="fee_amount" required>

    <label>Paid Amount</label>
    <input type="number" name="paid_amount" required>

    <label>Payment Mode</label>
    <select name="payment_mode" required>
        <option value="Cash">Cash</option>
        <option value="UPI">UPI</option>
        <option value="Bank">Bank</option>
    </select>

    <button type="submit">Submit Payment</button>
</form>

</body>
</html>
