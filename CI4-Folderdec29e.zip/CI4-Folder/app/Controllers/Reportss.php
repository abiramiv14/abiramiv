<?php
namespace App\Controllers;

use CodeIgniter\Controller;

class Reportss extends Controller
{
    protected $db;

    public function __construct()
    {
        // Load database
        $this->db = \Config\Database::connect();
    }

    /**
     * Task 5: College Management Dashboard
     * Shows 3 widgets:
     * 1. Total Students by Department
     * 2. Fee Collection Summary (Paid vs Pending)
     * 3. Attendance Compliance Indicator (% students above 75%)
     */
    public function dashboard()
    {
        // --------------------- 1. Total Students by Department ---------------------
        $data['studentsByDept'] = $this->db->table('students s')
            ->select('d.department_name, COUNT(s.id) as total')
            ->join('departments d','d.id=s.department_id')
            ->groupBy('d.department_name')
            ->get()
            ->getResultArray();

        // --------------------- 2. Fee Collection Summary ---------------------
        $fees = $this->db->table('fees')
            ->select("
                SUM(CASE WHEN status='Paid' THEN 1 ELSE 0 END) AS paid,
                SUM(CASE WHEN status='Not Paid' THEN 1 ELSE 0 END) AS pending
            ")
            ->get()
            ->getRowArray();

        $data['feeData'] = $fees;

        // --------------------- 3. Attendance Compliance ---------------------
        $totalStudents = $this->db->table('attendance')->countAllResults();
        $above75 = $this->db->table('attendance')->where('attendance_percentage >=', 75)->countAllResults();

        $data['attendancePercent'] = $totalStudents ? round(($above75 / $totalStudents) * 100, 2) : 0;

        // --------------------- Load Dashboard View ---------------------
        return view('reports/dashboard', $data);
    }

    // Optional: Individual report methods for Task 1–4 can also be added here
}
