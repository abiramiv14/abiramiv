<?php

namespace App\Models;

use CodeIgniter\Model;

class UploadHistoryModel extends Model
{
    protected $table      = 'student_uploads';  // Table name
    protected $primaryKey = 'id';               // Primary key column
    protected $allowedFields = ['file_name', 'total_uploaded', 'uploaded_at']; // Fields you can insert/update

    protected $useTimestamps = true; // Automatically manage created_at/updated_at
    
      // optional, can remove if not needed
}
