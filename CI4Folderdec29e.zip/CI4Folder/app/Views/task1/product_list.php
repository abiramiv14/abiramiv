<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:90%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#343a40; color:#fff; }
        .editing-row { background-color: #fff3cd !important; }
        .edit-field { width:100%; padding:3px; }
        button { cursor:pointer; }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
</head>
<body>

<h2 style="text-align:center;">Product List</h2>

<div style="width:80%; margin:20px auto; text-align:right;">
    <a href="<?= base_url('/products/create') ?>"
       style="padding:10px 15px; background:#28a745; color:#fff; text-decoration:none; border-radius:4px;">
        + Add Products
    </a>
</div>

<table id="productTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Description</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
<?php foreach ($products as $row): ?>
<tr data-id="<?= $row['product_id'] ?>">
    <td><?= $row['product_id'] ?></td>
    <td><span class="text"><?= $row['product_name'] ?></span>
        <input type="text" name="product_name" class="edit-field" value="<?= $row['product_name'] ?>" style="display:none;"></td>
    <td><span class="text"><?= $row['category'] ?></span>
        <input type="text" name="category" class="edit-field" value="<?= $row['category'] ?>" style="display:none;"></td>
    <td><span class="text"><?= $row['price'] ?></span>
        <input type="text" name="price" class="edit-field" value="<?= $row['price'] ?>" style="display:none;"></td>
    <td><span class="text"><?= $row['stock_quantity'] ?></span>
        <input type="text" name="stock_quantity" class="edit-field" value="<?= $row['stock_quantity'] ?>" style="display:none;"></td>
    <td><span class="text"><?= $row['description'] ?></span>
        <input type="text" name="description" class="edit-field" value="<?= $row['description'] ?>" style="display:none;"></td>
    <td>
        <button class="edit-btn"><i class="fa fa-pen" style="color:blue;"></i></button>
        <button class="save-btn" style="display:none;"><i class="fa fa-check" style="color:green;"></i></button>
        <button class="cancel-btn" style="display:none;"><i class="fa fa-times" style="color:orange;"></i></button>
        <a href="<?= base_url('products/delete/'.$row['product_id']) ?>" onclick="return confirm('Delete this product?')">
            <i class="fa fa-trash" style="color:red;"></i>
        </a>
    </td>
</tr>
<?php endforeach; ?>
    </tbody>
</table>

<script>
$(document).ready(function() {
    $('#productTable').DataTable();

    // Click edit
    $(document).on('click', '.edit-btn', function() {
        let row = $(this).closest('tr');
        row.addClass('editing-row');
        row.find('.text').hide();
        row.find('.edit-field').show();
        row.find('.edit-btn').hide();
        row.find('.save-btn, .cancel-btn').show();
    });

    // Click cancel
    $(document).on('click', '.cancel-btn', function() {
        let row = $(this).closest('tr');
        row.removeClass('editing-row');
        row.find('.edit-field').each(function() {
            $(this).val($(this).siblings('.text').text());
        });
        row.find('.edit-field').hide();
        row.find('.text').show();
        row.find('.edit-btn').show();
        row.find('.save-btn, .cancel-btn').hide();
    });

    // Click save
    $(document).on('click', '.save-btn', function() {
        let row = $(this).closest('tr');
        let id = row.data('id');
        let data = {};
        row.find('.edit-field').each(function() {
            data[$(this).attr('name')] = $(this).val();
        });

        // AJAX POST request to update row
        $.post("<?= base_url('products/update') ?>/"+id, data, function(response){
            row.find('.edit-field').each(function() {
                $(this).siblings('.text').text($(this).val());
            });
            row.removeClass('editing-row');
            row.find('.edit-field').hide();
            row.find('.text').show();
            row.find('.edit-btn').show();
            row.find('.save-btn, .cancel-btn').hide();
        });
    });
});
</script>

</body>
</html>
