$(document).ready(function () {
    $("#student_name").focus();

    /* ================================
       STUDENT NAME / COURSE / CITY
       Only letters + space, max 15
    ================================= */
    $("#student_name, #course, #city").on("input", function () {
        let value = $(this).val();

        // Remove numbers & special characters
        value = value.replace(/[^a-zA-Z\s]/g, "");

        // Limit to 15 characters
        if (value.length > 15) {
            value = value.substring(0, 15);
        }

        $(this).val(value);
    });

    /* ================================
       PHONE NUMBER
       Only numbers, starts 6–9, max 10
    ================================= */
    $("#phone").on("input", function () {
        let value = $(this).val();

        // Allow only digits
        value = value.replace(/[^0-9]/g, "");

        // Max 10 digits
        if (value.length > 10) {
            value = value.substring(0, 10);
        }

        $(this).val(value);
    });

    /* ================================
       FORM SUBMIT VALIDATION
    ================================= */
    $("#studentForm").submit(function () {

        let name = $("#student_name").val().trim();
        let email = $("#email").val().trim();
        let phone = $("#phone").val().trim();

        /* Student Name */
        if (name === "") {
            alert("Student name is required");
            return false;
        }

        /* Email format + rules */
        let emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z]{1,25}\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(email)) {
            alert("Enter valid email. After @ only alphabets, max 25 characters.");
            return false;
        }

        /* Phone validation */
        let phoneRegex = /^[6-9][0-9]{9}$/;
        if (!phoneRegex.test(phone)) {
            alert("Phone number must start from 6–9 and be exactly 10 digits.");
            return false;
        }

        return true;
    });
    $("#student_name").on("input", function(){
        if($(this).val().trim() !== "") $("#name_error").text("");
    });

    $("#email").on("input", function(){
        if($(this).val().trim() !== "") $("#email_error").text("");
    });

    $("#phone").on("input", function(){
        if($(this).val().trim() !== "") $("#phone_error").text("");
    });

});

