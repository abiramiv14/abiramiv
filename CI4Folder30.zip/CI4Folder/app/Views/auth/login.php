<?php helper(['form','url']); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>

    <style>
        body{
            background: linear-gradient(135deg, #667eea, #764ba2);
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-box{
            width: 380px;
            padding: 35px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        h2{
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        label{
            font-size: 14px;
            font-weight: bold;
            color: #555;
            display: block;
            margin-top: 12px;
        }

        input, select{
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        input:focus, select:focus{
            border-color: #667eea;
            outline: none;
            box-shadow: 0 0 6px rgba(102,126,234,0.5);
        }

        button{
            width: 100%;
            padding: 12px;
            margin-top: 25px;
            background: linear-gradient(to right, #667eea, #764ba2);
            border: none;
            border-radius: 6px;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover{
            opacity: 0.9;
        }

        .error{
            color: red;
            text-align: center;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="login-box">
    <h2>Login</h2>

    <?php if(session()->getFlashdata('error')): ?>
        <p class="error"><?= session()->getFlashdata('error') ?></p>
    <?php endif; ?>

    <?= form_open('/setRole') ?>

        <label>Select Role</label>
        <select name="role" required>
            <option value="">-- Select Role --</option>
            <option value="1">Admin</option>
            <option value="2">User</option>
        </select>

        <label>Email</label>
        <input type="email" name="email" placeholder="Enter email" required>

        <label>Password</label>
        <input type="password" name="password" placeholder="Enter password" required>

        <button type="submit">Login</button>

    <?= form_close() ?>
</div>

</body>
</html>
