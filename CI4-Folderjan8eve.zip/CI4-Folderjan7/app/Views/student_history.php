<!DOCTYPE html>
<html>
<head>
    <title>Upload History</title>
    <style>
        body { font-family: Arial; background: #f4f6f8; }
        .container {
            width: 90%;
            margin: 40px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; margin-bottom: 20px; color:#333; }
        .links a {
            display:inline-block;
            margin:5px;
            background:#007bff;
            color:white;
            padding:5px 10px;
            border-radius:4px;
            text-decoration:none;
        }
        .links a:hover { background:#0056b3; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td { border: 1px solid #ccc; }
        th, td { padding: 10px; text-align: left; }
        th { background-color: #f2f2f2; }
        .download-icon {
            font-size: 18px;
            color: #28a745;
            text-decoration: none;
        }
        .download-icon:hover { color: #1e7e34; }
    </style>
</head>
<body>

<div class="container">
    <h2>Upload History</h2>

    

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>File Name</th>
                <th>Total Uploaded</th>
                <th>Date</th>
                <th>Download</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($history as $h): ?>
            <tr>
                <td><?= $h['id'] ?></td>
                <td><?= esc($h['file_name']) ?></td>
                <td><?= $h['total_uploaded'] ?></td>
                <td><?= $h['uploaded_at'] ?></td>
                <td>
                    <?php if($h['file_name']): ?>
                        <a class="download-icon" 
                           href="<?= base_url('student/downloadUploadedFile/'.$h['file_name']) ?>" 
                           download="<?= $h['file_name'] ?>">⬇️</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
