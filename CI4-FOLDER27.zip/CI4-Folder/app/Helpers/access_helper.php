<?php
if (!function_exists('isAdmin')) {
    function isAdmin() {
        $session = session();
        return ($session->get('role') === 'admin');
    }
}

if (!function_exists('canEditAllocation')) {
    function canEditAllocation($allocationYear) {
        $currentYear = currentAcademicYear();
        return isAdmin() && ($allocationYear == $currentYear);
    }
}

if (!function_exists('currentAcademicYear')) {
    function currentAcademicYear() {
        return '2025-2028'; // Hardcoded current academic year
    }
}
