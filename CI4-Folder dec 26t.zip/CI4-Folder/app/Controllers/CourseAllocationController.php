<?php namespace App\Controllers;

use App\Models\CourseAllocationModel;
use App\Models\FacultyModel;
use App\Models\CourseModel;

class CourseAllocationController extends BaseController
{
    public function index()
    {
        helper('access');

        $allocationModel = new CourseAllocationModel();
        $facultyModel    = new FacultyModel();
        $courseModel     = new CourseModel();

        // Admin optional filter by year
        $yearFilter = $this->request->getGet('year');

        if (session()->get('role') === 'faculty') {
            $faculty = $facultyModel->where('user_id', session()->get('user_id'))->first();

            if (!$faculty) {
                $allocations = [];
            } else {
                $allocations = $allocationModel
                    ->where('academic_year', $faculty['academic_year'])
                    ->where('semester', $faculty['semester'])
                    ->orderBy('id', 'DESC')
                    ->findAll();
            }

        } else { // Admin
            $allocations = $allocationModel;
            if ($yearFilter) {
                $allocations = $allocations->where('academic_year', $yearFilter);
            }
            $allocations = $allocations->orderBy('id','DESC')->findAll();
        }

        // Prepare data for view
        $data['allocations'] = [];
        $data['years'] = $allocationModel->select('academic_year')->distinct()->orderBy('academic_year','DESC')->findAll();
        $data['selected_year'] = $yearFilter;

        foreach ($allocations as $a) {
            $course  = $courseModel->find($a['course_id']);
            $faculty = $facultyModel->find($a['faculty_id']);

            $data['allocations'][] = [
                'id' => $a['id'],
                'course_code' => $course ? $course['course_code'] : '',
                'course_name' => $course ? $course['course_name'] : '',
                'faculty_name' => $faculty ? $faculty['user_id'] : '',
                'academic_year' => $a['academic_year'] ?? '',
                'semester' => $a['semester'] ?? ''
            ];
        }

        return view('allocations/list', $data);
    }

    public function create()
    {
        helper('access');
        if (!isAdmin()) return redirect()->to('/allocations');

        $courseModel  = new CourseModel();
        $facultyModel = new FacultyModel();

        return view('allocations/create', [
            'courses' => $courseModel->findAll(),
            'faculties' => $facultyModel->findAll()
        ]);
    }

    public function store()
    {
        helper('access');
        if (!isAdmin()) return redirect()->to('/allocations');

        $model = new CourseAllocationModel();
        $academicYear = currentAcademicYear(); // e.g., 2025-2028

        $model->insert([
            'course_id' => $this->request->getPost('course_id'),
            'faculty_id' => $this->request->getPost('faculty_id'),
            'academic_year' => $academicYear,
            'semester' => $this->request->getPost('semester'),
            'created_by' => session()->get('user_id')
        ]);

        return redirect()->to('/allocations')->with('success','Course allocated successfully');
    }

    public function edit($id)
    {
        helper('access');
        if (!isAdmin()) return redirect()->to('/allocations');

        $model = new CourseAllocationModel();
        $allocation = $model->find($id);

        if (!$allocation || !canEditAllocation($allocation['academic_year'])) {
            return redirect()->to('/allocations')->with('error','Cannot edit past batches');
        }

        $courseModel  = new CourseModel();
        $facultyModel = new FacultyModel();
        return view('allocations/edit', [
            'allocation' => $allocation,
            'courses' => $courseModel->findAll(),
            'faculties' => $facultyModel->findAll()
        ]);
    }

    public function update($id)
    {
        helper('access');
        if (!isAdmin()) return redirect()->to('/allocations');

        $model = new CourseAllocationModel();
        $allocation = $model->find($id);

        if (!$allocation || !canEditAllocation($allocation['academic_year'])) {
            return redirect()->to('/allocations')->with('error','Cannot update past batches');
        }

        $model->update($id, [
            'course_id' => $this->request->getPost('course_id'),
            'faculty_id' => $this->request->getPost('faculty_id'),
            'semester' => $this->request->getPost('semester'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to('/allocations')->with('success','Allocation updated successfully');
    }

    public function delete($id)
    {
        helper('access');
        if (!isAdmin()) return redirect()->to('/allocations');

        $model = new CourseAllocationModel();
        $allocation = $model->find($id);

        if (!$allocation || !canEditAllocation($allocation['academic_year'])) {
            return redirect()->to('/allocations')->with('error','Cannot delete past batches');
        }

        $model->where('id', $id)->delete();

        return redirect()->to('/allocations')->with('success','Allocation deleted');
    }
}
