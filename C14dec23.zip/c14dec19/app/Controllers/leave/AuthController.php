<?php
namespace App\Controllers\leave;
use CodeIgniter\Controller;
use App\Models\leave\Usermodel;
use App\Models\leave\DatasModel;
use App\Models\leave\FacultyModel;
class AuthController extends Controller
{
    public function login(){
        return view('leave/login');
    }

    public function loginPost(){
        $userModel = model(Usermodel::class);
        $username=$this->request->getPost('username');

        $password=$this->request->getPost('password');
     $user = $userModel->where('email', $username)->first();

if(empty($user)){
    return $this->response->redirect('');
}

if($password == $user['password']){  
    
        $session=session();
        $session->set([
            'username'=>$username,
            'id'=>(int)$user['id'],
            'role'=>$user['role'],
            'dept_name'=>$user['dept_name']
        ]);
        $role=$session->get('role');
        if($role=='hod'){
            $facultyModel = new FacultyModel();

    $deptName = $session->get('dept_name');

    $fetcheddata = $facultyModel
        ->select('faculty.*, user.email, user.role')
        ->join('user', 'user.id = faculty.facul_name')
        ->where('user.role', 'staff')
        ->where('user.dept_name', $deptName)
         ->groupBy('faculty.id')
        ->findAll();

    $data['Fetched_Datas_Hod'] = $fetcheddata;

    return view('leaves/index', $data);
        }
        else {
        // STAFF view
        return redirect()->to('leave'); // Redirect staff to their leave page
    }
}
else{
            return $this->response->redirect("dff");
        }

    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
