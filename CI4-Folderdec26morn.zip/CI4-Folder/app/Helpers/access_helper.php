<?php

function isAdmin()
{
    return session()->get('role') === 'admin';
}

function currentAcademicYear()
{
    return '2025-2028';
}

function canEditAllocation($year)
{
    return isAdmin() && $year === currentAcademicYear();
}
