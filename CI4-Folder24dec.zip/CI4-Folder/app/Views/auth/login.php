<h2>Login</h2>
<form method="post" action="<?= base_url('login') ?>">
    <input name="username" placeholder="Username"><br>
    <input name="password" type="password" placeholder="Password"><br>
    <button>Login</button>
</form>
