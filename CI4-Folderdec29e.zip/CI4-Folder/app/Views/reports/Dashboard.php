<!DOCTYPE html>
<html>
<head>
    <title>College Dashboard</title>

    <!-- amCharts -->
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

    <!-- ApexCharts -->
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <style>
        .dashboard { display: flex; flex-wrap: wrap; gap: 20px; }
        .card { width: 400px; height: 300px; padding: 10px; border: 1px solid #ccc; border-radius: 10px; }
    </style>
</head>
<body>

<h2>College Management Dashboard</h2>
<div class="dashboard">

    <!-- 1. Total Students by Department -->
    <div class="card" id="chart1"></div>

    <!-- 2. Fee Collection Summary -->
    <div class="card" id="chart2"></div>

    <!-- 3. Attendance Compliance -->
    <div class="card" id="chart3"></div>

</div>

<script>
am5.ready(function() {

    var root = am5.Root.new("chart1");
    root.setThemes([ am5themes_Animated.new(root) ]);

    var chart = root.container.children.push(
        am5xy.XYChart.new(root, {
            layout: root.verticalLayout
        })
    );

    // Cursor for tooltip
    chart.set("cursor", am5xy.XYCursor.new(root, {}));

    /* ---------------- Y Axis (Department Name) ---------------- */
    var yAxis = chart.yAxes.push(
        am5xy.CategoryAxis.new(root, {
            categoryField: "department",
            renderer: am5xy.AxisRendererY.new(root, {})
        })
    );

    // Y-axis title
    yAxis.children.push(
        am5.Label.new(root, {
            text: "Department Name",
            rotation: -90,
            y: am5.p50,
            centerY: am5.p50
        })
    );

    /* ---------------- X Axis (Student Count) ---------------- */
    var xAxis = chart.xAxes.push(
        am5xy.ValueAxis.new(root, {
            renderer: am5xy.AxisRendererX.new(root, {})
        })
    );

    // X-axis title
    xAxis.children.push(
        am5.Label.new(root, {
            text: "Number of Students",
            x: am5.p50,
            centerX: am5.p50,
            paddingTop: 10
        })
    );

    /* ---------------- Series ---------------- */
    var series = chart.series.push(
        am5xy.ColumnSeries.new(root, {
            xAxis: xAxis,
            yAxis: yAxis,
            valueXField: "total",
            categoryYField: "department",
            tooltip: am5.Tooltip.new(root, {
                labelText: "{categoryY}: {valueX} students"
            })
        })
    );

    series.columns.template.setAll({
        interactive: true,
        tooltipText: "{categoryY}: {valueX} students"
    });

    /* ---------------- Data ---------------- */
    var data = [
        <?php foreach($studentsByDept as $row){ ?>
        { department: "<?= $row['department_name'] ?>", total: <?= $row['total'] ?> },
        <?php } ?>
    ];

    yAxis.data.setAll(data);
    series.data.setAll(data);

});

/* --------------------- 2. Fee Collection Summary (ApexCharts Radial Bar) --------------------- */
var options2 = {
    chart: { type: 'radialBar', height: 300 },
    series: [<?= $feeData['paid'] ?>, <?= $feeData['pending'] ?>],
    labels: ['Paid', 'Pending'],
    plotOptions: { radialBar: { dataLabels: { total: { show: true } } } },
    tooltip: { y: { formatter: val => val + " students" } }
};
new ApexCharts(document.querySelector("#chart2"), options2).render();

/* --------------------- 3. Attendance Compliance (ApexCharts Gauge) --------------------- */
var options3 = {
    chart: { type: 'radialBar', height: 300 },
    series: [<?= $attendancePercent ?>],
    labels: ['Attendance ≥ 75%'],
    plotOptions: { radialBar: { hollow: { size: '60%' }, dataLabels: { value: { formatter: val => val + "%" } } } }
};
new ApexCharts(document.querySelector("#chart3"), options3).render();

</script>

</body>
</html>
