<!DOCTYPE html>
<html>
<head>
    <title>Add Employee</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 400px;
            margin: 50px auto;
            background: #fff;
            padding: 30px 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        form input {
            width: 100%;
            padding: 12px 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }

        form button {
            width: 100%;
            padding: 12px;
            background: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 15px;
            transition: background 0.3s;
        }

        form button:hover {
            background: #218838;
        }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Common validation JS -->
    <script src="<?= base_url('assets/js/jqueryvalidation.js') ?>"></script>
</head>
<body>
    <div class="container">
        <script>
            $(document).ready(function () {
                $("#emp").focus();
            });
        </script>

        <form method="post" action="<?= base_url('/employees/store') ?>">
            <h2>Add Employee</h2>

            <input type="text" name="emp_name" placeholder="Employee Name" id="emp" class="name" required>
            <input type="text" name="department" placeholder="Department" class="name" required>
            <input type="text" name="salary" placeholder="Salary" class="salary-range" required>
            <input type="email" name="email" placeholder="Email" class="email">
            <input type="date" name="date_of_joining" placeholder="Date of Joining">

            <button type="submit">Save Employee</button>
        </form>
    </div>
</body>
</html>
