<!DOCTYPE html>
<html>
<head>
    <title>Apply Leave</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
</head>
<body>

<!-- ===== HEADER ===== -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">ERP System</a>
    <div class="collapse navbar-collapse justify-content-end">
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <?= session()->get('username') ?>
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
            <li><a class="dropdown-item" href="#">Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?= base_url('logout') ?>">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-4">
    <h2>Apply Leave</h2>

    <!-- ===== APPLY LEAVE FORM ===== -->
    <div class="card p-4 mb-4">
        <form method="post" action="<?= base_url('leave/store') ?>">
            <div class="mb-3">
                <label class="form-label">Leave Type</label>
                <select class="form-select" name="type" required>
                    <option value="casual">Casual</option>
                    <option value="medical">Medical</option>
                    <option value="earned">Earned</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">From Date</label>
                <input type="date" class="form-control" name="from_date" required>
            </div>

            <div class="mb-3">
                <label class="form-label">To Date</label>
                <input type="date" class="form-control" name="to_date" required>
            </div>

            <button type="submit" class="btn btn-success">Submit</button>
            <a href="<?= base_url('leave') ?>" class="btn btn-secondary">Back</a>
        </form>
    </div>

    <!-- ===== PAST LEAVES TABLE ===== -->
    <?php if (!empty($myLeaves ?? [])): ?>
    <div class="card p-4">
        <h4>My Leave Requests</h4>
        <table id="leavesTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Leave Type</th>
                    <th>From Date</th>
                    <th>To Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; foreach ($myLeaves as $leave): ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td><?= esc($leave['type']) ?></td>
                    <td><?= esc($leave['from_date']) ?></td>
                    <td><?= esc($leave['to_date']) ?></td>
                    <td>
                        <span class="<?= esc($leave['status']) ?>"><?= ucfirst($leave['status']) ?></span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- ===== SCRIPTS ===== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script>
$(document).ready(function() {
    $('#leavesTable').DataTable({
        "ordering": true,
        "searching": true,
        "pageLength": 5
    });
});
</script>

<style>
/* Status colors */
.pending { color: orange; font-weight: bold; }
.approved { color: green; font-weight: bold; }
.rejected { color: red; font-weight: bold; }
</style>

</body>
</html>
