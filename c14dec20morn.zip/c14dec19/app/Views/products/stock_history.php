<!DOCTYPE html>
<html>
<head>
    <title>Stock History</title>

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
        }

        .header {
            background: #007bff;
            color: #fff;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
        }

        .container {
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }

        th {
            background: #f1f1f1;
        }

        a {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>

<div class="header">
    <h2>Stock History</h2>
    <div>
        Role: <?= session()->get('role') ?>
    </div>
</div>

<div class="container">

<table>
    <tr>
        <th>ID</th>
        <th>Product ID</th>
        <th>Change Qty</th>
        <th>Stock Before</th>
        <th>Stock After</th>
        <th>Changed By</th>
        <th>Date</th>
    </tr>

    <?php if (!empty($logs)): ?>
        <?php foreach ($logs as $log): ?>
        <tr>
            <td><?= $log['id'] ?></td>
            <td><?= $log['product_id'] ?></td>
            <td><?= $log['change_qty'] ?></td>
            <td><?= $log['stock_before'] ?></td>
            <td><?= $log['stock_after'] ?></td>
            <td><?= $log['changed_by'] ?></td>
            <td><?= $log['created_at'] ?></td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="7">No history found</td>
        </tr>
    <?php endif; ?>
</table>

<a href="/products">⬅ Back to Products</a>

</div>
</body>
</html>
