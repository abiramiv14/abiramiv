<?php

namespace App\Controllers;

use App\Models\ContactModel;

class ContactController extends BaseController
{
    public function index()
    {
        return view('contact_form');
    }

    public function save()
    {
        $contactModel = new ContactModel();
        $contactModel->insert([
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'message' => $this->request->getPost('message')
        ]);

        return view('contact_success');
    } 

}
