<?php
namespace App\Controllers\ticket;

use App\Models\ticket\UserModel;
use CodeIgniter\Controller;

class AuthController extends Controller
{
    public function login()
    {
        return view('authpages/login_view');
    }

    public function loginPost()
    {
        if ($this->request->getMethod() === 'post') {

            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');

            $userModel = new UserModel();
            $user = $userModel->where('username', $username)->first();

            if ($user && $password == $user['password']) {

                session()->set([
                    'username'   => $user['username'],
                    'role'       => $user['role'],
                    'isLoggedIn' => true
                ]);

                // role-based redirect
                if ($user['role'] === 'admin') {
                    return redirect()->to('/tickets');
                } else {
                    return redirect()->to('/tickets/create');
                }

            } else {
                return redirect()->back()->with('error', 'Invalid Credentials');
            }
        }

        return redirect()->to('/login');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
