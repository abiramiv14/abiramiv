<?php namespace App\Models;

use CodeIgniter\Model;

class StudentFeeModel extends Model
{
    protected $table = 'student_fees';
    protected $allowedFields = [
        'student_id','semester','fee_amount','paid_amount',
        'due_amount','payment_mode','payment_date',
        'receipt_no','created_by'
    ];
}
