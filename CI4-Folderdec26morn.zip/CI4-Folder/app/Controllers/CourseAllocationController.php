<?php namespace App\Controllers;

use App\Models\CourseAllocationModel;
use App\Models\FacultyModel;
use App\Models\CourseModel;

class CourseAllocationController extends BaseController
{
    /* =========================================================
       INDEX – LIST PAGE
       ========================================================= */
    public function index()
    {
        helper('access');

        $allocationModel = new CourseAllocationModel();
        $facultyModel    = new FacultyModel();
        $courseModel     = new CourseModel();

        // -------------------------------
        // FACULTY LOGIN → see only own batch & subjects
        // -------------------------------
        if (session()->get('role') === 'faculty') {

            // convert user_id → faculty_id
            $faculty = $facultyModel
                ->where('user_id', session()->get('user_id'))
                ->first();

            $allocations = $allocationModel
                ->where('faculty_id', $faculty['id'])
                ->findAll();

        }
        // -------------------------------
        // ADMIN LOGIN → see all batches
        // -------------------------------
        else {
            $allocations = $allocationModel->findAll();
        }

        // prepare data for view
        $data['allocations'] = [];

        foreach ($allocations as $a) {

            $course  = $courseModel->find($a['course_id']);
            $faculty = $facultyModel->find($a['faculty_id']);

            $data['allocations'][] = [
                'id'            => $a['id'],
                'course_code'   => $course['course_code'],
                'course_name'   => $course['course_name'],
                'faculty_name'  => 'Faculty ID '.$faculty['id'],
                'academic_year' => $a['academic_year'],
                'semester'      => $a['semester']
            ];
        }

        return view('allocations/list', $data);
    }

    /* =========================================================
       CREATE – NEW ALLOCATION FORM
       ========================================================= */
    public function create()
    {
        helper('access');

        // only admin allowed
        if (!isAdmin()) {
            return redirect()->to('/allocations');
        }

        $courseModel  = new CourseModel();
        $facultyModel = new FacultyModel();

        return view('allocations/create', [
            'courses'   => $courseModel->findAll(),
            'faculties' => $facultyModel->findAll()
        ]);
    }

    /* =========================================================
       STORE – SAVE NEW ALLOCATION
       ========================================================= */
    public function store()
    {
        helper('access');

        if (!isAdmin()) {
            return redirect()->to('/allocations');
        }

        // allow only CURRENT academic year
        if ($this->request->getPost('academic_year') !== currentAcademicYear()) {
            return redirect()->back()->with('error', 'Only current batch can be allocated');
        }

        $model = new CourseAllocationModel();

        $model->insert([
            'course_id'    => $this->request->getPost('course_id'),
            'faculty_id'   => $this->request->getPost('faculty_id'),
            'academic_year'=> currentAcademicYear(),
            'semester'     => $this->request->getPost('semester'),
            'created_by'   => session()->get('user_id')
        ]);

        return redirect()->to('/allocations')
            ->with('success', 'Course allocated successfully');
    }

    /* =========================================================
       EDIT – EDIT ALLOCATION (ONLY CURRENT BATCH)
       ========================================================= */
    public function edit($id)
    {
        helper('access');

        if (!isAdmin()) {
            return redirect()->to('/allocations');
        }

        $model      = new CourseAllocationModel();
        $allocation = $model->find($id);

        if (!canEditAllocation($allocation['academic_year'])) {
            return redirect()->to('/allocations')
                ->with('error', 'Cannot edit past batches');
        }

        $courseModel  = new CourseModel();
        $facultyModel = new FacultyModel();

        return view('allocations/edit', [
            'allocation' => $allocation,
            'courses'    => $courseModel->findAll(),
            'faculties'  => $facultyModel->findAll()
        ]);
    }

    /* =========================================================
       UPDATE – SAVE EDITED DATA
       ========================================================= */
    public function update($id)
    {
        helper('access');

        if (!isAdmin()) {
            return redirect()->to('/allocations');
        }

        $model      = new CourseAllocationModel();
        $allocation = $model->find($id);

        if (!canEditAllocation($allocation['academic_year'])) {
            return redirect()->to('/allocations')
                ->with('error', 'Cannot update past batches');
        }

        $model->update($id, [
            'course_id'  => $this->request->getPost('course_id'),
            'faculty_id' => $this->request->getPost('faculty_id'),
            'semester'   => $this->request->getPost('semester'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to('/allocations')
            ->with('success', 'Allocation updated successfully');
    }

    /* =========================================================
       DELETE – REMOVE ALLOCATION
       ========================================================= */
    public function delete($id)
    {
        helper('access');

        if (!isAdmin()) {
            return redirect()->to('/allocations');
        }

        $model      = new CourseAllocationModel();
        $allocation = $model->find($id);

        if (!canEditAllocation($allocation['academic_year'])) {
            return redirect()->to('/allocations')
                ->with('error', 'Cannot delete past batches');
        }

        $model->delete($id);

        return redirect()->to('/allocations')
            ->with('success', 'Allocation deleted');
    }
}
