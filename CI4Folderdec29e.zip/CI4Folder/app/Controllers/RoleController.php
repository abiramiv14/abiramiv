<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class RoleController extends Controller
{
    // Show login page
    public function login()
    {
        helper(['form','url']);
        return view('auth/login');
    }

    // Handle login
    public function setRole()
    {
        helper(['form','url']);
        $session = session();

        $email    = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $role     = $this->request->getPost('role'); // dropdown value

        $model = new UserModel();
        $user  = $model->where('email', $email)->first();

        // 🔐 CHECK EMAIL + PASSWORD + ROLE
        if ($user && 
            $password == $user['password'] && 
            $role == $user['role']) {

            $session->set([
                'email'      => $user['email'],
                'role'       => $user['role'], // 1 or 2
                'isLoggedIn' => true
            ]);

           
            if ($user['role'] == 1) {
                return redirect()->to('/adminPage');
            } else {
                return redirect()->to('/userPage');
            }

        } else {
            $session->setFlashdata('error', 'Invalid Email, Password or Role');
            return redirect()->to('/login');
        }
    }

    // Admin page
    public function adminPage()
    {
        if (!session()->get('isLoggedIn') || session()->get('role') != 1) {
            return redirect()->to('/login');
        }
        return view('admin/adminPage');
    }

    // User page
    public function userPage()
    {
        if (!session()->get('isLoggedIn') || session()->get('role') != 2) {
            return redirect()->to('/login');
        }
        return view('user1/userPage');
    }

    // Logout
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
