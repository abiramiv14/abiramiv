<?php
namespace App\Models\leave;
use CodeIgniter\Model;

class LeaveModel extends Model
{
    protected $table = 'faculty_leave';
    protected $primaryKey='id';
    protected $allowedFields = [
        'faculty_name','employee_code','department',
        'leave_type','from_date','to_date','status'
    ];
} 

