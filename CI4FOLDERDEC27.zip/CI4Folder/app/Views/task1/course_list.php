<!DOCTYPE html>
<html>
<head>
    <title>Registered Courses</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:90%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#ffc107; color:#000; }
        .editing-row { background-color: #fff3cd !important; }
        .edit-field { width:100%; padding:3px; display:none; }
        .action-btn { cursor:pointer; border:none; background:none; }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
</head>
<body>

<h2 style="text-align:center;">Registered Courses</h2>
<div style="width:80%; margin:20px auto; text-align:right;">
    <a href="<?= base_url('/courses/create') ?>" style="padding:10px 15px; background:#28a745; color:#fff; text-decoration:none; border-radius:4px;">
        + Add Course
    </a>
</div>

<table id="courseTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Student Name</th>
            <th>Course Name</th>
            <th>Semester</th>
            <th>Fees</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
<?php foreach ($registrations as $row): ?>
<tr data-id="<?= $row['course_id'] ?>">
    <td><?= $row['course_id'] ?></td>
    <td><span class="text"><?= $row['student_name'] ?></span>
        <input type="text" name="student_name" class="edit-field" value="<?= $row['student_name'] ?>"></td>
    <td><span class="text"><?= $row['course_name'] ?></span>
        <input type="text" name="course_name" class="edit-field" value="<?= $row['course_name'] ?>"></td>
    <td><span class="text"><?= $row['semester'] ?></span>
        <input type="text" name="semester" class="edit-field" value="<?= $row['semester'] ?>"></td>
    <td><span class="text"><?= $row['fees'] ?></span>
        <input type="text" name="fees" class="edit-field" value="<?= $row['fees'] ?>"></td>
    <td><span class="text"><?= $row['email'] ?></span>
        <input type="email" name="email" class="edit-field" value="<?= $row['email'] ?>"></td>
    <td>
        <button class="action-btn edit-btn"><i class="fa fa-pen" style="color:blue;"></i></button>
        <button class="action-btn save-btn" style="display:none;"><i class="fa fa-check" style="color:green;"></i></button>
        <button class="action-btn cancel-btn" style="display:none;"><i class="fa fa-times" style="color:orange;"></i></button>
        <a href="<?= base_url('courses/delete/'.$row['course_id']) ?>" onclick="return confirm('Delete this course?')">
            <i class="fa fa-trash" style="color:red;"></i>
        </a>
    </td>
</tr>
<?php endforeach; ?>
    </tbody>
</table>

<script>
$(document).ready(function(){
    $('#courseTable').DataTable();

    // Click edit
    $(document).on('click', '.edit-btn', function(){
        let row = $(this).closest('tr');
        row.addClass('editing-row');
        row.find('.text').hide();
        row.find('.edit-field').show();
        row.find('.edit-btn').hide();
        row.find('.save-btn, .cancel-btn').show();
    });

    // Click cancel
    $(document).on('click', '.cancel-btn', function(){
        let row = $(this).closest('tr');
        row.removeClass('editing-row');
        row.find('.edit-field').each(function(){
            $(this).val($(this).siblings('.text').text());
        });
        row.find('.edit-field').hide();
        row.find('.text').show();
        row.find('.edit-btn').show();
        row.find('.save-btn, .cancel-btn').hide();
    });

    // Click save
    $(document).on('click', '.save-btn', function(){
        let row = $(this).closest('tr');
        let id = row.data('id');
        let data = {};
        row.find('.edit-field').each(function(){
            data[$(this).attr('name')] = $(this).val();
        });

        // AJAX POST request to update row
        $.post("<?= base_url('courses/update') ?>/"+id, data, function(response){
            // Update displayed text
            row.find('.edit-field').each(function(){
                $(this).siblings('.text').text($(this).val());
            });
            row.removeClass('editing-row');
            row.find('.edit-field').hide();
            row.find('.text').show();
            row.find('.edit-btn').show();
            row.find('.save-btn, .cancel-btn').hide();
        });
    });
});
</script>

</body>
</html>
