<!DOCTYPE html>
<html>
<head>
    <title>Department-wise Student Strength</title>

    <!-- amCharts CDN -->
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
</head>
<body>

<h2>Department-wise Student Strength</h2>
<div id="chartdiv" style="width: 100%; height: 500px;"></div>

<script>
am5.ready(function() {

var root = am5.Root.new("chartdiv");
root.setThemes([ am5themes_Animated.new(root) ]);

var chart = root.container.children.push(
    am5xy.XYChart.new(root, {
        panX: false,
        panY: false,
        wheelX: "none",
        wheelY: "none"
    })
);

// Cursor (IMPORTANT for hover)
chart.set("cursor", am5xy.XYCursor.new(root, {}));

var xAxis = chart.xAxes.push(
    am5xy.CategoryAxis.new(root, {
        categoryField: "department",
        renderer: am5xy.AxisRendererX.new(root, {})
    })
);

var yAxis = chart.yAxes.push(
    am5xy.ValueAxis.new(root, {
        renderer: am5xy.AxisRendererY.new(root, {})
    })
);

var series = chart.series.push(
    am5xy.ColumnSeries.new(root, {
        name: "Students",
        xAxis: xAxis,
        yAxis: yAxis,
        valueYField: "count",
        categoryXField: "department"
    })
);

// ✅ TOOLTIP FIX (THIS LINE IS THE KEY)
series.columns.template.setAll({
    tooltipText: "{categoryX}: {valueY}",
    interactive: true
});

// PHP → JS data
var data = [
<?php foreach($chartData as $row){ ?>
    {
        department: "<?= $row['department_name'] ?>",
        count: <?= $row['total'] ?>
    },
<?php } ?>
];

xAxis.data.setAll(data);
series.data.setAll(data);

}); // end am5
</script>

</body>
</html>
