Chart.register(ChartDataLabels);
// --- CONSTANTS & CONFIG ---
const COLORS = {
    completed: '#22c55e',
    inProgress: '#eab308',
    yetToStart: '#f59e0b',
    halted: '#ef4444',
    blue: '#3b82f6',
    gray: '#94a3b8'
};

const ICONS = {
    calendar: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>',
    check: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
    clock: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
    pause: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>'
};

// --- STATE & DATA GENERATION ---
let appState = {
    selectedPeriod: 'Feb26',
    data: null,
    charts: {} // Store chart instances
};

const generateMockData = (period) => {
    const baseDate = period === "Feb26" ? "2026-02" : period === "Mar26" ? "2026-03" : "2026-04";

    const summary = {
        completed: period === "Feb26" ? 125 : period === "Mar26" ? 98 : 67,
        inProgress: period === "Feb26" ? 45 : period === "Mar26" ? 52 : 38,
        yetToStart: period === "Feb26" ? 30 : period === "Mar26" ? 50 : 95,
        halted: period === "Feb26" ? 5 : period === "Mar26" ? 8 : 12,
    };

    return {
        summary,
        drillDownData: [
            { date: `${baseDate}-01`, count: 12 },
            { date: `${baseDate}-05`, count: 18 },
            { date: `${baseDate}-10`, count: 25 },
            { date: `${baseDate}-15`, count: 30 },
            { date: `${baseDate}-20`, count: 22 },
            { date: `${baseDate}-25`, count: 18 },
        ],
        courseData: [
            { courseCode: "CS101", completed: 45, inProgress: 10, yetToStart: 5, halted: 2 },
            { courseCode: "MATH201", completed: 38, inProgress: 12, yetToStart: 8, halted: 1 },
            { courseCode: "PHY301", completed: 42, inProgress: 8, yetToStart: 7, halted: 2 },
            { courseCode: "ENG101", completed: 50, inProgress: 5, yetToStart: 3, halted: 0 },
            { courseCode: "BIO202", completed: 35, inProgress: 10, yetToStart: 7, halted: 0 },
            { courseCode: "CHEM301", completed: 40, inProgress: 8, yetToStart: 5, halted: 1 },
        ],
        examDayData: [
            { day: "Day 1", scriptCount: 45, completedCount: 35 },
            { day: "Day 2", scriptCount: 52, completedCount: 48 },
            { day: "Day 3", scriptCount: 38, completedCount: 38 },
            { day: "Day 4", scriptCount: 48, completedCount: 45 },
            { day: "Day 5", scriptCount: 42, completedCount: 42 },
        ],
        evaluatedData: {
            evaluated: period === "Feb26" ? 150 : period === "Mar26" ? 130 : 100,
            nonEvaluated: period === "Feb26" ? 55 : period === "Mar26" ? 75 : 70,
            // mock student list for modal
            studentList: [
                { sno: 1, regNo: "R001", name: "Alice", course: "CS101", status: "Pass" },
                { sno: 2, regNo: "R002", name: "Bob", course: "MATH201", status: "Fail" },
                // ... more rows
            ]
        }
        ,
        studentsByStatus: {
            scheduled: [
                { batch: "2022-2025", courseCode: "CS101", regNo: "R001", name: "Alice Johnson", mobile: "9876543210", email: "alice@gmail.com" },
                { batch: "2022-2025", courseCode: "MATH201", regNo: "R002", name: "Bob Smith", mobile: "9876501234", email: "bob@gmail.com" },
                { batch: "2022-2025", courseCode: "PHY301", regNo: "R010", name: "Charlie Brown", mobile: "9876599999", email: "charlie@gmail.com" },
                { batch: "2022-2025", courseCode: "ENG101", regNo: "R020", name: "Diana Prince", mobile: "9876512345", email: "diana@gmail.com" },
                { batch: "2022-2025", courseCode: "BIO202", regNo: "R030", name: "Edward Norton", mobile: "9876522222", email: "edward@gmail.com" },
                // Add more students as needed
            ],
            completed: [
                {
                    batch: "2022-2025",
                    courseCode: "CS101",
                    regNo: "R001",
                    name: "Alice Johnson",
                    mobile: "9876543210",
                    email: "alice@gmail.com"
                },
                {
                    batch: "2022-2025",
                    courseCode: "MATH201",
                    regNo: "R002",
                    name: "Bob Smith",
                    mobile: "9876501234",
                    email: "bob@gmail.com"
                }
            ],
            inProgress: [
                {
                    batch: "2022-2025",
                    courseCode: "PHY301",
                    regNo: "R010",
                    name: "Charlie Brown",
                    mobile: "9876599999",
                    email: "charlie@gmail.com"
                }
            ],
            yetToStart: [
                {
                    batch: "2022-2025",
                    courseCode: "ENG101",
                    regNo: "R020",
                    name: "Diana Prince",
                    mobile: "9876512345",
                    email: "diana@gmail.com"
                }
            ],
            halted: [
                {
                    batch: "2022-2025",
                    courseCode: "BIO202",
                    regNo: "R030",
                    name: "Edward Norton",
                    mobile: "9876522222",
                    email: "edward@gmail.com"
                }
            ]
        }



    }

};


// --- CHART JS HELPERS ---

// Destroy existing charts to prevent memory leaks and overlapping renders
function destroyCharts() {
    Object.values(appState.charts).forEach(chart => {
        if (chart) chart.destroy();
    });
    appState.charts = {};
}

function createLegend(containerId, data, keys, colors) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    const total = data.reduce((acc, curr) => acc + curr.value, 0);

    keys.forEach((key, index) => {
        const item = data.find(d => d.key === key);
        const value = item ? item.value : 0;
        const percent = total > 0 ? ((value / total) * 100).toFixed(1) : 0;

        const el = document.createElement('div');
        el.className = 'legend-item';
        el.innerHTML = `
            <div class="legend-dot" style="background-color: ${colors[key]}"></div>
            <span>${formatLabel(key)}: ${value} (${percent}%)</span>
        `;
        // Add click handler for drilldown on Completed segment
        if (key === 'completed') {
            el.style.cursor = 'pointer';
            el.onclick = () => openDrillDown();
        }
        container.appendChild(el);
    });
}

function formatLabel(key) {
    if (key === 'yetToStart') return 'Yet to Start';
    return key.charAt(0).toUpperCase() + key.slice(1);
}

// --- RENDER FUNCTIONS ---

function renderSummaryCards() {
    const container = document.getElementById('summaryCardsContainer');
    const d = appState.data.summary;
    const total = d.completed + d.inProgress + d.yetToStart + d.halted;

    const cardsConfig = [
        { key: "scheduled", label: "Scheduled Exam", value: total, icon: ICONS.calendar, colorClass: "bg-gray-soft", textClass: "text-gray" },
        { key: "completed", label: "Completed", value: d.completed, icon: ICONS.check, colorClass: "bg-green-soft", textClass: "text-green" },
        { key: "inProgress", label: "Ongoing", value: d.inProgress, icon: ICONS.clock, colorClass: "bg-yellow-soft", textClass: "text-yellow" },
        { key: "yetToStart", label: "Yet To Start", value: d.yetToStart, icon: ICONS.pause, colorClass: "bg-light-brown", textClass: "text-light-brown" },

        { key: "halted", label: "Halted", value: d.halted, icon: ICONS.pause, colorClass: "bg-red-soft", textClass: "text-red" },
    ];


    container.innerHTML = cardsConfig.map(c => `
        <div class="card stat-card ${c.colorClass}" 
 style="border:none; cursor:pointer;"
 onclick="openStatCardModal('${c.key}')">
            <div class="stat-content">
                <div class="stat-label">${c.label}</div>
                <div class="stat-value ${c.textClass}">${c.value}</div>
            </div>
            <div class="stat-icon ${c.textClass}">
                ${c.icon}
            </div>
        </div>
    `).join('');
}
function renderCourseProgress() {
    const container = document.getElementById('courseStatsContainer');
    container.innerHTML = `<canvas id="courseHeatmapChart" style="width:100%; height:300px;"></canvas>`;

    const courses = appState.data.courseData;
    const statuses = ['Completed', 'In Progress', 'Yet to Start', 'Halted'];

    const data = [];
    courses.forEach((course) => {
        data.push({ x: 'Completed', y: course.courseCode, v: course.completed });
        data.push({ x: 'In Progress', y: course.courseCode, v: course.inProgress });
        data.push({ x: 'Yet to Start', y: course.courseCode, v: course.yetToStart });
        data.push({ x: 'Halted', y: course.courseCode, v: course.halted });

    });



    const ctx = document.getElementById('courseHeatmapChart').getContext('2d');

    if (appState.charts.courseHeatmap) appState.charts.courseHeatmap.destroy();

    appState.charts.courseHeatmap = new Chart(ctx, {
        type: 'matrix',
        data: {
            datasets: [{
                label: 'Course Progress Heatmap',
                data: data,
                backgroundColor: function (ctx) {
                    const value = ctx.dataset.data[ctx.dataIndex].v;
                    if (value > 40) return COLORS.completed;
                    if (value > 20) return 'yellow';
                    if (value > 5) return COLORS.yetToStart;
                    return COLORS.halted;
                },
                borderWidth: 4,
                borderColor: '#ffffff',
                width: ({ chart }) => (chart.chartArea || {}).width / statuses.length - 20,
                height: ({ chart }) => (chart.chartArea || {}).height / courses.length - 10

            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    type: 'category',
                    position: 'top',
                    labels: ['Completed', 'In Progress', 'Yet to Start', 'Halted'],
                    grid: { display: false },
                    ticks: {
                        font: { size: 12, weight: 'bold' },
                        padding: 10 // <-- increase this to move labels UP
                    }
                },
                y: {
                    type: 'category',
                    labels: courses.map(c => c.courseCode), // courses on Y
                }
            },
            plugins: {
                datalabels: {
                    color: '#fffff',        // color of text, choose black or white depending on bg
                    anchor: 'center',     // center the label in the box
                    align: 'center',
                    font: {
                        weight: 'bold',
                        size: 12
                    },
                    formatter: function (value, ctx) {
                        return value.v;   // show the 'v' value in each cell
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function (ctx) {
                            const course = ctx.raw.y;
                            const status = ctx.raw.x;
                            const value = ctx.raw.v;
                            return `${course} - ${status}: ${value}`;
                        }
                    }
                },
                legend: { display: false }
            }
        }
    });
}


function openStatCardModal(statusKey) {
    const modal = document.getElementById('statCardModal');
    const tbody = document.querySelector('#statCardTable tbody');

    // Clear old rows
    tbody.innerHTML = '';

    const students = appState.data.studentsByStatus[statusKey] || [];

    students.forEach((s, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${index + 1}</td>
            <td>${s.regNo}</td>
            <td>${s.batch}</td>
            <td>${s.courseCode}</td>
            <td>${s.name}</td>
            <td>${s.mobile}</td>
            <td>${s.email}</td>
        `;
        tbody.appendChild(tr);
    });

    // Initialize DataTable
    if ($.fn.DataTable.isDataTable('#statCardTable')) {
        $('#statCardTable').DataTable().destroy();
    }

    $('#statCardTable').DataTable({
        pageLength: 10,
        lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
        order: [[0, 'asc']],
    });

    modal.classList.add('active');
}

function toggleStatCardModal(show) {
    const modal = document.getElementById('statCardModal');
    if (show) {
        modal.classList.add('active');
    } else {
        modal.classList.remove('active');
        if ($.fn.DataTable.isDataTable('#statCardTable')) {
            $('#statCardTable').DataTable().destroy();
        }
    }
}


function openStudentModal() {
    const modal = document.getElementById('studentModal');
    const tbody = document.querySelector('#studentTable tbody');

    // Destroy existing DataTable if it exists
    if ($.fn.DataTable.isDataTable('#studentTable')) {
        $('#studentTable').DataTable().destroy();
    }

    tbody.innerHTML = '';

    const students = appState.data.evaluatedData.studentList || [];

    students.forEach((student, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${index + 1}</td>
            <td>${student.regNo}</td>
            <td>${student.name}</td>
            <td>${student.course}</td>
            <td>${student.status}</td>
        `;
        tbody.appendChild(tr);
    });

    $('#studentTable').DataTable({
        pageLength: 10,
        lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
        order: [[0, 'asc']],
        language: {
            search: "Search:",
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ students",
            infoEmpty: "Showing 0 to 0 of 0 students",
            infoFiltered: "(filtered from _MAX_ total students)",
            paginate: {
                first: "First",
                last: "Last",
                next: "Next",
                previous: "Previous"
            }
        }
    });

    modal.classList.add('active');
}


function toggleStudentModal(show) {
    const modal = document.getElementById('studentModal');
    if (show) {
        modal.classList.add('active');
    } else {
        // Add closing class for animation
        modal.classList.add('closing');

        // Wait for animation to complete before hiding
        setTimeout(() => {
            modal.classList.remove('active');
            modal.classList.remove('closing');

            // Destroy DataTable when closing modal
            if ($.fn.DataTable.isDataTable('#studentTable')) {
                $('#studentTable').DataTable().destroy();
            }
        }, 300); // Match the animation duration
    }
}


let currentChartType = 'count'; // default

function renderSummaryChart() {
    const d = appState.data.summary;
    const labels = ['Completed', 'In Progress', 'Yet to Start', 'Halted'];
    const valuesCount = [d.completed, d.inProgress, d.yetToStart, d.halted];
    const total = valuesCount.reduce((a, b) => a + b, 0);
    const valuesPercent = valuesCount.map(v => total > 0 ? Number(((v / total) * 100).toFixed(1)) : 0);
    const bgColors = [COLORS.completed, COLORS.inProgress, COLORS.yetToStart, COLORS.halted];
    const keys = ['completed', 'inProgress', 'yetToStart', 'halted'];
    const chartData = labels.map((l, i) => ({ name: l, value: valuesCount[i], key: keys[i] }));

    const ctx = document.getElementById('summaryToggleChart').getContext('2d');

    if (appState.charts.summaryToggle) appState.charts.summaryToggle.destroy();

    appState.charts.summaryToggle = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: currentChartType === 'count' ? valuesCount : valuesPercent,
                backgroundColor: bgColors,
                borderWidth: 0
            }]
        },
        plugins: [ChartDataLabels],
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => currentChartType === 'count'
                            ? `${ctx.label}: ${ctx.raw}`
                            : `${ctx.label}: ${ctx.raw}%`
                    }
                },
                datalabels: {
                    color: '#000',
                    font: { weight: 'bold', size: 12 },
                    formatter: (value) => currentChartType === 'count' ? value : value + '%'
                }
            },
            onClick: (e, elements) => {
                if (elements.length > 0 && elements[0].index === 0) openDrillDown(); // Completed
            }
        }
    });

    createLegend('summaryLegendToggle', chartData, keys, COLORS);
}

// Toggle button function
function toggleSummaryChart(type) {
    currentChartType = type;

    document.getElementById('btnCount').classList.toggle('active-btn', type === 'count');
    document.getElementById('btnPercent').classList.toggle('active-btn', type === 'percent');

    renderSummaryChart();
}



function renderEvaluatedChart() {
    const data = appState.data.evaluatedData;
    const ctx = document.getElementById('evaluatedPieChart').getContext('2d');

    if (appState.charts.evaluatedPie) appState.charts.evaluatedPie.destroy();

    appState.charts.evaluatedPie = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Evaluated', 'Non-Evaluated'],
            datasets: [{
                data: [data.evaluated, data.nonEvaluated],
                backgroundColor: [COLORS.completed, COLORS.gray],
                borderWidth: 0
            }]
        },
        plugins: [ChartDataLabels],
        options: {
            responsive: true,
            maintainAspectRatio: false,


            onClick: (e, elements) => {
                if (elements.length > 0) {
                    openStudentModal(); // show table for ANY donut click
                }
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    align: 'center',
                    labels: { padding: 20, paddingTop: 90 }
                },
                layout: {
                    padding: {
                        top: 90
                    }
                },
                datalabels: {
                    color: '#fff',

                    font: { weight: 'bold', size: 12 },
                    formatter: (value) => value
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => `${ctx.label}: ${ctx.raw}`
                    }
                }
            }
        }

    });
}


function renderBottomRow() {
    // Bar Chart
    const barData = appState.data.examDayData;
    const ctxBar = document.getElementById('examDayBarChart').getContext('2d');
    appState.charts.bar = new Chart(ctxBar, {
        type: 'line',
        data: {
            labels: barData.map(d => d.day),
            datasets: [
                {
                    label: 'Evaluated Scripts',
                    data: barData.map(d => d.completedCount),
                    borderColor: COLORS.completed,
                    backgroundColor: 'rgba(34, 197, 94, 0.2)', // optional shaded area
                    tension: 0.4,      // smooth curve
                    fill: true,        // fill under curve
                    pointRadius: 5,
                    pointHoverRadius: 7
                }
            ]
        },
        plugins: [ChartDataLabels],
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, grid: { borderDash: [3, 3] } },
                x: { grid: { display: false } }
            },
            plugins: {
                legend: { position: 'bottom' },
                datalabels: {    // << ADD THIS
                    anchor: 'end',
                    align: 'end',
                    color: '#fff',
                    font: { weight: 'bold', size: 12 }
                }
            }
        }
    });

    // Total Pie Chart & Metrics
    const d = appState.data.summary;

    const totalScheduled =
        d.completed + d.inProgress + d.yetToStart + d.halted;

    const totalCompleted = d.completed;


    // Update Metrics Text
    document.getElementById('metricScheduled').innerText = totalScheduled;
    document.getElementById('metricCompleted').innerText = totalCompleted;
    document.getElementById('metricRate').innerText =
        totalScheduled > 0
            ? ((totalCompleted / totalScheduled) * 100).toFixed(1) + '%'
            : '0%';


    const ctxTotalPie = document.getElementById('totalPieChart').getContext('2d');
    appState.charts.totalPie = new Chart(ctxTotalPie, {
        type: 'pie',
        data: {
            labels: ['Completed', 'Remaining'],
            datasets: [{
                data: [totalCompleted, totalScheduled - totalCompleted],
                backgroundColor: [COLORS.completed, COLORS.gray],
                borderWidth: 0
            }]
        },
        plugins: [ChartDataLabels],
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' },
                datalabels: {    // << ADD THIS
                    anchor: 'end',
                    align: 'end',
                    color: '#000',
                    font: { weight: 'bold', size: 12 }
                }
            }
        }
    });
}

function renderDrillDownChart() {
    const data = appState.data.drillDownData;
    const ctx = document.getElementById('drillDownChart').getContext('2d');

    // Destroy previous instance if exists
    if (appState.charts.drillDown) {
        appState.charts.drillDown.destroy();
    }

    appState.charts.drillDown = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.date),
            datasets: [{
                label: 'Completed Count',
                data: data.map(d => d.count),
                backgroundColor: COLORS.completed,
                borderRadius: 4
            }]
        },
        plugins: [ChartDataLabels],
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, grid: { borderDash: [3, 3] } },
                x: { grid: { display: false } }
            }
        }
    });
}

// --- INTERACTIONS ---

function openDrillDown() {
    document.getElementById('drillDownModal').classList.add('active');
    renderDrillDownChart();
}

function toggleModal(show) {
    const modal = document.getElementById('drillDownModal');
    if (show) {
        modal.classList.add('active');
    } else {
        modal.classList.remove('active');
    }
}

function handlePeriodChange(e) {
    appState.selectedPeriod = e.target.value;
    updateDashboard();
}

function updateDashboard() {
    appState.data = generateMockData(appState.selectedPeriod);

    destroyCharts();

    renderSummaryCards();
    renderSummaryChart();
    renderCourseProgress(); // only this
    renderBottomRow();
    renderEvaluatedChart();
}

window.addEventListener('DOMContentLoaded', () => {
    document.getElementById('periodSelect').addEventListener('change', handlePeriodChange);

    appState.data = generateMockData(appState.selectedPeriod);
    renderSummaryCards();
    renderSummaryChart();
    renderCourseProgress(); // only this
    renderBottomRow();
    renderEvaluatedChart();
});
