<?php
namespace app\Models\task1;
use CodeIgniter\Controller;
use CodeIgniter\Model;
class StudentModel extends Model
{
    protected $table='students';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'student_name',
        'email',
        'phone',
        'course',
        'city'
    ];
}