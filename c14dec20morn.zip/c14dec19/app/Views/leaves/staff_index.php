<!DOCTYPE html>
<html>
<head>
    <title>My Leave Requests</title>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #333; padding: 8px; text-align: center; }
        .pending { color: orange; font-weight: bold; }
        .approved { color: green; font-weight: bold; }
        .rejected { color: red; font-weight: bold; }
        .disabled { color: gray; pointer-events: none; }
    </style>
</head>
<body>

<h2>My Leave Requests</h2>

<a href="<?= base_url('leave/create') ?>">Apply Leave</a>
<br><br>

<table>
    <tr>
        <th>S.No</th>
        <th>Leave Type</th>
        <th>From</th>
        <th>To</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>

    <?php if (!empty($myLeaves)): ?>
        <?php $i = 1; foreach ($myLeaves as $leave): ?>
        <tr>
            <td><?= $i++ ?></td>
            <td><?= esc($leave['type']) ?></td>
            <td><?= esc($leave['from_date']) ?></td>
            <td><?= esc($leave['to_date']) ?></td>
            <td class="<?= esc($leave['status']) ?>">
                <?= ucfirst($leave['status']) ?>
            </td>
            <td>
                <?php if ($leave['status'] == 'pending'): ?>
                    <a href="<?= base_url('leave/edit/'.$leave['id']) ?>">Edit</a> |
                    <a href="<?= base_url('leave/delete/'.$leave['id']) ?>"
                       onclick="return confirm('Delete this leave?')">Delete</a>
                <?php else: ?>
                    <span class="disabled">Edit</span> |
                    <span class="disabled">Delete</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="6">No leave requests found</td>
        </tr>
    <?php endif; ?>
    <?php if (!empty($myLeaves)): ?>
    <?php $i = 1; foreach ($myLeaves as $leave): ?>
        <tr>
            <td><?= $i++ ?></td>
            <td><?= esc($leave['type']) ?></td>
            <td><?= esc($leave['from_date']) ?></td>
            <td><?= esc($leave['to_date']) ?></td>
            <td class="<?= esc($leave['status']) ?>"><?= ucfirst($leave['status']) ?></td>
            <td>
                <?php if ($leave['status'] == 'pending'): ?>
                    <a href="<?= base_url('leave/edit/'.$leave['id']) ?>">Edit</a> |
                    <a href="<?= base_url('leave/delete/'.$leave['id']) ?>" onclick="return confirm('Delete?')">Delete</a>
                <?php else: ?>
                    <span class="disabled">Edit</span> |
                    <span class="disabled">Delete</span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr>
        <td colspan="6">No leave requests found</td>
    </tr>
<?php endif; ?>

</table>

</body>
</html>
