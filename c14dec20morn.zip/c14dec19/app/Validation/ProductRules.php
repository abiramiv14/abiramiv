<?php

namespace App\Validation;

use CodeIgniter\Validation\ValidationInterface;

class ProductRules
{
    public static function validateStock(string $value)
    {
        if (!is_numeric($value)) {
            return false;
        }

        if ($value < 0) {
            return false;
        }

        return true;
    }
}
