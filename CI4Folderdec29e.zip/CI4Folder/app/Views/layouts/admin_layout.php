<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Course Management</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght:300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        :root {
            --sidebar-width: 260px;
            --primary-color: #4f46e5;
            --bg-light: #f3f4f6;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-light);
            overflow-x: hidden;
        }
        /* Top Navbar */
        .top-navbar {
            background: #fff;
            height: 70px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
            position: fixed;
            top: 0;
            right: 0;
            left: var(--sidebar-width);
            z-index: 1000;
            padding: 0 30px;
        }
        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            background: #1e293b;
            color: #fff;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 1001;
            padding-top: 20px;
            transition: all 0.3s;
        }
        .sidebar-brand {
            font-size: 1.5rem;
            font-weight: 700;
            color: #fff;
            text-decoration: none;
            padding: 0 24px;
            margin-bottom: 40px;
            display: block;
            letter-spacing: -0.5px;
        }
        .nav-link {
            color: #94a3b8;
            padding: 12px 24px;
            display: flex;
            align-items: center;
            font-weight: 500;
            transition: all 0.2s;
            text-decoration: none;
            border-left: 3px solid transparent;
        }
        .nav-link i {
            font-size: 1.2rem;
            margin-right: 12px;
        }
        .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.05);
        }
        .nav-link.active {
            background: rgba(79, 70, 229, 0.1);
            color: #818cf8;
            border-left-color: #818cf8;
        }
        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            margin-top: 70px;
            padding: 30px;
        }
        /* Tables & Cards */
        .table {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.02);
        }
        .table thead {
            background-color: #f8fafc;
            border-bottom: 1px solid #e2e8f0;
        }
        .table th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.75rem;
            color: #64748b;
            letter-spacing: 0.5px;
            padding: 1rem;
        }
        .table td {
            vertical-align: middle;
            padding: 1rem;
            color: #334155;
            border-bottom: 1px solid #f1f5f9;
        }
        .form-check-input:checked {
            background-color: #10b981;
            border-color: #10b981;
        }
        /* Action Buttons */
        .btn-icon {
            width: 32px;
            height: 32px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            transition: 0.2s;
            text-decoration: none;
        }
        .btn-icon:hover {
            background-color: #f1f5f9;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="/admin/dashboard" class="sidebar-brand">
            <i class="bi bi-grid-1x2-fill text-primary me-2"></i> ERP Admin
        </a>
        <nav class="nav flex-column">
            <a class="nav-link <?= uri_string()=='admin/dashboard'?'active':'' ?>" href="/admin/dashboard">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
            <a class="nav-link <?= (strpos(uri_string(), 'courses') !== false && strpos(uri_string(), 'create') === false)?'active':'' ?>" href="/admin/courses">
                <i class="bi bi-book"></i> Manage Courses
            </a>
            <a class="nav-link <?= uri_string()=='admin/courses/create'?'active':'' ?>" href="/admin/courses/create">
                <i class="bi bi-plus-circle"></i> Add New Course
            </a>
        </nav>
        
        <div class="position-absolute bottom-0 w-100 p-3">
             <a href="/logout" class="nav-link text-danger" style="cursor:pointer;">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>

    <!-- Top Navbar -->
    <nav class="top-navbar d-flex align-items-center justify-content-end">
        <div class="d-flex align-items-center">
            <div class="text-end me-3">
                <div class="fw-bold text-dark" style="font-size: 0.9rem;">Admin User</div>
                <div class="text-muted" style="font-size: 0.8rem;">Administrator</div>
            </div>
            <img src="https://ui-avatars.com/api/?name=Admin+User&background=4f46e5&color=fff" class="rounded-circle" width="40" height="40" alt="User">
        </div>
    </nav>

    <!-- Main Content Area -->
    <div class="main-content">
        <?= $this->renderSection('content') ?>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>