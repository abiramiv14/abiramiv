<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Product</title>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
        }

        /* HEADER */
        .header {
            background: #007bff;
            color: #fff;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .profile {
            position: relative;
        }

        .profile button {
            background: none;
            border: none;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        .profile-content {
            display: none;
            position: absolute;
            right: 0;
            background: #fff;
            min-width: 150px;
            box-shadow: 0 2px 8px rgba(0,0,0,.2);
        }

        .profile-content a {
            display: block;
            padding: 10px;
            color: #333;
            text-decoration: none;
        }

        .profile:hover .profile-content {
            display: block;
        }

        /* FORM */
        .container {
            padding: 30px;
            max-width: 500px;
            margin: auto;
            background: #fff;
            margin-top: 30px;
            border-radius: 6px;
        }

        label {
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }

        .btn {
            margin-top: 15px;
            padding: 10px;
            width: 100%;
            background: #28a745;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h2>Create Product</h2>
    <div class="profile">
        <button><i class="fas fa-user-circle"></i> <?= session()->get('role') ?></button>
        <div class="profile-content">
            <a href="/logout">Logout</a>
        </div>
    </div>
</div>

<div class="container">

<?php if(session()->getFlashdata('error')): ?>
    <p style="color:red"><?= session()->getFlashdata('error') ?></p>
<?php endif; ?>

<form action="/products/store" method="post">
    <?= csrf_field() ?>

    <label>Product Name</label>
    <input type="text" name="product_name" required>

    <label>SKU</label>
    <input type="text" name="sku" required>

    <label>Price</label>
    <input type="number" step="0.01" name="price" required>

    <label>Stock</label>
    <input type="number" name="stock" required>

    <button type="submit" class="btn">Create Product</button>
</form>

<br>
<a href="/products">⬅ Back to Products</a>

</div>
</body>
</html>
