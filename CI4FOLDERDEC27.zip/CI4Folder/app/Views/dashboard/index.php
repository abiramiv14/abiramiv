<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<h3>Dashboard</h3>
<hr>

<div class="row">
    <div class="col-md-3">
        <div class="card text-white bg-primary mb-3">
            <div class="card-body">
                <h5>Total Courses</h5>
                <h3><?= $total ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success mb-3">
            <div class="card-body">
                <h5>Active Courses</h5>
                <h3><?= $active ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-danger mb-3">
            <div class="card-body">
                <h5>Inactive Courses</h5>
                <h3><?= $inactive ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-6">
        <canvas id="deptChart"></canvas>
    </div>
    <div class="col-md-6">
        <canvas id="semChart"></canvas>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const deptData = {
    labels: <?= json_encode(array_keys($dept)) ?>,
    datasets: [{
        label: 'Courses by Department',
        data: <?= json_encode(array_values($dept)) ?>,
        backgroundColor: [
            'rgba(54, 162, 235, 0.7)',
            'rgba(255, 99, 132, 0.7)',
            'rgba(255, 206, 86, 0.7)',
            'rgba(75, 192, 192, 0.7)',
            'rgba(153, 102, 255, 0.7)'
        ]
    }]
};

new Chart(document.getElementById('deptChart'), {
    type: 'bar',
    data: deptData,
    options: {
        responsive: true,
        plugins: {
            legend: { display: true, position: 'top' },
            title: { display: true, text: 'Courses by Department' }
        },
        scales: {
            x: { title: { display: true, text: 'Department' } },
            y: { title: { display: true, text: 'Number of Courses' }, beginAtZero: true }
        }
    }
});

const semData = {
    labels: <?= json_encode(array_keys($sem)) ?>,
    datasets: [{
        label: 'Courses by Semester',
        data: <?= json_encode(array_values($sem)) ?>,
        backgroundColor: [
            'rgba(255, 99, 132, 0.7)',
            'rgba(54, 162, 235, 0.7)',
            'rgba(255, 206, 86, 0.7)',
            'rgba(75, 192, 192, 0.7)',
            'rgba(153, 102, 255, 0.7)',
            'rgba(255, 159, 64, 0.7)',
            'rgba(201, 203, 207, 0.7)',
            'rgba(100, 149, 237, 0.7)'
        ]
    }]
};

new Chart(document.getElementById('semChart'), {
    type: 'bar',
    data: semData,
    options: {
        responsive: true,
        plugins: {
            legend: { display: true, position: 'top' },
            title: { display: true, text: 'Courses by Semester' }
        },
        scales: {
            x: { title: { display: true, text: 'Semester' } },
            y: { title: { display: true, text: 'Number of Courses' }, beginAtZero: true }
        }
    }
});
</script>

<?= $this->endSection() ?>
