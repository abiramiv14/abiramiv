<!DOCTYPE html>
<html>
<head>
    <title>Log Incident</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 450px;
            margin: 50px auto;
            background: #fff;
            padding: 30px 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        form input,
        form textarea,
        form select {
            width: 100%;
            padding: 12px 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }

        form textarea {
            resize: none;
            height: 100px;
        }

        form select {
            background: #fff;
            cursor: pointer;
        }

        form button {
            width: 100%;
            padding: 12px;
            background: #dc3545;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 15px;
            transition: background 0.3s;
        }

        form button:hover {
            background: #c82333;
        }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Common validation -->
    <script src="<?= base_url('assets/js/jqueryvalidation.js') ?>"></script>
</head>
<body>

<div class="container">

    <script>
        $(document).ready(function () {
            $("#title").focus();
        });
    </script>

    <form method="post" action="<?= base_url('/incidents/save') ?>">
        <h2>Incident / Complaint Log</h2>

        <input type="text" name="title" placeholder="Title" id="title" required class="name">

        <textarea name="description" placeholder="Description" required></textarea>

        <input type="text" name="department" placeholder="Department" class="name">

        <select name="priority">
            <option value="">-- Select Priority --</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
        </select>

        <input type="date" name="incident_date">

        <button type="submit">Submit Incident</button>
    </form>

</div>

</body>
</html>
