<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/','AuthController::login');
$routes->get('login','AuthController::login');
$routes->post('loginPost','AuthController::loginPost');
$routes->get('logout','AuthController::logout');

// Fee Routes
$routes->get('fees','FeeController::index');
$routes->get('fees/create','FeeController::create');
$routes->post('fees/store','FeeController::store');
$routes->get('fees/edit/(:num)','FeeController::edit/$1');
$routes->post('fees/update/(:num)','FeeController::update/$1');
$routes->post('fees/delete/(:num)','FeeController::delete/$1');  // use POST for delete

