<!DOCTYPE html>
<html>
<head>
    <title>Semester-wise Pass Percentage</title>
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
</head>
<body>

<h2>Semester-wise Pass Percentage</h2>
<div id="chartdiv3" style="width: 100%; height: 500px;"></div>

<script>
am5.ready(function() {

    var root = am5.Root.new("chartdiv3");
    root.setThemes([ am5themes_Animated.new(root) ]);
root._logo.dispose();
root.logo=null;
    var chart = root.container.children.push(
        am5xy.XYChart.new(root, {})
    );

    // Cursor
    chart.set("cursor", am5xy.XYCursor.new(root, {}));

    // X-axis → Semester
    var xAxis = chart.xAxes.push(
        am5xy.CategoryAxis.new(root, {
            categoryField: "semester",
            renderer: am5xy.AxisRendererX.new(root, { minGridDistance: 30 })
        })
    );
    xAxis.children.push(am5.Label.new(root, {
        text: "Semester",
        x: am5.p50,
        centerX: am5.p50,
        paddingTop: 10
    }));

    // Y-axis → Pass Percentage
    var yAxis = chart.yAxes.push(
        am5xy.ValueAxis.new(root, {
            min: 0,
            max: 100,
            renderer: am5xy.AxisRendererY.new(root, {})
        })
    );
    yAxis.children.push(am5.Label.new(root, {
        text: "Pass Percentage",
        rotation: -90,
        y: am5.p50,
        centerY: am5.p50
    }));

    // Line series
    var series = chart.series.push(
        am5xy.LineSeries.new(root, {
            name: "Pass %",
            xAxis: xAxis,
            yAxis: yAxis,
            valueYField: "pass_percentage",
            categoryXField: "semester",
            tooltip: am5.Tooltip.new(root, {
                labelText: "{categoryX}: {valueY}%"
            })
        })
    );

    // Add bullets on line points
    series.bullets.push(function() {
        return am5.Bullet.new(root, {
            sprite: am5.Circle.new(root, { radius: 5, fill: series.get("fill") })
        });
    });

    // PHP → JS data
    var data = [
        <?php foreach($passData as $row){ ?>
        { semester: "<?= $row['semester'] ?>", pass_percentage: <?= $row['pass_percentage'] ?> },
        <?php } ?>
    ];

    xAxis.data.setAll(data);
    series.data.setAll(data);

    series.appear(1000);
    chart.appear(1000, 100);
});
</script>

</body>
</html>
