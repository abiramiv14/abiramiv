<!DOCTYPE html>
<html>
<head>
    <title>Student List</title>

    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:80%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#007bff; color:#fff; }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
</head>

<body>

<h2 style="text-align:center;">Registered Students</h2>

<!-- ADD STUDENT BUTTON -->
<div style="width:80%; margin:20px auto; text-align:right;">
    <a href="<?= base_url('/students/create') ?>"
       style="padding:10px 15px; background:#28a745; color:#fff; text-decoration:none; border-radius:4px;">
        + Add Student
    </a>
</div>

<table id="studentTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Course</th>
            <th>City</th>
        </tr>
    </thead>

    <tbody>
    <?php foreach ($students as $row): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['student_name'] ?></td>
            <td><?= $row['email'] ?></td>
            <td><?= $row['phone'] ?></td>
            <td><?= $row['course'] ?></td>
            <td><?= $row['city'] ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>


<script>
$(document).ready(function () {
    $('#studentTable').DataTable();
});
</script>

</body>
</html>