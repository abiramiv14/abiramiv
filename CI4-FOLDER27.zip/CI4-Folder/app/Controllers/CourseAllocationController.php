<?php namespace App\Controllers;

use App\Models\CourseModel;
use App\Models\LoginModel;
use App\Models\CourseAllocationModel;

class CourseAllocationController extends BaseController {

    public function __construct() {
        helper('access');
        $session = session();
        if (!$session->get('isLoggedIn')) {
            return redirect()->to('/');
        }
    }

    // List allocations
    public function index() {
        $session = session();
        $model = new CourseAllocationModel();

        $allocations = $model->select('course_allocations.*, courses.course_name, login.name as faculty_name')
                             ->join('courses','courses.id = course_allocations.course_id')
                             ->join('login','login.id = course_allocations.faculty_id');

        if($session->get('role') == 'faculty'){
            $allocations = $allocations->where('faculty_id', $session->get('id'));
        }

        $data['allocations'] = $allocations->findAll();
        return view('course_allocation/list', $data);
    }

    // Create allocation form
    public function create() {
        if(!isAdmin()) return redirect()->to('/course_allocation');

        $data['courses'] = (new CourseModel())->findAll();
        $data['faculty'] = (new LoginModel())->where('role','faculty')->findAll();
        return view('course_allocation/create', $data);
    }

    // Store new allocation
    public function store() {
        if(!isAdmin()) return redirect()->to('/course_allocation');

        $session = session();
        $model = new CourseAllocationModel();

        $model->save([
            'course_id' => $this->request->getPost('course_id'),
            'faculty_id' => $this->request->getPost('faculty_id'),
            'academic_year' => $this->request->getPost('academic_year'),
            'semester' => $this->request->getPost('semester'),
            'created_by' => $session->get('id')
        ]);

        return redirect()->to('/course_allocation');
    }

    // Edit allocation form
    public function edit($id) {
        $model = new CourseAllocationModel();
        $allocation = $model->find($id);

        if(!$allocation) return redirect()->to('/course_allocation');
        if(!canEditAllocation($allocation['academic_year'])) return redirect()->to('/course_allocation');

        $data['allocation'] = $allocation;
        $data['courses'] = (new CourseModel())->findAll();
        $data['faculty'] = (new LoginModel())->where('role','faculty')->findAll();
        return view('course_allocation/edit', $data);
    }

    // Update allocation
    public function update($id) {
        $model = new CourseAllocationModel();
        $allocation = $model->find($id);

        if(!$allocation) return redirect()->to('/course_allocation');
        if(!canEditAllocation($allocation['academic_year'])) return redirect()->to('/course_allocation');

        $model->update($id, [
            'course_id' => $this->request->getPost('course_id'),
            'faculty_id' => $this->request->getPost('faculty_id'),
            'academic_year' => $this->request->getPost('academic_year'),
            'semester' => $this->request->getPost('semester')
        ]);

        return redirect()->to('/course_allocation');
    }

    // Delete allocation
    public function delete($id) {
        $model = new CourseAllocationModel();
        $allocation = $model->find($id);

        if(!$allocation) return redirect()->to('/course_allocation');
        if(!canEditAllocation($allocation['academic_year'])) return redirect()->to('/course_allocation');

        $model->delete($id);
        return redirect()->to('/course_allocation');
    }
}
