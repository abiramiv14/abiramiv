<!DOCTYPE html>
<html>
<head>
    <title>Fee Details</title>
    <!-- Include jQuery and DataTables CSS/JS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; padding:20px; }
        .profile-dropdown { float:right; margin-bottom: 20px; }
        .profile-dropdown select { padding:5px; }
        table { width:100%; margin-top:20px; }
        form { display:inline; }
    </style>
</head>
<body>

<div class="profile-dropdown">
    <select onchange="if(this.value){window.location=this.value}">
        <option value="">Profile</option>
        <option value="<?= base_url('logout') ?>">Logout</option>
    </select>
</div>

<h2>Fee Details</h2>

<?php if(session()->getFlashdata('success')): ?>
<script>alert("<?= session()->getFlashdata('success') ?>")</script>
<?php endif; ?>

<?php if(session('role')=='admin'): ?>
<a href="<?= base_url('fees/create') ?>">New Payment</a><br><br>
<?php endif; ?>

<table id="feesTable" class="display">
    <thead>
        <tr>
            <th>Receipt</th>
            <th>Student</th>
            <th>Total Fee</th>
            <th>Paid</th>
            <th>Due</th>
            <th>Status</th>
            <th>Payment Mode</th>
            <th>Date</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $studentModel = new \App\Models\StudentModel();
    foreach($fees as $f): 
        $status = $f['due_amount']>0 ? 'Pending' : 'Payment Successful';
        $student = $studentModel->find($f['student_id']);
    ?>
    <tr>
        <td><?= $f['receipt_no'] ?></td>
        <td><?= $student['register_no'].' - '.$student['department'] ?></td>
        <td><?= number_format($f['fee_amount'],0,'.',',') ?></td>
        <td><?= number_format($f['paid_amount'],0,'.',',') ?></td>
        <td><?= number_format($f['due_amount'],0,'.',',') ?></td>
        <td><?= $status ?></td>
        <td><?= $f['payment_mode'] ?></td>
        <td><?= $f['payment_date'] ?></td>
        <td>
            <?php if(session('role')=='admin'): ?>
                <a href="<?= base_url('fees/edit/'.$f['id']) ?>">Edit</a> | 
                <form method="post" action="<?= base_url('fees/delete/'.$f['id']) ?>" onsubmit="return confirm('Are you sure?')">
                    <?= csrf_field() ?>
                    <button type="submit">Delete</button>
                </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<script>
$(document).ready(function() {
    $('#feesTable').DataTable({
        "pageLength": 10,
        "order": [[ 0, "desc" ]] // sort by Receipt descending
    });
});
</script>

</body>
</html>
