<h2>New Course Allocation</h2>

<?php if(session()->getFlashdata('success')): ?>
<p style="color:green"><?= session()->getFlashdata('success') ?></p>
<?php endif; ?>
<?php if(session()->getFlashdata('error')): ?>
<p style="color:red"><?= session()->getFlashdata('error') ?></p>
<?php endif; ?>

<form method="post" action="<?= base_url('allocations/store') ?>">
    <?= csrf_field() ?>

    <label>Course:</label><br>
    <select name="course_id" required>
        <option value="">-- Select Course --</option>
        <?php foreach($courses as $c): ?>
            <option value="<?= $c['id'] ?>"><?= $c['course_code'] ?> - <?= $c['course_name'] ?></option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Faculty:</label><br>
    <select name="faculty_id" required>
        <option value="">-- Select Faculty --</option>
        <?php foreach($faculties as $f): ?>
            <option value="<?= $f['id'] ?>"><?= $f['user_id'] ?></option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Academic Year:</label><br>
    <input type="text" name="academic_year" value="<?= $currentYear ?>" readonly><br><br>

    <label>Semester:</label><br>
    <select name="semester" required>
        <?php for($i=1; $i<=8; $i++): ?>
            <option value="<?= $i ?>"><?= $i ?></option>
        <?php endfor; ?>
    </select><br><br>

    <button type="submit">Allocate Course</button>
</form>
