<?php namespace App\Controllers;

use App\Models\AdminModel;

class AuthControllers extends BaseController
{
    public function login()
    {
        echo view('login');
    }

    public function loginPost()
    {
        $session = session();
        $model = new AdminModel();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $admin = $model->where('username', $username)->first();
        if($admin && $admin['password'] == $password) {
            $session->set([
                'admin_id' => $admin['id'],
                'admin_name' => $admin['username'],
                'isLoggedIn' => true
            ]);
            return redirect()->to('/admin/dashboard');
        } else {
            $session->setFlashdata('error', 'Invalid Credentials');
            return redirect()->to('/');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}
