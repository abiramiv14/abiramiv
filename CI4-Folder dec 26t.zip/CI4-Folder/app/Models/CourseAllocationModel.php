<?php namespace App\Models;

use CodeIgniter\Model;

class CourseAllocationModel extends Model
{
    protected $table = 'course_allocations';
    protected $primaryKey = 'id';
    protected $allowedFields = ['course_id', 'faculty_id', 'academic_year', 'semester', 'created_by', 'updated_at'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
}
