<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Management</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <style>
        body, html { height: 100%; margin: 0; padding: 0; overflow: hidden; background-color: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .main-wrapper { display: flex; height: 100vh; width: 100%; }

        /* Sidebar */
        .sidebar { width: 220px; background: #2c3e50; color: #ecf0f1; display: flex; flex-direction: column; flex-shrink: 0; transition: all 0.3s; }
        .sidebar .brand { padding: 15px; font-size: 1.2rem; font-weight: bold; border-bottom: 1px solid #34495e; text-align: center; }
        .sidebar a { color: #bdc3c7; text-decoration: none; padding: 12px 20px; display: block; font-size: 0.9rem; transition: 0.2s; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: #fff; }

        /* Content Area */
        .content-area { flex-grow: 1; display: flex; flex-direction: column; overflow: hidden; position: relative; }

        /* Top Header */
        .top-header { height: 50px; background: #fff; border-bottom: 1px solid #ddd; display: flex; align-items: center; justify-content: flex-end; padding: 0 20px; flex-shrink: 0; z-index: 10; }
        .user-profile { cursor: pointer; display: flex; align-items: center; gap: 10px; padding: 5px 10px; border-radius: 5px; transition: 0.2s; }
        .user-profile:hover { background-color: #f1f1f1; }
        .user-avatar { width: 32px; height: 32px; background: #0d6efd; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; }

        /* Charts */
        .charts-container { height: 35%; padding: 10px; display: flex; gap: 10px; flex-shrink: 0; }
        .chart-card { background: #fff; border-radius: 5px; flex: 1; box-shadow: 0 2px 5px rgba(0,0,0,0.05); padding: 5px; display: flex; flex-direction: column; }
        .chart-card h6 { font-size: 0.8rem; margin: 5px; color: #666; text-align: center; }
        .chart-wrapper { flex-grow: 1; position: relative; width: 100%; overflow: hidden; }

        /* Table */
        .table-container { flex-grow: 0; max-height: 500px; margin: 5px 10px; overflow-y: auto; }
        .toolbar { padding: 10px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; background: #f8f9fa; }
        .dataTables_wrapper { flex-grow: 1; display: flex; flex-direction: column; overflow:visible; justify-content:flex-start; }
        .dataTables_length, .dataTables_filter, .dataTables_info, .dataTables_paginate { padding: 5px !important; }
        .dataTables_scrollBody { overflow-y: auto !important; flex-grow: 1 !important; }
        table { font-size: 0.85rem; margin: 0 !important; }
        .badge { font-size: 0.75rem; }
        .editable input.form-control-sm { height: 24px; font-size: 0.85rem; padding: 2px 5px; }
    </style>
</head>
<body>

<div class="main-wrapper">
    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="brand">📘 College ERP</div>
        <a href="#" class="active">📊 Dashboard</a>
        <a href="#">📚 Courses</a>
        <a href="#">👥 Students</a>
        <a href="#">👨‍🏫 Faculty</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="content-area">
        <div class="top-header">
            <div class="dropdown">
                <div class="user-profile dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="user-avatar">AD</div>
                    <span class="small fw-bold">Admin User</span>
                </div>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                    <li><a class="dropdown-item" href="#"><i class="bi bi-person me-2"></i> Profile</a></li>
                    <li><a class="dropdown-item" href="#"><i class="bi bi-gear me-2"></i> Settings</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="#"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                </ul>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="charts-container">
            <div class="chart-card">
                <h6>Status (Active vs Inactive)</h6>
                <div class="chart-wrapper"><canvas id="statusChart"></canvas></div>
            </div>
            <div class="chart-card">
                <h6>Department Wise</h6>
                <div class="chart-wrapper"><canvas id="deptChart"></canvas></div>
            </div>
            <div class="chart-card">
                <h6>Semester Wise</h6>
                <div class="chart-wrapper"><canvas id="semChart"></canvas></div>
            </div>
        </div>

        <!-- Course Table -->
        <div class="table-container">
            <div class="toolbar">
                <h6 class="m-0 fw-bold">Course List</h6>
                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addCourseModal">
                    <i class="bi bi-plus-lg"></i> Add Course
                </button>
            </div>

            <table id="courseTable" class="table table-hover table-striped w-100">
                <thead class="table-light sticky-top">
                    <tr>
                        <th>ID</th>
                        <th>Code</th>
                        <th>Course Name</th>
                        <th>Dept</th>
                        <th>Sem</th>
                        <th>Credits</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($courses as $c): ?>
                    <tr data-id="<?= $c['id'] ?>" class="editable-row">
                        <td><?= $c['id'] ?></td>
                        <td class="editable fw-bold text-primary" data-field="course_code"><?= esc($c['course_code']) ?></td>
                        <td class="editable" data-field="course_name"><?= esc($c['course_name']) ?></td>
                        <td class="editable" data-field="department"><span class="badge bg-secondary"><?= esc($c['department']) ?></span></td>
                        <td class="editable" data-field="semester"><?= esc($c['semester']) ?></td>
                        <td class="editable" data-field="credits"><?= esc($c['credits']) ?></td>
                        <td>
                            <div class="form-check form-switch">
                                <input class="form-check-input toggleStatus" type="checkbox" <?= $c['status']=='Active'?'checked':'' ?>>
                                <small class="status-label text-<?= $c['status']=='Active'?'success':'secondary' ?>"><?= $c['status'] ?></small>
                            </div>
                        </td>
                        <td>
                            <a href="#" class="editRow text-primary me-2"><i class="bi bi-pencil-fill"></i></a>
                            <a href="#" class="saveRow text-success me-2 d-none"><i class="bi bi-check-circle-fill"></i></a>
                            <a href="#" class="cancelRow text-danger me-2 d-none"><i class="bi bi-x-circle-fill"></i></a>
                            <a href="#" class="deleteCourse text-danger" data-id="<?= $c['id'] ?>"><i class="bi bi-trash-fill"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ADD COURSE MODAL -->
<div class="modal fade" id="addCourseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Course</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="addCourseForm">
                    <div class="mb-2">
                        <label class="small">Course Code</label>
                        <input type="text" name="course_code" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-2">
                        <label class="small">Course Name</label>
                        <input type="text" name="course_name" class="form-control form-control-sm" required>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-2">
                            <label class="small">Dept</label>
                            <select name="department" class="form-select form-select-sm" required>
                                <option value="CSE">CSE</option>
                                <option value="ECE">ECE</option>
                                <option value="EEE">EEE</option>
                                <option value="MECH">MECH</option>
                                <option value="CIVIL">CIVIL</option>
                            </select>
                        </div>
                        <div class="col-6 mb-2">
                            <label class="small">Credits</label>
                            <select name="credits" class="form-select form-select-sm" required>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="small">Semester</label>
                        <select name="semester" class="form-select form-select-sm" required>
                            <option value="1">Sem 1</option>
                            <option value="2">Sem 2</option>
                            <option value="3">Sem 3</option>
                            <option value="4">Sem 4</option>
                            <option value="5">Sem 5</option>
                            <option value="6">Sem 6</option>
                            <option value="7">Sem 7</option>
                            <option value="8">Sem 8</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 btn-sm">Save Course</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php 
$active = $inactive = 0;
foreach($courses as $c){
    if($c['status']=='Active') $active++;
    else $inactive++;
}
?>

<!-- SCRIPTS -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function(){

    const table = $('#courseTable').DataTable({
        paging: true,
        pageLength: 5,
        lengthMenu: [5, 10, 25, 50],
        searching: true,
        order: [[0,'desc']],
        dom: 'lfrtip',
    });

    // Charts
    const statusChartCtx = document.getElementById('statusChart').getContext('2d');
    const deptChartCtx = document.getElementById('deptChart').getContext('2d');
    const semChartCtx = document.getElementById('semChart').getContext('2d');

    const statusChart = new Chart(statusChartCtx, {
        type:'doughnut',
        data:{ labels:['Active','Inactive'], datasets:[{data:[<?= $active ?>, <?= $inactive ?>], backgroundColor:['#28a745','#6c757d']}] },
        options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{ position:'bottom' } } }
    });

    const deptChart = new Chart(deptChartCtx, {
        type:'bar',
        data:{ labels:Object.keys(<?= json_encode($dept) ?>), datasets:[{label:'Courses', data:Object.values(<?= json_encode($dept) ?>), backgroundColor:'#0d6efd'}] },
        options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false } } }
    });

    const semChart = new Chart(semChartCtx, {
        type:'line',
        data:{ labels:Object.keys(<?= json_encode($sem) ?>).map(s=>'Sem '+s), datasets:[{label:'Courses', data:Object.values(<?= json_encode($sem) ?>), borderColor:'#ffc107', backgroundColor:'rgba(255,193,7,0.2)', fill:true, tension:0.3}] },
        options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false } } }
    });

    function refreshCharts(){
        let active=0, inactive=0, dept={}, sem={};
        table.rows().every(function(){
            const d = this.data();
            if ($(d[6]).text().includes('Active')) active++;
            else inactive++;
            const dep = $(d[3]).text().trim(); dept[dep] = (dept[dep] || 0)+1;
            const s = d[4]; sem[s] = (sem[s]||0)+1;
        });
        statusChart.data.datasets[0].data = [active, inactive]; statusChart.update();
        deptChart.data.labels = Object.keys(dept); deptChart.data.datasets[0].data = Object.values(dept); deptChart.update();
        semChart.data.labels = Object.keys(sem).map(x=>'Sem '+x); semChart.data.datasets[0].data = Object.values(sem); semChart.update();
    }

    // Edit / Save
    $(document).on('click','.editRow',function(){
        const row = $(this).closest('tr');
        row.find('.editable').each(function(){
            if($(this).data('field')=='course_code') return;
            let val = $(this).text();
            if($(this).find('.badge').length) val = $(this).find('.badge').text();
            $(this).data('old',val).html(`<input class="form-control form-control-sm" value="${val}">`);
        });
        toggleRowButtons(row,true);
    });

    $(document).on('click','.cancelRow',function(){
        const row=$(this).closest('tr');
        row.find('.editable').each(function(){
            const oldVal=$(this).data('old');
            if($(this).data('field')=='department') $(this).html(`<span class="badge bg-secondary">${oldVal}</span>`);
            else $(this).html(oldVal);
        });
        toggleRowButtons(row,false);
    });

    $(document).on('click','.saveRow',function(){
        const row=$(this).closest('tr');
        const id=row.data('id'); const newData={};
        row.find('.editable').each(function(){
            const field=$(this).data('field'); if(field=='course_code') return;
            const input=$(this).find('input'); if(input.length) newData[field]=input.val();
        });

        $.post("<?= base_url('admin/courses/update-inline') ?>",{...newData,id},function(res){
            if(res.status==='success'){
                // Update row
                row.find('td:eq(2)').html(newData.course_name);
                row.find('td:eq(3)').html(`<span class="badge bg-secondary">${newData.department}</span>`);
                row.find('td:eq(4)').html(newData.semester);
                row.find('td:eq(5)').html(newData.credits);

                // Move row to top
                table.row(row).remove().draw(false);
                table.row.add(row).draw(false);
                row.prependTo('#courseTable tbody');

                toggleRowButtons(row,false);
                refreshCharts();
                Swal.fire({icon:'success',title:'Course Updated',timer:1200,toast:true,position:'top-end',showConfirmButton:false});
            }
        },'json');
    });

    // Toggle Status
    $(document).on('change','.toggleStatus',function(){
        const row=$(this).closest('tr'); const rowIndex=table.row(row).index();
        const id=row.data('id');
        $.post("<?= base_url('admin/courses/toggle-status') ?>",{id},function(res){
            if(res.status==='Active'||res.status==='Inactive'){
                const statusHtml=`<div class="form-check form-switch">
                    <input class="form-check-input toggleStatus" type="checkbox" ${res.status==='Active'?'checked':''}>
                    <small class="status-label text-${res.status==='Active'?'success':'secondary'}">${res.status}</small>
                </div>`;
                table.cell(rowIndex,6).data(statusHtml).draw(false);
                refreshCharts();
            }
        },'json');
    });

    // Delete
    $(document).on('click','.deleteCourse',function(e){
        e.preventDefault();
        const row=$(this).closest('tr'); const id=$(this).data('id');
        Swal.fire({title:'Delete?',text:'Cannot revert',icon:'warning',showCancelButton:true,confirmButtonColor:'#d33',confirmButtonText:'Yes, delete'})
        .then(r=>{ if(r.isConfirmed){
            $.get("<?= base_url('admin/courses/delete') ?>/"+id,function(res){
                if(res.status==='success'){ table.row(row).remove().draw(false); refreshCharts(); Swal.fire({icon:'success',title:'Deleted',timer:1200}); }
            },'json');
        }});
    });

    // Add Course
    $('#addCourseForm').submit(function(e){
        e.preventDefault();
        $.post("<?= base_url('admin/courses/store') ?>",$(this).serialize(),function(res){
            if(res.status==='success'){
                const c=res.course;
                const newRow = table.row.add([
                    c.id, c.course_code,
                    `<td class="editable" data-field="course_name">${c.course_name}</td>`,
                    `<td class="editable" data-field="department"><span class="badge bg-secondary">${c.department}</span></td>`,
                    c.semester, c.credits,
                    `<td><div class="form-check form-switch"><input class="form-check-input toggleStatus" type="checkbox" checked><small class="status-label text-success">Active</small></div></td>`,
                    `<td>
                        <a href="#" class="editRow text-primary me-2"><i class="bi bi-pencil-fill"></i></a>
                        <a href="#" class="saveRow text-success me-2 d-none"><i class="bi bi-check-circle-fill"></i></a>
                        <a href="#" class="cancelRow text-danger me-2 d-none"><i class="bi bi-x-circle-fill"></i></a>
                        <a href="#" class="deleteCourse text-danger" data-id="${c.id}"><i class="bi bi-trash-fill"></i></a>
                    </td>`
                ]).draw(false).node();
                $(newRow).prependTo('#courseTable tbody');
                $('#addCourseModal').modal('hide'); $('#addCourseForm')[0].reset(); refreshCharts();
                Swal.fire({icon:'success',title:'Course Added',timer:1200,toast:true,position:'top-end',showConfirmButton:false});
            }
        },'json');
    });

    function toggleRowButtons(row,isEditing){
        if(isEditing){ row.find('.editRow').addClass('d-none'); row.find('.saveRow,.cancelRow').removeClass('d-none'); }
        else { row.find('.saveRow,.cancelRow').addClass('d-none'); row.find('.editRow').removeClass('d-none'); }
    }
});
</script>

</body>
</html>
