<?php

if (!function_exists('isAdmin')) {
    function isAdmin() {
        return session('role') === 'admin';
    }
}

if (!function_exists('currentAcademicYear')) {
    function currentAcademicYear() {
        $year = date('Y');
        $nextYear = date('Y', strtotime('+1 year'));
        return $year . '-' . $nextYear;
    }
}

if (!function_exists('canEditAllocation')) {
    function canEditAllocation($allocationYear) {
        if (!isAdmin()) return false;
        return $allocationYear === currentAcademicYear();
    }
}
