<?php
namespace App\Controllers\leave;

use App\Models\leave\LeaveModel;
use CodeIgniter\Controller;

class LeaveController extends Controller
{
    protected $leaveModel;

    public function __construct()
    {
        $this->leaveModel = new LeaveModel();
    }

    public function index()
    {
        $role = session('role');
        $dept = session('department');

        if ($role == 'hod') {
           
            $data['leaves'] = $this->leaveModel
                ->where('department', $dept)
                ->findAll();
        } else {
            
            $data['leaves'] = $this->leaveModel
                ->where('employee_code', session('employee_code'))
                ->findAll();
        }

        return view('leaves/index', $data);
    }


    public function create()
    {
        if (session('role') != 'staff') {
            return redirect()->to('/leaves');
        }
        return view('leaves/create');
    }

    public function store()
    {
        if (session('role') != 'staff') {
            return redirect()->to('/leaves');
        }

        $this->leaveModel->save([
            'faculty_name' => session('name'),
            'employee_code' => session('employee_code'),
            'department' => session('department'),
            'leave_type' => $this->request->getPost('leave_type'),
            'from_date' => $this->request->getPost('from_date'),
            'to_date' => $this->request->getPost('to_date'),
            'status' => 'Pending'
        ]);

        return redirect()->to('/leaves');
    }

  
    public function edit($id)
{
    $leave = $this->leaveModel->find($id);

    // Staff can edit ONLY their own Pending leave
    if (session('role') == 'staff') {

        if (
            $leave['employee_code'] != session('employee_code') ||
            $leave['status'] != 'Pending'
        ) {
            return redirect()->to('/leaves');
        }
    }
    else {
        return redirect()->to('/leaves');
    }

    return view('leaves/edit', ['leave' => $leave]);
}


    public function update($id)
{
    $leave = $this->leaveModel->find($id);

    if (
        session('role') == 'staff' &&
        $leave['employee_code'] == session('employee_code') &&
        $leave['status'] == 'Pending'
    ) {
        $this->leaveModel->update($id, [
            'leave_type' => $this->request->getPost('leave_type'),
            'from_date' => $this->request->getPost('from_date'),
            'to_date' => $this->request->getPost('to_date')
        ]);
    }

    return redirect()->to('/leaves');
}


   
    public function delete($id)
{
    $leave = $this->leaveModel->find($id);

    if (
        session('role') == 'staff' &&
        $leave['employee_code'] == session('employee_code') &&
        $leave['status'] == 'Pending'
    ) {
        $this->leaveModel->delete($id);
    }

    return redirect()->to('/leaves');
}

    public function approve($id)
    {
        if (session('role') == 'hod') {
            $this->leaveModel->update($id, ['status' => 'Approved']);
        }
        return redirect()->to('/leaves');
    }

    public function reject($id)
    {
        if (session('role') == 'hod') {
            $this->leaveModel->update($id, ['status' => 'Rejected']);
        }
        return redirect()->to('/leaves');
    }
}
