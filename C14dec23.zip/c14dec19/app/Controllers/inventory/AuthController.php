<?php
namespace App\Controllers\inventory;

use CodeIgniter\Controller;
use App\Models\inventory\UserModel;

class AuthController extends Controller
{
    public function login()
    {
        return view('users/login');
    }

    public function loginPost()
    {
        $session = session();
        $userModel = new UserModel();

        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $user = $userModel->where('email', $email)->first();

        if (!$user || $password !== $user['password']) {
            return redirect()->back()->with('error', 'Invalid email or password');
        }

        $session->set([
            'user_id' => $user['id'],
            'role'    => $user['role'],
            'isLoggedIn' => true
        ]);

        return redirect()->to('/products');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
