<?php
namespace App\Models\helpersessiontask;

use CodeIgniter\Model;

class FeedbackModel extends Model
{
    protected $table = 'feedback';
    protected $primaryKey= "id";
    protected $allowedFields = ['name','email','message'];
}
