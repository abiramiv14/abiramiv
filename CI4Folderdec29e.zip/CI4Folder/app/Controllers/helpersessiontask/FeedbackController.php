<?php
namespace App\Controllers\helpersessiontask;

use CodeIgniter\Controller;
use App\Models\helpersessiontask\FeedbackModel;

class FeedbackController extends Controller
{
    public function saveFeedback()
    {
        helper(['form','url']);
        $model = new FeedbackModel();

        $model->insert([
            'name'    => $this->request->getPost('name'),
            'email'   => $this->request->getPost('email'),
            'message' => $this->request->getPost('message')
        ]);

        session()->setFlashdata('success','Feedback submitted successfully!');
        return redirect()->to('/dashboard');
    }
}
