<!DOCTYPE html>
<html>
<head>
    <title>Create Fee Payment</title>
    <!-- Include jQuery and DataTables CSS/JS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; padding:20px; }
        .profile-dropdown { float:right; margin-bottom: 20px; }
        .profile-dropdown select { padding:5px; }
        table { width:100%; margin-top:20px; }
    </style>
</head>
<body>

<div class="profile-dropdown">
    <select onchange="if(this.value){window.location=this.value}">
        <option value="">Profile</option>
        <option value="<?= base_url('logout') ?>">Logout</option>
    </select>
</div>

<h2>Create Fee Payment</h2>

<?php if(session()->getFlashdata('error')): ?>
<p style="color:red"><?= session()->getFlashdata('error') ?></p>
<?php endif; ?>
<?php if(session()->getFlashdata('success')): ?>
<script>alert("<?= session()->getFlashdata('success') ?>")</script>
<?php endif; ?>

<form method="post" action="<?= base_url('fees/store') ?>">
    <?= csrf_field() ?>
    Student:
    <select name="student_id" required>
        <?php foreach($students as $s): ?>
        <option value="<?= $s['id'] ?>"><?= $s['register_no']." - ".$s['department'] ?></option>
        <?php endforeach; ?>
    </select><br><br>

    Semester: <input type="number" name="semester" required><br><br>
    Total Fee: <input type="number" name="fee_amount" required><br><br>
    Paid Amount: <input type="number" name="paid_amount" required><br><br>

    Payment Mode:
    <select name="payment_mode" required>
        <option>Cash</option>
        <option>UPI</option>
        <option>Bank</option>
    </select><br><br>

    <button type="submit">Submit Payment</button>
</form>

<h2>All Payments</h2>
<table id="paymentsTable" class="display">
    <thead>
        <tr>
            <th>Receipt</th>
            <th>Student</th>
            <th>Total Fee</th>
            <th>Paid</th>
            <th>Due</th>
            <th>Status</th>
            <th>Payment Mode</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    $studentModel = new \App\Models\StudentModel();
    foreach($fees as $f):
        $student = $studentModel->find($f['student_id']);
        $status = $f['due_amount']>0 ? 'Pending' : 'Payment Successful';
    ?>
        <tr>
            <td><?= $f['receipt_no'] ?></td>
            <td><?= $student['register_no'].' - '.$student['department'] ?></td>
            <td><?= number_format($f['fee_amount'],0,'.',',') ?></td>
            <td><?= number_format($f['paid_amount'],0,'.',',') ?></td>
            <td><?= number_format($f['due_amount'],0,'.',',') ?></td>
            <td><?= $status ?></td>
            <td><?= $f['payment_mode'] ?></td>
            <td><?= $f['payment_date'] ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<script>
$(document).ready(function() {
    $('#paymentsTable').DataTable({
        "pageLength": 10,
        "order": [[ 0, "desc" ]] // order by Receipt
    });
});
</script>

</body>
</html>
