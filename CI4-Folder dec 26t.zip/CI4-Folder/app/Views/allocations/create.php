<h3>New Allocation (<?= currentAcademicYear() ?>)</h3>

<form method="post" action="<?= base_url('allocations/store') ?>">
<?= csrf_field() ?>

<select name="course_id" required>
<?php foreach($courses as $c): ?>
<option value="<?= $c['id'] ?>"><?= $c['course_code'].' - '.$c['course_name'] ?></option>
<?php endforeach; ?>
</select>

<select name="faculty_id" required>
<?php foreach($faculties as $f): ?>
<option value="<?= $f['id'] ?>">Faculty <?= $f['user_id'] ?></option>
<?php endforeach; ?>
</select>

<select name="semester" required>
<?php foreach([1,2] as $s): ?>  <!-- Admin can choose semester here -->
<option value="<?= $s ?>"><?= $s ?></option>
<?php endforeach; ?>
</select>

<button type="submit">Allocate</button>
</form>
