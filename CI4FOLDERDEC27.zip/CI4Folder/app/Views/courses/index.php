<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<h3>Courses List</h3>
<hr>
<?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<table id="courseTable" class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Code</th>
            <th>Name</th>
            <th>Department</th>
            <th>Semester</th>
            <th>Credits</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($courses as $c): ?>
        <tr>
            <td><?= $c['id'] ?></td>
            <td><?= $c['course_code'] ?></td>
            <td><?= $c['course_name'] ?></td>
            <td><?= $c['department'] ?></td>
            <td><?= $c['semester'] ?></td>
            <td><?= $c['credits'] ?></td>
            <td class="text-center">
    <button class="btn btn-sm <?= $c['status']=='Active'?'btn-success':'btn-danger' ?> toggleStatusBtn" 
            data-id="<?= $c['id'] ?>">
        <?= $c['status'] ?>
    </button>
</td>

            <td class="text-center">
                <!-- Edit icon -->
                <a href="/admin/courses/edit/<?= $c['id'] ?>" class="text-primary me-2" title="Edit">
                    <i class="bi bi-pencil-fill" style="font-size: 1.2rem;"></i>
                </a>

                <!-- Delete icon -->
                <a href="/admin/courses/delete/<?= $c['id'] ?>" class="text-danger" title="Delete" onclick="return confirm('Are you sure?')">
                    <i class="bi bi-trash-fill" style="font-size: 1.2rem;"></i>
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready(function(){

    // Initialize DataTable with newest first
    $('#courseTable').DataTable({
        "order": [[0, "desc"]]
    });

    // Toggle status button
    $(document).on('click', '.toggleStatusBtn', function(){
        let btn = $(this);
        let courseId = btn.data('id');

        $.ajax({
            url: "<?= base_url('admin/courses/toggle-status') ?>",
            type: "POST",
            data: {id: courseId},
            success: function(res){
                // Update button text and color
                if(res.status == 'Active'){
                    btn.removeClass('btn-danger').addClass('btn-success').text('Active');
                } else {
                    btn.removeClass('btn-success').addClass('btn-danger').text('Inactive');
                }
            },
            error: function(){
                alert('Error updating status.');
            }
        });
    });

});
</script>



<?= $this->endSection() ?>
