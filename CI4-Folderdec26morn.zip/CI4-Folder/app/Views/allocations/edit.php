<h2>Edit Course Allocation</h2>
<form method="post" action="<?= base_url('allocations/update/'.$allocation['id']) ?>">
<?= csrf_field() ?>
<label>Course:</label>
<select name="course_id" required>
<?php foreach($courses as $course): ?>
<option value="<?= $course['id'] ?>" <?= $allocation['course_id']==$course['id']?'selected':'' ?>>
<?= $course['course_code'].' - '.$course['course_name'] ?></option>
<?php endforeach; ?>
</select><br><br>

<label>Faculty:</label>
<select name="faculty_id" required>
<?php foreach($faculties as $faculty): ?>
<option value="<?= $faculty['id'] ?>" <?= $allocation['faculty_id']==$faculty['id']?'selected':'' ?>>
<?= $faculty['user_id'] ?></option>
<?php endforeach; ?>
</select><br><br>

<label>Academic Year:</label>
<select name="academic_year" required>
<option value="<?= $allocation['academic_year'] ?>"><?= $allocation['academic_year'] ?></option>
</select><br><br>

<label>Semester:</label>
<select name="semester" required>
<option value="1" <?= $allocation['semester']==1?'selected':'' ?>>1</option>
<option value="2" <?= $allocation['semester']==2?'selected':'' ?>>2</option>
</select><br><br>

<button type="submit">Update</button>
</form>
