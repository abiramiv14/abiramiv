<?php
namespace App\Controllers;

use App\Models\ResultReportModel;

class reports2 extends BaseController {

    public function semesterPassPercentage()
    {
        $model = new ResultReportModel();
        $data['passData'] = $model->getPassPercentageBySemester();

        return view('reports/semester_pass_percentage', $data);
    }

    // You can add more functions here
}
