<?php helper(['form','url']); ?>
<!DOCTYPE html>
<html>
<head>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <!-- CKEditor 4 Full version with Word import -->
<script src="https://cdn.ckeditor.com/4.23.0/full/ckeditor.js"></script>
<script src="<?= base_url('assets/js/jqueryvalidation.js') ?>"></script>


    <title>Dashboard</title>
    <style>
        /* BODY STYLES */
        body.light {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: #fff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: background 0.5s, color 0.5s;
        }

        body.dark {
            background: linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%);
            color: #fff;
            transition: background 0.5s, color 0.5s;
        }

        /* CONTAINER CARD */
        .container {
            width: 500px;
            margin: 50px auto;
            padding: 30px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.3);
            text-align: center;
            transition: background 0.5s;
        }

        body.dark .container {
            background: rgba(0,0,0,0.3);
        }

        h2, h3 {
            margin-bottom: 20px;
            letter-spacing: 1px;
        }

        /* FLASH MESSAGE */
        p.flash {
            font-weight: bold;
            color: #00ff99;
            margin-bottom: 20px;
            animation: flashAnim 1s ease-in-out;
        }

        @keyframes flashAnim {
            0%,100% {opacity: 1;}
            50% {opacity: 0.5;}
        }

        /* FORM FIELDS */
        input, textarea, select, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 12px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            font-size: 16px;
            transition: all 0.3s ease;
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.3), 0 0 10px rgba(255,255,255,0.3);
        }

        body.dark input, body.dark textarea, body.dark select {
            background-color: rgba(255,255,255,0.1);
            color: #fff;
            border: 1px solid rgba(255,255,255,0.2);
        }

        /* BUTTONS */
        button {
            background: linear-gradient(to right, #ff416c, #ff4b2b);
            color: #fff;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        button:hover {
            background: linear-gradient(to right, #ff4b2b, #ff416c);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.4);
        }

        /* LOGOUT LINK */
        a.logout {
            display: inline-block;
            margin-top: 25px;
            padding: 12px 25px;
            background: linear-gradient(to right, #00c6ff, #0072ff);
            color: #fff;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        a.logout:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.4);
        }

        /* DROPDOWN & TEXTAREA */
        select, textarea {
            resize: none;
        }

        /* RESPONSIVE */
        @media screen and (max-width: 550px) {
            .container {
                width: 90%;
                padding: 20px;
            }
        }

    </style>
</head>
<body class="<?= session()->get('theme') ?? 'light' ?>">

<div class="container">
    <h2>Welcome <?= session()->get('email') ?></h2>

    <!-- FLASH MESSAGE -->
    <?php if(session()->getFlashdata('success')): ?>
        <p class="flash"><?= session()->getFlashdata('success') ?></p>
    <?php endif; ?>

    <!-- FEEDBACK FORM -->
    <h3>Feedback Form</h3>
    <?= form_open('/feedback/save') ?>
        <?= form_input(['name'=>'name', 'placeholder'=>'Name', 'required'=>true,'class'=>"name"]) ?>
        <?= form_input(['name'=>'email', 'type'=>'email', 'placeholder'=>'Email', 'required'=>true]) ?>
        <?= form_textarea(['name'=>'message', 'id'=>'message', 'placeholder'=>'Message']) ?>

        <?= form_submit('submit','Send Feedback') ?>
    <?= form_close() ?>

    <!-- THEME SELECTION -->
    <h3>Select Theme</h3>
    <?= form_open('/theme/apply') ?>
        <?= form_dropdown('theme', ['light'=>'Light','dark'=>'Dark'], session()->get('theme')) ?>
        <?= form_submit('submit','Apply Theme') ?>
    <?= form_close() ?>

    <a class="logout" href="/logout">Logout</a>
</div>

<script src="https://cdn.ckeditor.com/4.23.0/full/ckeditor.js"></script>
<script>
    CKEDITOR.replace('message', {
        extraPlugins: 'pastefromword', // Enable Word import
        height: 250,                    // Editor height
        removeButtons: '',              // Optional: customize toolbar
        pasteFromWordPromptCleanup: true
    });
</script>


</body>
</html>
