<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
/*$routes->get('/','AuthController::login');
$routes->get('login','AuthController::login');
$routes->post('loginPost','AuthController::loginPost');
$routes->get('logout','AuthController::logout');

// Fee Routes
$routes->get('fees','FeeController::index');
$routes->get('fees/create','FeeController::create');
$routes->post('fees/store','FeeController::store');
$routes->get('fees/edit/(:num)','FeeController::edit/$1');
$routes->post('fees/update/(:num)','FeeController::update/$1');
$routes->post('fees/delete/(:num)','FeeController::delete/$1'); 
$routes->get('fees/receipt/(:num)','FeeController::receipt/$1');*/



$routes->get('/', 'AuthController1::login');
$routes->post('/loginPost', 'AuthController1::loginPost');
$routes->get('/logout', 'AuthController1::logout');

// Course Allocations
$routes->get('/allocations', 'CourseAllocationController::index');
$routes->get('/allocations/create', 'CourseAllocationController::create');
$routes->post('/allocations/store', 'CourseAllocationController::store');
$routes->get('/allocations/edit/(:num)', 'CourseAllocationController::edit/$1');
$routes->post('/allocations/update/(:num)', 'CourseAllocationController::update/$1');
$routes->get('/allocations/delete/(:num)', 'CourseAllocationController::delete/$1');
