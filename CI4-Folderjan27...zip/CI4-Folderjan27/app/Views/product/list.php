<!DOCTYPE html>
<html>
<head>
<title>Department Master</title>

<style>
body { font-family: Arial; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 10px; border: 1px solid #ddd; }
th { background: #f2f2f2; }

input[type=text] { padding: 5px; width: 95%; }

.btn {
    padding: 5px 10px;
    border-radius: 4px;
    border: none;
    cursor: pointer;
}
.btn-save { background: #0d6efd; color: #fff; }
.btn-del { background: #dc3545; color: #fff; }

/* Toggle */
.switch {
    position: relative;
    display: inline-block;
    width: 40px;
    height: 20px;
}
.switch input { display: none; }
.slider {
    position: absolute;
    background-color: #ccc;
    border-radius: 20px;
    top: 0; left: 0; right: 0; bottom: 0;
}
.slider:before {
    content: "";
    position: absolute;
    height: 14px;
    width: 14px;
    left: 3px;
    bottom: 3px;
    background: white;
    border-radius: 50%;
}
input:checked + .slider {
    background-color: #28a745;
}
input:checked + .slider:before {
    transform: translateX(18px);
}
</style>
</head>

<body>

<h2>Department Master</h2>

<!-- ADD FORM -->
<form method="post" action="/department/save">
    <input type="text" name="dept_code" placeholder="Dept Code" required>
    <input type="text" name="dept_name" placeholder="Dept Name" required>
    <button class="btn btn-save">Add</button>
</form>

<br>

<table>
<tr>
    <th>Code</th>
    <th>Name</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php foreach ($departments as $d): ?>
<tr>
    <td><?= esc($d['dept_code']) ?></td>

    <td>
        <form method="post" action="/department/update/<?= $d['id'] ?>">
            <input type="text" name="dept_name"
                   value="<?= esc($d['dept_name']) ?>">
    </td>

    <td>
        <label class="switch">
            <input type="checkbox"
                <?= $d['status']=='Active' ? 'checked' : '' ?>
                onchange="this.form.submit()">
            <span class="slider"></span>
        </label>

        <!-- ALWAYS SEND STATUS -->
        <input type="hidden" name="status"
               value="<?= $d['status']=='Active' ? 'Inactive' : 'Active' ?>">
    </td>

    <td>
        <button class="btn btn-save">💾</button>
        </form>

        <a class="btn btn-del"
           onclick="return confirm('Deactivate this department?')"
           href="/department/delete/<?= $d['id'] ?>">🗑</a>
    </td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>
