<!DOCTYPE html>
<html>
<head>
    <title>Edit Leave</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        header {
            background-color: #2c3e50;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .profile-dropdown {
            position: relative;
            display: inline-block;
        }
        .profile-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: #fff;
            min-width: 120px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .profile-dropdown-content a {
            color: #333;
            padding: 8px 12px;
            text-decoration: none;
            display: block;
        }
        .profile-dropdown-content a:hover { background-color: #f2f2f2; }
        .profile-dropdown:hover .profile-dropdown-content { display: block; }

        .container { padding: 20px; }
        form { max-width: 500px; margin: auto; }
        label { font-weight: bold; }
        input, select, button { width: 100%; padding: 8px; margin: 8px 0; }
        button { background-color: #2c3e50; color: #fff; border: none; cursor: pointer; }
        button:hover { background-color: #34495e; }
        a.back-link { display: inline-block; margin-top: 10px; text-decoration: none; color: #007bff; }
    </style>
</head>
<body>

<header>
    <div><h3>College ERP - Leave Management</h3></div>
    <div class="profile-dropdown">
        <?= session()->get('username') ?> (<?= session()->get('role') ?>)
        <div class="profile-dropdown-content">
            <a href="<?= base_url('logout') ?>">Logout</a>
        </div>
    </div>
</header>

<div class="container">
    <h2>Edit Leave (Pending Only)</h2>

    <form method="post" action="<?= base_url('leave/update/'.$leave['id']) ?>">
        <?= csrf_field() ?>

        <label>Leave Type</label><br>
        <select name="type" required>
            <option value="Casual" <?= $leave['type']=='Casual'?'selected':'' ?>>Casual</option>
            <option value="Sick" <?= $leave['type']=='Sick'?'selected':'' ?>>Sick</option>
            <option value="On Duty" <?= $leave['type']=='On Duty'?'selected':'' ?>>On Duty</option>
        </select><br>

        <label>From Date</label><br>
        <input type="date" name="from_date" value="<?= $leave['from_date'] ?>" required><br>

        <label>To Date</label><br>
        <input type="date" name="to_date" value="<?= $leave['to_date'] ?>" required><br>

        <button type="submit">Update</button>
    </form>

    <a class="back-link" href="<?= base_url('leave') ?>">&#8592; Back</a>
</div>

</body>
</html>
