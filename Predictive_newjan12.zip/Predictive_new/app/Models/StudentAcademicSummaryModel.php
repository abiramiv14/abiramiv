<?php
namespace App\Models;
use CodeIgniter\Model;
class StudentAcademicSummaryModel extends Model{
    protected $table            = 'student_academic_summary';
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
'student_id',
'student_name',
'attendance_percentage',
'avg_internal_marks',
'fee_due_amount',
'incident_count'];

    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $useSoftDeletes   = false;
}
