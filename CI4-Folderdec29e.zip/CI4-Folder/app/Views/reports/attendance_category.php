<!DOCTYPE html>
<html>
<head>
    <title>Attendance Distribution</title>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
</head>
<body>

<h3>Attendance Category Distribution</h3>
<div id="chart" style="width: 400px; height: 300px;"></div>

<script>
var options = {
    chart: { type: 'donut' },
    series: [<?= $attendanceData['Excellent'] ?>, <?= $attendanceData['Good'] ?>, <?= $attendanceData['Poor'] ?>],
    labels: ['Excellent', 'Good', 'Poor'],
    tooltip: {
        y: { formatter: val => val + " students" }
    }
};

new ApexCharts(document.querySelector("#chart"), options).render();
</script>

</body>
</html>
