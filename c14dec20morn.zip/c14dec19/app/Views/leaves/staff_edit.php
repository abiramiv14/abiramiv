<!DOCTYPE html>
<html>
<head>
    <title>Edit Leave</title>
</head>
<body>

<h2>Edit Leave</h2>

<form method="post" action="<?= base_url('leave/update/'.$leave['id']) ?>">
    <label>Leave Type</label><br>
    <select name="type" required>
        <option value="casual" <?= $leave['type']=='casual'?'selected':'' ?>>Casual</option>
        <option value="medical" <?= $leave['type']=='medical'?'selected':'' ?>>Medical</option>
        <option value="earned" <?= $leave['type']=='earned'?'selected':'' ?>>Earned</option>
    </select><br><br>

    <label>From Date</label><br>
    <input type="date" name="from_date" value="<?= $leave['from_date'] ?>" required><br><br>

    <label>To Date</label><br>
    <input type="date" name="to_date" value="<?= $leave['to_date'] ?>" required><br><br>

    <button type="submit">Update</button>
</form>

<a href="<?= base_url('leave') ?>">Back</a>

</body>
</html>
