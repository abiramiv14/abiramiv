<?php helper(['url']); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1f4037, #99f2c8);
            margin: 0;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #fff;
            margin-bottom: 30px;
        }

        .cart-container {
            max-width: 900px;
            margin: auto;
            background: #ffffff;
            border-radius: 18px;
            padding: 30px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.25);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th {
            background: #2c3e50;
            color: #fff;
            padding: 14px;
        }

        td {
            padding: 14px;
            text-align: center;
            border-bottom: 1px solid #eee;
        }

        tr:hover {
            background-color: #f8f8f8;
        }

        .price {
            color: #27ae60;
            font-weight: bold;
        }

        .subtotal {
            font-weight: bold;
            color: #333;
        }

        .remove-btn {
            text-decoration: none;
            padding: 7px 14px;
            background: linear-gradient(135deg, #ff512f, #dd2476);
            color: #fff;
            border-radius: 20px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .remove-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 20px rgba(221,36,118,0.4);
        }

        .total-row td {
            font-size: 18px;
            font-weight: bold;
            background: #f1f1f1;
        }

        /* 🔥 BUTTON SECTION */
        .actions {
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            flex: 1;
            text-align: center;
            padding: 14px 22px;
            border-radius: 30px;
            font-weight: bold;
            text-decoration: none;
            color: #fff;
            letter-spacing: 0.5px;
            transition: all 0.35s ease;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255,255,255,0.2);
            transition: 0.4s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-products {
            background: linear-gradient(135deg, #00b09b, #96c93d);
        }

        .btn-products:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(0,176,155,0.4);
        }

        .btn-checkout {
            background: linear-gradient(135deg, #ff512f, #dd2476);
        }

        .btn-checkout:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(221,36,118,0.45);
        }

        .empty {
            text-align: center;
            font-size: 18px;
            padding: 40px;
            color: #555;
        }
    </style>
</head>

<body>

<h2>🛒 Your Shopping Cart</h2>

<div class="cart-container">

<?php
$total = 0;

if (!empty($cart) && is_array($cart)):
?>
<table>
    <tr>
        <th>Product</th>
        <th>Price</th>
        <th>Qty</th>
        <th>Subtotal</th>
        <th>Action</th>
    </tr>

<?php foreach ($cart as $key => $item):
    if (!is_array($item)) continue;
    $sub = $item['price'] * $item['quantity'];
    $total += $sub;
?>
<tr>
    <td><?= esc($item['name']) ?></td>
    <td class="price">₹ <?= esc($item['price']) ?></td>
    <td><?= esc($item['quantity']) ?></td>
    <td class="subtotal">₹ <?= $sub ?></td>
    <td>
        <a class="remove-btn" href="<?= site_url('remove/'.$key) ?>">Remove</a>
    </td>
</tr>
<?php endforeach; ?>

<tr class="total-row">
    <td colspan="3">Total</td>
    <td colspan="2">₹ <?= $total ?></td>
</tr>
</table>

<!-- 🔥 ACTION BUTTONS -->
<div class="actions">
    <a class="btn btn-products" href="<?= site_url('cart-form') ?>">
        🛍️ View Products
    </a>

    <a class="btn btn-checkout" href="#">
        🚀 Checkout
    </a>
</div>

<?php else: ?>
<div class="empty">
    🛍️ Your cart is empty <br><br>
    <a class="btn btn-products" href="<?= site_url('cart-form') ?>">
        Start Shopping
    </a>
</div>
<?php endif; ?>

</div>

</body>
</html>
