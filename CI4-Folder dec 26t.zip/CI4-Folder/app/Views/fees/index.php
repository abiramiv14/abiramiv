<h2>Fee Payments</h2>
<a href="<?= base_url('fees/create') ?>">Add Payment</a>
<table border="1">
<tr>
    <th>Receipt</th><th>Student</th><th>Semester</th><th>Fee</th><th>Paid</th><th>Due</th><th>Date</th>
</tr>
<?php foreach($payments as $pay): ?>
<tr>
    <td><?= $pay['receipt_no'] ?></td>
    <td><?= $pay['student_id'] ?></td>
    <td><?= $pay['semester'] ?></td>
    <td><?= $pay['fee_amount'] ?></td>
    <td><?= $pay['paid_amount'] ?></td>
    <td><?= calculateDue($pay['fee_amount'], $pay['paid_amount']) ?></td>
    <td><?= $pay['payment_date'] ?></td>
</tr>
<?php endforeach; ?>
</table>
