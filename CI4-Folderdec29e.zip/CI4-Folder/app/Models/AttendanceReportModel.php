<?php
namespace App\Models;

use CodeIgniter\Model;

class AttendanceReportModel extends Model
{
    public function getAttendanceCategoryCount()
    {
        return $this->db->table('attendance')
            ->select("
                SUM(CASE WHEN attendance_percentage >= 85 THEN 1 ELSE 0 END) AS Excellent,
                SUM(CASE WHEN attendance_percentage BETWEEN 75 AND 84 THEN 1 ELSE 0 END) AS Good,
                SUM(CASE WHEN attendance_percentage < 75 THEN 1 ELSE 0 END) AS Poor
            ")
            ->get()
            ->getRowArray();
    }
}
