<?php namespace App\Controllers;
use App\Models\StudentFeeModel;
use App\Models\StudentModel;

class FeeController extends BaseController
{
    public function create()
{
    if(session('role')!='admin') return redirect()->to('/login');

    $studentModel = new StudentModel();
    $feeModel = new StudentFeeModel();

    $data = [
        'students' => $studentModel->findAll(),
        'fees'     => $feeModel->findAll()  // <-- Pass all fees here
    ];

    return view('fees/create', $data);
}


    public function store()
    {
        if(session('role')!='admin') return redirect()->to('/login');

        $student_id = $this->request->getPost('student_id');
        $fee = $this->request->getPost('fee_amount');
        $paid = $this->request->getPost('paid_amount');

        // remaining due before this payment
        $remainingBefore = getRemainingDue($student_id);

        // check if paid + already paid > fee
        if($paid > $fee + $remainingBefore){
            return redirect()->back()->with('error','Paid amount exceeds total fee');
        }

        $due = $fee - $paid;
        $receipt = generateReceiptNo($student_id);

        $model = new StudentFeeModel();
        $model->insert([
            'student_id'=>$student_id,
            'semester'=>$this->request->getPost('semester'),
            'fee_amount'=>$fee,
            'paid_amount'=>$paid,
            'due_amount'=>$due,
            'payment_mode'=>$this->request->getPost('payment_mode'),
            'payment_date'=>date('Y-m-d'),
            'receipt_no'=>$receipt,
            'created_by'=>session('user_id')
        ]);

        // remaining after this payment
        $remainingAfter = getRemainingDue($student_id);

        $message = $remainingAfter > 0 ?
            "Partial Payment Success! Remaining: ".formatINR($remainingAfter) :
            "Payment Successful! No pending dues";

        return redirect()->to('/fees')->with('success',$message);
    }

    public function index()
    {
        $model = new StudentFeeModel();
        if(session('role')=='student'){
            $data['fees'] = $model->where('student_id',session('student_id'))->findAll();
        }else{
            $data['fees'] = $model->findAll();
        }
        return view('fees/list',$data);
    }


    public function edit($id)
    {
        if(session('role')!='admin') return redirect()->to('/login');
        $model = new StudentFeeModel();
        $data['fee'] = $model->find($id);
        $studentModel = new StudentModel();
        $data['students'] = $studentModel->findAll();
        return view('fees/edit',$data);
    }

    public function update($id)
{
    if(session('role')!='admin') return redirect()->to('/login');

    $fee = $this->request->getPost('fee_amount');
    $paid = $this->request->getPost('paid_amount');

    if($paid > $fee){
        return redirect()->back()->with('error','Paid amount cannot exceed fee');
    }

    $due = calculateDue($fee,$paid);

    $model = new StudentFeeModel();
    $model->update($id,[
        'student_id'=>$this->request->getPost('student_id'),
        'semester'=>$this->request->getPost('semester'),
        'fee_amount'=>$fee,
        'paid_amount'=>$paid,
        'due_amount'=>$due,
        'payment_mode'=>$this->request->getPost('payment_mode')
    ]);

    return redirect()->to('/fees')->with('success','Payment updated successfully');
}
public function delete($id)
{
    if(session('role')!='admin') return redirect()->to('/login');
    $model = new StudentFeeModel();
    $model->delete($id);
    return redirect()->to('/fees')->with('success','Payment deleted successfully');
}
}