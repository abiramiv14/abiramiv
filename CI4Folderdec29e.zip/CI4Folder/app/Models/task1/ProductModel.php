<?php

namespace App\Models\task1;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'product_id';

    
    protected $allowedFields = [
        'product_name',
        'category',
        'price',
        'stock_quantity',
        'description'
    ];

    
    protected $validationRules = [
        'product_name' => 'required',
        'category'     => 'required'
    ];

    protected $validationMessages = [
        'product_name' => [
            'required' => 'Product name is required'
        ],
        'category' => [
            'required' => 'Category is required'
        ]
    ];
}
