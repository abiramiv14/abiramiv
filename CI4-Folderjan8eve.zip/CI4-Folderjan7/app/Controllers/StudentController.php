<?php

namespace App\Controllers;

use App\Models\StudentModel;
use App\Models\UploadHistoryModel;

class StudentController extends BaseController
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    // Upload form
    public function index()
    {
        return view('upload_form');
    }

    // ✅ CSV upload
    public function upload()
    {
        $file = $this->request->getFile('csv_file');

        if (!$file || !$file->isValid() || $file->getClientExtension() !== 'csv') {
            return redirect()->back()->with('error', 'Upload failed');
        }
$originalName = $file->getClientName();
        $csvName = time().'_students.csv';
        $csvPath = WRITEPATH.'uploads/'.$csvName;
        $file->move(WRITEPATH.'uploads', $csvName);

        $xlsxName = $this->request->getPost('original_xlsx');

        $studentModel = new StudentModel();
        $countInserted = 0;

        if (($handle = fopen($csvPath, 'r')) !== false) {
            fgetcsv($handle); // skip header

            while (($row = fgetcsv($handle)) !== false) {
                $name  = trim($row[0] ?? '');
                $email = trim($row[1] ?? '');
                $phone = trim($row[2] ?? '');
                $mark  = trim($row[3] ?? 0);
         if (!is_numeric($mark) || $mark < 0 || $mark > 100) {
            return redirect()->back()->with(
            'error',
            "Invalid mark ($mark) for email $email. Mark must be between 0 and 100."
        );
    }
                if (!$email) continue;

             $existingStudent = $studentModel->where('email', $email)->first();

if ($existingStudent) {
    // UPDATE mark if email exists
    $studentModel->update($existingStudent['id'], [
        'mark' => $mark ?? 0,
    ]);
} else {
    // INSERT new student
    $studentModel->insert([
        'name'  => $name,
        'email' => $email,
        'phone' => $phone,
        'mark'  => $mark ?? 0,
    ]);
}

            }
            fclose($handle);
        }

        // unlink($csvPath);

        // Save upload history
        $this->db->table('student_uploads')->insert([
            'file_name'      => $csvName,
            'total_uploaded' => $countInserted
        ]);

        return redirect()->to('/student/report')
            ->with('success', 'Upload completed')
            ->with('skipped', 0); // You can modify to track skipped records
    }

    // Student history page
    public function history()
    {
        $historyModel = new UploadHistoryModel();
        $data['history'] = $historyModel->orderBy('uploaded_at', 'DESC')->findAll();

        return view('student_history', $data);
    }

    // Download uploaded XLSX file
    public function downloadUploadedFile($file)
    {
        $path = WRITEPATH.'uploads/'.$file;

        if (!file_exists($path)) {
            return redirect()->back()->with('error', 'File not found');
        }

        return $this->response->download($path, null);
    }

    // Show student report
    public function report()
    {
        return view('student_report', [
            'students' => (new StudentModel())->findAll(),
            'success' => session()->getFlashdata('success'),
            'skipped' => session()->getFlashdata('skipped')
        ]);
    }

    // ✅ Generate PDF report
    public function downloadReport()
{
    helper('ReportHelper'); // optional if you later auto-increment

    $students = (new StudentModel())->findAll();
    $reportNo = 'GCE/TNV/' . date('Y') . '/' . rand(1001, 9999);

    require_once(APPPATH.'Libraries/TCPDF-main/tcpdf.php');

    // Create PDF
    $pdf = new \TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

    // ---------------- DOCUMENT SETTINGS ----------------
    $pdf->SetCreator('GCE Tirunelveli');
    $pdf->SetAuthor('GCE Tirunelveli');
    $pdf->SetTitle('Official Marksheet');

    // REAL MARKSHEET MARGINS
    $pdf->SetMargins(20, 25, 20);
    $pdf->SetHeaderMargin(10);
    $pdf->SetFooterMargin(15);
    $pdf->SetAutoPageBreak(true, 25);

    $pdf->AddPage();

    // ---------------- PAGE BORDER (REAL LOOK) ----------------
    $pdf->Rect(10, 10, 190, 277);

    // ---------------- LOGO CENTER ----------------
    $logoPath = FCPATH.'logo.png';
    if (file_exists($logoPath)) {
        $pageWidth = $pdf->getPageWidth();
        $logoWidth = 30;
        $x = ($pageWidth - $logoWidth) / 2;
        $pdf->Image($logoPath, $x, 18, $logoWidth);
    }

    $pdf->Ln(30);

    // ---------------- COLLEGE NAME ----------------
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 8, 'GOVERNMENT COLLEGE OF ENGINEERING', 0, 1, 'C');
    $pdf->Cell(0, 8, 'TIRUNELVELI – 627007', 0, 1, 'C');

    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 6, 'OFFICIAL STATEMENT OF MARKS', 0, 1, 'C');

    $pdf->Ln(5);
    $pdf->Cell(0, 6, 'Report No: '.$reportNo, 0, 1, 'R');

    $pdf->Ln(8);

    // ---------------- TABLE ----------------
    $pdf->SetFont('helvetica', '', 11);

    $html = '
    <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead>
            <tr bgcolor="#e6e6e6">
                <th  align="center"><b>ID</b></th>
                <th  align="center"><b>Name</b></th>
                <th  align="center"><b>Email</b></th>
                <th  align="center"><b>Phone</b></th>
                <th  align="center"><b>Marks</b></th>
            </tr>
        </thead>
        <tbody>';

    foreach ($students as $s) {
        $html .= '
        <tr>
            <td align="center">'.$s['id'].'</td>
            <td>'.esc($s['name']).'</td>
            <td>'.esc($s['email']).'</td>
            <td align="center">'.esc($s['phone']).'</td>
            <td align="center"><b>'.$s['mark'].'</b></td>
        </tr>';
    }

    $html .= '</tbody></table>';

    $pdf->writeHTML($html, true, false, true, false, '');

    $pdf->Ln(10);

    // ---------------- INSTRUCTIONS ----------------
    $pdf->SetFont('helvetica', '', 11);
    $instructions = 
    "Instructions:\n".
    "1. This marksheet is generated electronically and does not require a seal.\n".
    "2. Any discrepancy in marks should be reported within 7 days.\n".
    "3. This document is valid only with authorized signatures.";

    $pdf->MultiCell(0, 6, $instructions, 0, 'L');

    $pdf->Ln(18);

    // ---------------- SIGNATURES ----------------
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(90, 6, "Controller of Examinations", 0, 0, 'L');
    $pdf->Cell(0, 6, "Candidate Signature", 0, 1, 'R');

    $pdf->Ln(12);

    $pdf->Cell(90, 6, "_________________________", 0, 0, 'L');
    $pdf->Cell(0, 6, "_________________________", 0, 1, 'R');

    $pdf->Ln(10);

    $pdf->SetFont('helvetica', 'I', 10);
    $pdf->Cell(0, 6, 'Date: '.date('d-m-Y'), 0, 1, 'L');

    // ---------------- DOWNLOAD ----------------
    $pdf->Output('GCE_Tirunelveli_Marksheet_'.$reportNo.'.pdf', 'D');
}


}
