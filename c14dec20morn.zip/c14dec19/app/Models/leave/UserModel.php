<?php

namespace App\Models\leave;

use CodeIgniter\Model;

class Usermodel extends Model{
    protected $table = 'user';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'email',
        'password',
        'role',
        'dept_name'
    ];

    protected $useTimestamps = true;
}
