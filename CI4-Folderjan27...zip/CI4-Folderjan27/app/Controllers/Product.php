<?php

namespace App\Controllers;
use App\Models\ProductModel;

class Product extends BaseController
{
    public function index()
    {
        $model = new ProductModel();

        $search = $this->request->getGet('search');
        $status = $this->request->getGet('status');

        $query = $model;

        if($search) {
            $query = $query->like('product_name', $search)->orLike('product_code', $search);
        }

        if($status && $status != 'All') {
            $query = $query->where('status', $status);
        }

        $data['products'] = $query->findAll();

        return view('product/index', $data);
    }
public function store()
{
    $model = new \App\Models\ProductModel();

    $model->insert([
        'product_code' => $this->request->getPost('product_code'),
        'product_name' => $this->request->getPost('product_name'),
        'category'     => $this->request->getPost('category'),
        'price'        => $this->request->getPost('price'),
        'stock'        => $this->request->getPost('stock'),
        'status'       => $this->request->getPost('status'),
    ]);

    return redirect()->to('/products');
}
public function create()
{
    return view('product/create');
}

    // Inline edit AJAX
    public function inlineEdit()
    {
        $id = $this->request->getPost('id');
        $field = $this->request->getPost('field');
        $value = $this->request->getPost('value');

        $model = new ProductModel();
        $model->update($id, [$field => $value]);

        return $this->response->setJSON(['success' => true]);
    }

    // Toggle status AJAX
    public function toggleStatus($id)
    {
        $model = new ProductModel();
        $product = $model->find($id);

        if($product){
            $newStatus = $product['status']=='Active'?'Inactive':'Active';
            $model->update($id,['status'=>$newStatus]);
            return $this->response->setJSON(['success'=>true,'status'=>$newStatus]);
        }
        return $this->response->setJSON(['success'=>false]);
    }

    // Soft delete AJAX
    public function delete($id)
    {
        $model = new ProductModel();
        $model->delete($id);
        return $this->response->setJSON(['success'=>true]);
    }

    // Restore soft deleted product
    public function restore($id)
    {
        $model = new ProductModel();
        $model->update($id, ['deleted_at'=>null]);
        return $this->response->setJSON(['success'=>true]);
    }

    // Bulk actions
    public function bulkAction()
    {
        $action = $this->request->getPost('action');
        $ids = $this->request->getPost('ids'); // array of ids

        $model = new ProductModel();

        if($action=='delete'){
            foreach($ids as $id) $model->delete($id);
        }
        elseif($action=='restore'){
            foreach($ids as $id) $model->update($id, ['deleted_at'=>null]);
        }
        elseif($action=='activate'){
            foreach($ids as $id) $model->update($id, ['status'=>'Active']);
        }
        elseif($action=='deactivate'){
            foreach($ids as $id) $model->update($id, ['status'=>'Inactive']);
        }

        return $this->response->setJSON(['success'=>true]);
    }
}
