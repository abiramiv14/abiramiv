<!DOCTYPE html>
<html>
<head>
    <title>Apply Leave</title>
</head>
<body>

<h2>Apply Leave</h2>

<form method="post" action="<?= base_url('leaves/store') ?>">
    <?= csrf_field() ?>

    <label>Leave Type</label><br>
    <select name="leave_type" required>
        <option value="">--Select--</option>
        <option value="Casual">Casual</option>
        <option value="Sick">Sick</option>
        <option value="On Duty">On Duty</option>
    </select><br><br>

    <label>From Date</label><br>
    <input type="date" name="from_date" required><br><br>

    <label>To Date</label><br>
    <input type="date" name="to_date" required><br><br>

    <button type="submit">Submit Leave</button>
</form>

<a href="<?= base_url('leaves') ?>">Back</a>

</body>
</html>
