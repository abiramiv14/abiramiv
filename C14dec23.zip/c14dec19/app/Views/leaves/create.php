<!DOCTYPE html>
<html>
<head>
    <title>Apply Leave</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f9f9f9; }
        header {
            background-color: #2c3e50;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .profile-dropdown {
            position: relative;
            display: inline-block;
        }
        .profile-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: #fff;
            min-width: 120px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .profile-dropdown-content a {
            color: #333;
            padding: 8px 12px;
            text-decoration: none;
            display: block;
        }
        .profile-dropdown-content a:hover { background-color: #f2f2f2; }
        .profile-dropdown:hover .profile-dropdown-content { display: block; }

        .container { max-width: 500px; margin: 40px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 20px; }
        label { font-weight: bold; display: block; margin: 10px 0 5px; }
        select, input, button { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; }
        button { background-color: #2c3e50; color: #fff; border: none; cursor: pointer; }
        button:hover { background-color: #34495e; }
        a.back-link { display: block; text-align: center; margin-top: 10px; color: #007bff; text-decoration: none; }
    </style>
</head>
<body>

<header>
    <div><h3>College ERP - Leave Management</h3></div>
    <div class="profile-dropdown">
        <?= session()->get('username') ?> (<?= session()->get('role') ?>)
        <div class="profile-dropdown-content">
            <a href="<?= base_url('logout') ?>">Logout</a>
        </div>
    </div>
</header>

<div class="container">
    <h2>Apply Leave</h2>

    <form method="post" action="<?= base_url('leave/store') ?>">
        <?= csrf_field() ?>

        <label>Leave Type</label>
        <select name="type" required>
            <option value="">--Select--</option>
            <option value="Casual">Casual</option>
            <option value="Sick">Sick</option>
            <option value="On Duty">On Duty</option>
        </select>

        <label>From Date</label>
        <input type="date" name="from_date" required>

        <label>To Date</label>
        <input type="date" name="to_date" required>

        <button type="submit">Submit Leave</button>
    </form>

    <a class="back-link" href="<?= base_url('leave') ?>">&#8592; Back</a>
</div>

</body>
</html>
