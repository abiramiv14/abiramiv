<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>College ERP - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            overflow-x: hidden;
        }
        .sidebar {
            min-height: 100vh;
        }
        .sidebar .nav-link.active {
            background-color: #0d6efd;
            color: white !important;
        }
    </style>
</head>
<body>
    <!-- Top Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="/admin/dashboard">College ERP</a>
            <div class="d-flex">
                <span class="navbar-text me-3">
                    Welcome, <?= session()->get('admin_name') ?>
                </span>
                <a href="/logout" class="btn btn-danger btn-sm">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 bg-light sidebar p-3">
                <h5>Admin Menu</h5>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string()=='admin/dashboard'?'active':'' ?>" href="/admin/dashboard">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string()=='admin/courses'?'active':'' ?>" href="/admin/courses">Courses List</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string()=='admin/courses/create'?'active':'' ?>" href="/admin/courses/create">Add Course</a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <?= $this->renderSection('content') ?>
            </div>
        </div>
    </div>
</body>
</html>
