<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Course Allocations</title>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { font-family: Arial; background:#f4f6f9; padding:20px; }
h2 { margin-bottom:15px; }
.btn-add { background:#28a745; color:#fff; padding:8px 14px; text-decoration:none; border-radius:4px; font-size:14px; }
table.dataTable thead { background:#343a40; color:white; }
.action-icons a { margin-right:10px; font-size:16px; text-decoration:none; }
.edit-icon { color:#007bff; }
.delete-icon { color:#dc3545; }
</style>
</head>
<body>

<h2>Course Allocations</h2>

<?php if(isAdmin()): ?>
<a href="<?= base_url('allocations/create') ?>" class="btn-add"><i class="fa fa-plus"></i> New Allocation</a>
<form method="get" style="margin-top:10px;">
    <label>Filter by Academic Year:</label>
    <select name="year" onchange="this.form.submit()">
        <option value="">All</option>
        <?php foreach($years as $y): ?>
            <option value="<?= $y['academic_year'] ?>" <?= ($selected_year==$y['academic_year'])?'selected':'' ?>><?= $y['academic_year'] ?></option>
        <?php endforeach; ?>
    </select>
</form>
<?php endif; ?>

<br>

<table id="allocationTable" class="display" style="width:100%">
<thead>
<tr>
<th>Course Code</th>
<th>Course Name</th>
<th>Academic Year</th>
<th>Semester</th>
<?php if(isAdmin()): ?><th>Faculty</th><th>Action</th><?php endif; ?>
</tr>
</thead>
<tbody>
<?php foreach($allocations as $a): ?>
<tr>
<td><?= esc($a['course_code']) ?></td>
<td><?= esc($a['course_name']) ?></td>
<td><?= esc($a['academic_year']) ?></td>
<td><?= esc($a['semester']) ?></td>
<?php if(isAdmin()): ?>
<td><?= esc($a['faculty_name']) ?></td>
<td class="action-icons">
<?php if(canEditAllocation($a['academic_year'])): ?>
<a href="<?= base_url('allocations/edit/'.$a['id']) ?>" class="edit-icon"><i class="fa fa-pen"></i></a>
<a href="<?= base_url('allocations/delete/'.$a['id']) ?>" class="delete-icon" onclick="return confirm('Are you sure?');"><i class="fa fa-trash"></i></a>
<?php endif; ?>
</td>
<?php endif; ?>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#allocationTable').DataTable({ pageLength:5, lengthMenu:[5,10,25,50], ordering:true });
});
</script>

</body>
</html>
