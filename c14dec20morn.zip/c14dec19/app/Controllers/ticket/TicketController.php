<?php
namespace App\Controllers\ticket;
use App\Models\ticket\TicketModel;
use CodeIgniter\Controller;

class TicketController extends Controller
{
    protected $ticketModel;

    public function __construct(){
        $this->ticketModel = new TicketModel();
    }

    private function checkLogin(){
        $session = session();
        if(!$session->get('isLoggedIn')){
            return redirect()->to('/login')->with('error','Login required');
        }
    }

    public function index(){
        $this->checkLogin();
        $session = session();
        $role = $session->get('role');
        $username = $session->get('username');

        if($role == 'admin'){
            $data['tickets'] = $this->ticketModel->findAll();
        } else {
            $data['tickets'] = $this->ticketModel->where('raised_by', $username)->findAll();
        }
        return view('ticketpages/ticket_list', $data);
    }

    public function create(){
        return view('ticketpages/ticket_create');
    }

    public function store(){
        $data = $this->request->getPost();
        $data['raised_by'] = session()->get('username');

        if(!$this->ticketModel->insert($data)){
            return $this->response
                ->setStatusCode(422)
                ->setJSON([
                    'status'=>'error',
                    'errors'=>$this->ticketModel->errors()
                ]);
        }

        return redirect()->to('/tickets')->with('success','Ticket created successfully');
    }

    public function edit($id){
        $ticket = $this->ticketModel->find($id);
        return view('ticketpages/ticket_edit',['ticket'=>$ticket]);
    }

    public function update($id){
        $data = $this->request->getPost();
        if(!$this->ticketModel->update($id, $data)){
            return $this->response
                ->setStatusCode(422)
                ->setJSON([
                    'status'=>'error',
                    'errors'=>$this->ticketModel->errors()
                ]);
        }
        return redirect()->to('/tickets')->with('success','Ticket updated successfully');
    }

    public function delete($id){
        $this->ticketModel->delete($id);
        return redirect()->to('/tickets')->with('success','Ticket deleted successfully');
    }
}
