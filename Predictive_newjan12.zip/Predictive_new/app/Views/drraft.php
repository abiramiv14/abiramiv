<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Risk Predictions</title>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<style>
body { font-family: Arial, sans-serif; margin:20px; }
.high { color:red; font-weight:bold; }
.medium { color:orange; font-weight:bold; }
.low { color:green; font-weight:bold; }
.modal { display:none; position:fixed; z-index:999; left:0; top:0; width:100%; height:100%; background:rgba(0,0,0,0.5); }
.modal-content { background:#fff; width:400px; margin:10% auto; padding:20px; border-radius:5px; }
.close { float:right; font-size:20px; cursor:pointer; color:red; }
button { padding:5px 10px; cursor:pointer; }
.card { display:inline-block; padding:15px; margin:5px; background:#f2f2f2; border-radius:5px; }
</style>
</head>
<body>

<h2>High Risk Students by Department</h2>
<?php foreach($dropout_by_department as $d): ?>
    <div class="card">
        <strong><?= esc($d['department_name']) ?></strong><br>
        Total High Risk: <?= esc($d['total']) ?>
    </div>
<?php endforeach; ?>

<h2>Student Risk Predictions</h2>
<label for="department">Select Department:</label>
<select id="department">
    <option value="">---Select---</option>
    <?php foreach($dropout_by_department as $d): ?>
        <option value="<?= esc($d['department_name']) ?>" <?= $d['department_name']==$defaultDept?'selected':'' ?>>
            <?= esc($d['department_name']) ?>
        </option>
    <?php endforeach; ?>
</select>

<table id="riskTable" class="display">
<thead>
<tr>
<!-- <th>ID</th> -->
<th>Student ID</th>
<th>Risk Score</th>
<th>Risk Level</th>
<th>Department</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($predictions as $row): ?>
<tr data-id="<?= esc($row['id']) ?>">
<td><?= esc($row['id']) ?></td>
<td><?= esc($row['student_id']) ?></td>
<td><?= esc($row['risk_score']) ?></td>
<td class="<?= strtolower($row['risk_level']) ?>"><?= esc($row['risk_level']) ?></td>
<td><?= esc($row['department_name']) ?></td>
<td><button class="viewBtn">View</button></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<!-- Modal -->
<div id="viewModal" class="modal">
<div class="modal-content">
<span class="close">&times;</span>
<h3>Risk Details</h3>
<p><strong>ID:</strong> <span id="m_id"></span></p>
<p><strong>Student ID:</strong> <span id="m_student"></span></p>
<p><strong>Risk Score:</strong> <span id="m_score"></span></p>
<p><strong>Risk Level:</strong> <span id="m_level"></span></p>
<p><strong>AI Remarks:</strong> <span id="m_remarks"></span></p>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function(){
    var table = $('#riskTable').DataTable({ pageLength:10 });

    // Modal
    $('.viewBtn').on('click', function(){
        let row = $(this).closest('tr');
        $('#m_id').text(row.find('td:eq(0)').text());
        $('#m_student').text(row.find('td:eq(1)').text());
        $('#m_score').text(row.find('td:eq(2)').text());
        $('#m_level').text(row.find('td:eq(3)').text());
        $('#m_remarks').text(row.find('td:eq(5)').text());
        $('#viewModal').fadeIn();
    });
    $('.close, .modal').on('click', function(e){ if(e.target!==this) return; $('#viewModal').fadeOut(); });

  $('#department').on('change', function () {
    let dept = $(this).val();

    $.post('getStudentsByDept', { department: dept }, function (res) {

        table.clear();

        res.forEach(function (r) {
            table.row.add([
                r.id,
                r.student_id,
                r.risk_score,
                '<span class="' + r.risk_level.toLowerCase() + '">' + r.risk_level + '</span>',
                r.department_name,
                '<button class="viewBtn">View</button>'
            ]);
        });

        table.draw(); // 🔥 THIS IS IMPORTANT

    }, 'json');
});

});
</script>

</body>
</html>
