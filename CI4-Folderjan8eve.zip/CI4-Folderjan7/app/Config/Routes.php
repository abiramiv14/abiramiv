<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index');



$routes->get('/student', 'StudentController::index');
$routes->post('/student/upload', 'StudentController::upload');
$routes->get('/student/report', 'StudentController::report');
$routes->get('/student/downloadReport', 'StudentController::downloadReport');


$routes->get('/student/downloadReport', 'StudentController::downloadReport');
$routes->get('/student/deleteAll', 'StudentController::deleteAll');
$routes->get('student/history', 'StudentController::history');
$routes->get('student/downloadUploadedFile/(:any)', 'StudentController::downloadUploadedFile/$1');

