<?php
namespace App\Controllers\helpersessiontask;

use CodeIgniter\Controller;

class ThemeController extends Controller
{
    public function applyTheme()
    {
        $theme = $this->request->getPost('theme');
        session()->set('theme', $theme);

        return redirect()->to('/dashboard');
    }
}
