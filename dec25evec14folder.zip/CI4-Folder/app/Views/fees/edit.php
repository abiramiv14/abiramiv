<h2>Edit Fee Payment</h2>

<?php if(session()->getFlashdata('error')): ?>
<p style="color:red"><?= session()->getFlashdata('error') ?></p>
<?php endif; ?>

<form method="post" action="<?= base_url('fees/update/'.$fee['id']) ?>">
    <?= csrf_field() ?>
    Student:
    <select name="student_id" required>
        <?php foreach($students as $s): ?>
        <option value="<?= $s['id'] ?>" <?= $fee['student_id']==$s['id']?'selected':'' ?>>
            <?= $s['register_no'].' - '.$s['department'] ?>
        </option>
        <?php endforeach; ?>
    </select><br><br>

    Semester: <input type="number" name="semester" value="<?= $fee['semester'] ?>" required><br><br>
    Total Fee: <input type="number" name="fee_amount" value="<?= $fee['fee_amount'] ?>" required><br><br>
    Paid Amount: <input type="number" name="paid_amount" value="<?= $fee['paid_amount'] ?>" required><br><br>

    Payment Mode:
    <select name="payment_mode" required>
        <option <?= $fee['payment_mode']=='Cash'?'selected':'' ?>>Cash</option>
        <option <?= $fee['payment_mode']=='UPI'?'selected':'' ?>>UPI</option>
        <option <?= $fee['payment_mode']=='Bank'?'selected':'' ?>>Bank</option>
    </select><br><br>

    <button type="submit">Update Payment</button>
</form>
