<h2>Login</h2>
<form method="post" action="<?= base_url('loginPost') ?>">
    <?= csrf_field() ?>
    Email: <input type="email" name="email" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    <button type="submit">Login</button>
</form>
