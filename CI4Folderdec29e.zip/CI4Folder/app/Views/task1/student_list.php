<!DOCTYPE html>
<html>
<head>
    <title>Registered Students</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:80%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#007bff; color:#fff; }
        .editing-row { background-color: #fff3cd !important; }
        .edit-field { width: 100%; padding:3px; }
        button { cursor: pointer; }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
</head>
<body>

<h2 style="text-align:center;">Registered Students</h2>

<div style="width:80%; margin:20px auto; text-align:right;">
    <a href="<?= base_url('/students/create') ?>"
       style="padding:10px 15px; background:#28a745; color:#fff; text-decoration:none; border-radius:4px;">
        + Add Student
    </a>
</div>

<table id="studentTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Course</th>
            <th>City</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($students as $row): ?>
        <tr data-id="<?= $row['id'] ?>">
            <td><?= $row['id'] ?></td>
            <td><span class="text"><?= $row['student_name'] ?></span>
                <input type="text" name="student_name" class="edit-field" value="<?= $row['student_name'] ?>" style="display:none;"></td>
            <td><span class="text"><?= $row['email'] ?></span>
                <input type="email" name="email" class="edit-field" value="<?= $row['email'] ?>" style="display:none;"></td>
            <td><span class="text"><?= $row['phone'] ?></span>
                <input type="text" name="phone" class="edit-field" value="<?= $row['phone'] ?>" style="display:none;"></td>
            <td><span class="text"><?= $row['course'] ?></span>
                <input type="text" name="course" class="edit-field" value="<?= $row['course'] ?>" style="display:none;"></td>
            <td><span class="text"><?= $row['city'] ?></span>
                <input type="text" name="city" class="edit-field" value="<?= $row['city'] ?>" style="display:none;"></td>
            <td>
                <button class="edit-btn"><i class="fa fa-pen" style="color:blue;"></i></button>
                <button class="save-btn" style="display:none;"><i class="fa fa-check" style="color:green;"></i></button>
                <button class="cancel-btn" style="display:none;"><i class="fa fa-times" style="color:orange;"></i></button>
                <a href="<?= base_url('students/delete/'.$row['id']) ?>" onclick="return confirm('Delete this student?')">
                    <i class="fa fa-trash" style="color:red;"></i>
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<script>
$(document).ready(function() {
    $('#studentTable').DataTable();

    // Click edit
    $(document).on('click', '.edit-btn', function() {
        let row = $(this).closest('tr');
        row.addClass('editing-row');
        row.find('.text').hide();
        row.find('.edit-field').show();
        row.find('.edit-btn').hide();
        row.find('.save-btn, .cancel-btn').show();
    });

    // Click cancel
    $(document).on('click', '.cancel-btn', function() {
        let row = $(this).closest('tr');
        row.removeClass('editing-row');
        row.find('.edit-field').each(function() {
            let val = $(this).siblings('.text').text();
            $(this).val(val);
        });
        row.find('.edit-field').hide();
        row.find('.text').show();
        row.find('.edit-btn').show();
        row.find('.save-btn, .cancel-btn').hide();
    });

    // Click save
    $(document).on('click', '.save-btn', function() {
        let row = $(this).closest('tr');
        let id = row.data('id');

        let data = {};
        row.find('.edit-field').each(function() {
            data[$(this).attr('name')] = $(this).val();
        });

        // Send AJAX request to update
        $.post("<?= base_url('students/update') ?>/"+id, data, function(response){
            // update table text
            row.find('.edit-field').each(function() {
                $(this).siblings('.text').text($(this).val());
            });
            row.removeClass('editing-row');
            row.find('.edit-field').hide();
            row.find('.text').show();
            row.find('.edit-btn').show();
            row.find('.save-btn, .cancel-btn').hide();
        });
    });
});
</script>

</body>
</html>
