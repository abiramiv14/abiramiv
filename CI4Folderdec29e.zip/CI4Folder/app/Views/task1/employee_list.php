<!DOCTYPE html>
<html>
<head>
    <title>Employee List</title>
    <style>
        body { font-family: Arial; background:#f4f4f4; }
        table { border-collapse: collapse; width:90%; margin:40px auto; background:#fff; }
        th, td { border:1px solid #ccc; padding:10px; text-align:center; }
        th { background:#28a745; color:#fff; }
        .editing-row { background-color: #fff3cd !important; }
        .edit-field { width:100%; padding:3px; display:none; }
        .action-btn { cursor:pointer; border:none; background:none; }
    </style>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
</head>
<body>

<h2 style="text-align:center;">Employees</h2>
<div style="width:80%; margin:20px auto; text-align:right;">
    <a href="<?= base_url('/employees/create') ?>" style="padding:10px 15px; background:#28a745; color:#fff; text-decoration:none; border-radius:4px;">
        + Add Employee
    </a>
</div>

<table id="employeeTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Department</th>
            <th>Salary</th>
            <th>Email</th>
            <th>Date of Joining</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
<?php foreach ($employees as $row): ?>
<tr data-id="<?= $row['emp_id'] ?>">
    <td><?= $row['emp_id'] ?></td>
    <td><span class="text"><?= $row['emp_name'] ?></span>
        <input type="text" name="emp_name" class="edit-field" value="<?= $row['emp_name'] ?>"></td>
    <td><span class="text"><?= $row['department'] ?></span>
        <input type="text" name="department" class="edit-field" value="<?= $row['department'] ?>"></td>
    <td><span class="text"><?= $row['salary'] ?></span>
        <input type="text" name="salary" class="edit-field" value="<?= $row['salary'] ?>"></td>
    <td><span class="text"><?= $row['email'] ?></span>
        <input type="text" name="email" class="edit-field" value="<?= $row['email'] ?>"></td>
    <td><span class="text"><?= $row['date_of_joining'] ?></span>
        <input type="text" name="date_of_joining" class="edit-field" value="<?= $row['date_of_joining'] ?>"></td>
    <td>
        <button class="action-btn edit-btn"><i class="fa fa-pen" style="color:blue;"></i></button>
        <button class="action-btn save-btn" style="display:none;"><i class="fa fa-check" style="color:green;"></i></button>
        <button class="action-btn cancel-btn" style="display:none;"><i class="fa fa-times" style="color:orange;"></i></button>
        <a href="<?= base_url('employees/delete/'.$row['emp_id']) ?>" onclick="return confirm('Delete this employee?')">
            <i class="fa fa-trash" style="color:red;"></i>
        </a>
    </td>
</tr>
<?php endforeach; ?>
    </tbody>
</table>

<script>
$(document).ready(function(){
    $('#employeeTable').DataTable();

    // Edit
    $(document).on('click', '.edit-btn', function(){
        let row = $(this).closest('tr');
        row.addClass('editing-row');
        row.find('.text').hide();
        row.find('.edit-field').show();
        row.find('.edit-btn').hide();
        row.find('.save-btn, .cancel-btn').show();
    });

    // Cancel
    $(document).on('click', '.cancel-btn', function(){
        let row = $(this).closest('tr');
        row.removeClass('editing-row');
        row.find('.edit-field').each(function(){
            $(this).val($(this).siblings('.text').text());
        });
        row.find('.edit-field').hide();
        row.find('.text').show();
        row.find('.edit-btn').show();
        row.find('.save-btn, .cancel-btn').hide();
    });

    // Save
    $(document).on('click', '.save-btn', function(){
        let row = $(this).closest('tr');
        let id = row.data('id');
        let data = {};
        row.find('.edit-field').each(function(){
            data[$(this).attr('name')] = $(this).val();
        });

        // AJAX POST
        $.post("<?= base_url('employees/update') ?>/"+id, data, function(response){
            row.find('.edit-field').each(function(){
                $(this).siblings('.text').text($(this).val());
            });
            row.removeClass('editing-row');
            row.find('.edit-field').hide();
            row.find('.text').show();
            row.find('.edit-btn').show();
            row.find('.save-btn, .cancel-btn').hide();
        });
    });
});
</script>

</body>
</html>
