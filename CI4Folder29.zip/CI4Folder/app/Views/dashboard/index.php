<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<h3>Dashboard</h3>
<hr>

<div class="row justify-content-center g-3">
    <!-- Total Courses -->
    <div class="col-md-3">
        <div class="card text-white bg-primary mb-3 text-center">
            <div class="card-body">
                <h6>Total Courses</h6>
                <h3><?= $total ?></h3>
            </div>
        </div>
    </div>

    <!-- Active vs Inactive Pie Chart -->
    <div class="col-md-3">
        <div class="card mb-3 text-center">
            <div class="card-body">
                <h6>Active vs Inactive</h6>
                <canvas id="statusPieChart" height="120"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4 g-3">
    <div class="col-md-6">
        <canvas id="deptChart"></canvas>
    </div>
    <div class="col-md-6">
        <canvas id="semChart"></canvas>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Active vs Inactive Pie Chart
    const statusData = {
        labels: ['Active', 'Inactive'],
        datasets: [{
            data: [<?= $active ?>, <?= $inactive ?>],
            backgroundColor: [
                'rgba(40, 167, 69, 0.8)', // green
                'rgba(220, 53, 69, 0.8)'  // red
            ],
            borderWidth: 1
        }]
    };

    new Chart(document.getElementById('statusPieChart'), {
        type: 'pie',
        data: statusData,
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' },
                title: { display: false }
            }
        }
    });

    // Courses by Department (Bar)
    const deptData = {
        labels: <?= json_encode(array_keys($dept)) ?>,
        datasets: [{
            label: 'Courses by Department',
            data: <?= json_encode(array_values($dept)) ?>,
            backgroundColor: [
                'rgba(54, 162, 235, 0.7)',
                'rgba(255, 99, 132, 0.7)',
                'rgba(255, 206, 86, 0.7)',
                'rgba(75, 192, 192, 0.7)',
                'rgba(153, 102, 255, 0.7)'
            ]
        }]
    };

    new Chart(document.getElementById('deptChart'), {
        type: 'bar',
        data: deptData,
        options: {
            responsive: true,
            plugins: {
                legend: { display: true, position: 'top' },
                title: { display: true, text: 'Courses by Department' }
            },
            scales: {
                x: { title: { display: true, text: 'Department' } },
                y: { title: { display: true, text: 'Number of Courses' }, beginAtZero: true }
            }
        }
    });

    // Courses by Semester (Bar)
    const semData = {
        labels: <?= json_encode(array_keys($sem)) ?>,
        datasets: [{
            label: 'Courses by Semester',
            data: <?= json_encode(array_values($sem)) ?>,
            backgroundColor: [
                'rgba(255, 99, 132, 0.7)',
                'rgba(54, 162, 235, 0.7)',
                'rgba(255, 206, 86, 0.7)',
                'rgba(75, 192, 192, 0.7)',
                'rgba(153, 102, 255, 0.7)',
                'rgba(255, 159, 64, 0.7)',
                'rgba(201, 203, 207, 0.7)',
                'rgba(100, 149, 237, 0.7)'
            ]
        }]
    };

    new Chart(document.getElementById('semChart'), {
        type: 'bar',
        data: semData,
        options: {
            responsive: true,
            plugins: {
                legend: { display: true, position: 'top' },
                title: { display: true, text: 'Courses by Semester' }
            },
            scales: {
                x: { title: { display: true, text: 'Semester' } },
                y: { title: { display: true, text: 'Number of Courses' }, beginAtZero: true }
            }
        }
    });
</script>

<?= $this->endSection() ?>
