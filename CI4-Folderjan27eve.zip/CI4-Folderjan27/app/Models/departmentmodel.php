<?php
namespace App\Models;
use codeigniter\Model;
class departmentmodel extends Model {
    protected $table='emp';
    protected $primarykey='id';
    protected $allowedfields=['dept_code','dept_name','status','created_at','updated_at'];
    protected $usetimestamps=true;
}