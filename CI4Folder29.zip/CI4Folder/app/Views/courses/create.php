<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<h3>Add Course</h3>
<hr>

<?php if(session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <?php foreach(session()->getFlashdata('errors') as $error) echo $error.'<br>'; ?>
    </div>
<?php endif; ?>

<form id="courseform" action="/admin/courses/store" method="POST">

    <!-- Course Code -->
    <div class="mb-3">
        <label>Course Code</label>
        <input type="text"
               name="course_code"
               id="code"
               class="form-control"
               maxlength="6"
               required
               placeholder="ABC123"
               value="<?= old('course_code') ?>"
               autofocus>
        <small class="text-muted">Format: 3 letters + 3 numbers (ABC123)</small>
    </div>

    <!-- Course Name -->
    <div class="mb-3">
        <label>Course Name</label>
        <input type="text"
               name="course_name"
               class="form-control name"
               maxlength="20"
               required
               value="<?= old('course_name') ?>">
    </div>

    <!-- Department -->
    <div class="mb-3">
        <label>Department</label>
        <select name="department" class="form-control" required>
            <option value="">-- Select Department --</option>
            <?php 
            $departments = ['ECE','EEE','MECH','CSE','CIVIL'];
            foreach($departments as $dept):
            ?>
                <option value="<?= $dept ?>" <?= old('department')==$dept?'selected':'' ?>>
                    <?= $dept ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- Semester -->
    <div class="mb-3">
        <label>Semester</label>
        <select name="semester" class="form-control" required>
            <option value="">-- Select Semester --</option>
            <?php for($i=1;$i<=8;$i++): ?>
                <option value="<?= $i ?>" <?= old('semester')==$i?'selected':'' ?>>
                    <?= $i ?>
                </option>
            <?php endfor; ?>
        </select>
    </div>

    <!-- Credits -->
    <div class="mb-3">
        <label>Credits</label>
        <select name="credits" class="form-control" required>
            <option value="">-- Select Credits --</option>
            <?php for($i=1;$i<=10;$i++): ?>
                <option value="<?= $i ?>" <?= old('credits')==$i?'selected':'' ?>>
                    <?= $i ?>
                </option>
            <?php endfor; ?>
        </select>
    </div>

    <!-- Status -->
    

    <button class="btn btn-success">Save</button>
</form>

<!-- JS Validation and Focus -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
$(document).ready(function () {

    // Focus on Course Code reliably
    $("#code").focus();

    /* =====================================
       COURSE CODE VALIDATION
       Format: ABC123 (3 letters + 3 numbers)
       ===================================== */
    $("#code").on("input", function () {
        let value = $(this).val();

        // Remove special characters
        value = value.replace(/[^a-zA-Z0-9]/g, "");

        // Limit to 6 characters
        value = value.substring(0, 6);

        // First 3 only alphabets, next 3 only numbers
        if (value.length <= 3) {
            value = value.replace(/[^a-zA-Z]/g, "");
        } else {
            let first = value.substring(0, 3).replace(/[^a-zA-Z]/g, "");
            let second = value.substring(3).replace(/[^0-9]/g, "");
            value = first + second;
        }

        $(this).val(value.toUpperCase());
    });

    /* =====================================
       COURSE NAME VALIDATION
       Max 20 characters, letters & space only
       ===================================== */
    $(".name").on("input", function () {
        let value = $(this).val();

        // Allow only alphabets and space
        value = value.replace(/[^a-zA-Z ]/g, "");

        // Limit to 20 characters
        value = value.substring(0, 20);

        $(this).val(value);
    });

});
</script>

<?= $this->endSection() ?>
