<!DOCTYPE html>
<html>
<head>
    <title>Student Report</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <style>
        body { font-family: Arial; background: #f4f6f8; }
        .container { width: 95%; margin: 40px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1);}
        h2 { text-align: center; color: #333; margin-bottom: 20px; }
        .links a { display:inline-block; margin:5px; color:#007bff; text-decoration:none; font-size:24px; }
        .links a:hover { color:#0056b3; }
        .success { color:green; text-align:center; margin-bottom:15px; font-weight:bold; }
    </style>
</head>
<body>

<div class="container">
    <h2>Student Report</h2>

    <?php if(!empty($success)): ?>
        <div class="success"><?= $success ?></div>
    <?php endif; ?>
    <?php if(!empty($skipped)): ?>
        <div class="success"><?= $skipped ?> records skipped due to duplicate email</div>
    <?php endif; ?>

    <!-- ICON LINKS -->
    <div class="links" style="text-align:center;">
        <a href="/student" title="Upload Students"><i class="fas fa-upload"></i></a>
        <a href="/student/history" title="History"><i class="fas fa-history"></i></a>
        <a href="/student/deleteAll" onclick="return confirm('Are you sure?')" title="Delete All"><i class="fas fa-trash"></i></a>
        <a href="/student/downloadReport" title="Download Report"><i class="fas fa-file-download"></i></a>
        <a href="<?= base_url('student(2).xlsx') ?>" download title="Download Template"><i class="fas fa-file-excel"></i></a>
    </div>

    <!-- STUDENT TABLE -->
    <table id="studentsTable" class="display">
        <thead>
            <tr>
                <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Mark</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($students as $s): ?>
            <tr>
                <td><?= $s['id'] ?></td>
                <td><?= $s['name'] ?></td>
                <td><?= $s['email'] ?></td>
                <td><?= $s['phone'] ?></td>
                <td><?= $s['mark'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- JS -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#studentsTable').DataTable();
    });
</script>
</body>
</html>
