<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
        }

        .header {
            background: #007bff;
            color: #fff;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
        }

        .profile {
            position: relative;
        }

        .profile button {
            background: none;
            border: none;
            color: #fff;
            font-size: 16px;
        }

        .profile-content {
            display: none;
            position: absolute;
            right: 0;
            background: #fff;
            min-width: 150px;
        }

        .profile:hover .profile-content {
            display: block;
        }

        .profile-content a {
            padding: 10px;
            display: block;
            text-decoration: none;
            color: #333;
        }

        .container {
            padding: 30px;
            max-width: 500px;
            margin: auto;
            background: #fff;
            margin-top: 30px;
            border-radius: 6px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }

        .btn {
            margin-top: 15px;
            padding: 10px;
            width: 100%;
            background: #007bff;
            color: #fff;
            border: none;
        }
    </style>
</head>
<body>

<div class="header">
    <h2>Edit Product</h2>
    <div class="profile">
        <button><i class="fas fa-user-circle"></i> <?= session()->get('role') ?></button>
        <div class="profile-content">
            <a href="/logout">Logout</a>
        </div>
    </div>
</div>

<div class="container">

<?php if(session()->getFlashdata('error')): ?>
    <p style="color:red"><?= session()->getFlashdata('error') ?></p>
<?php endif; ?>

<form action="/products/update/<?= $product['id'] ?>" method="post">

    <label>Product Name</label>
    <input type="text" name="product_name" value="<?= $product['product_name'] ?>" required>

    <label>SKU</label>
    <input type="text" name="sku" value="<?= $product['sku'] ?>" required>

    <label>Price</label>
    <input type="number" step="0.01" name="price" value="<?= $product['price'] ?>" required>

    <label>Stock</label>
    <input type="number" name="stock" value="<?= $product['stock'] ?>" required>

    <button type="submit" class="btn">Update Product</button>
</form>

<br>
<a href="/products">⬅ Back to Products</a>

</div>
</body>
</html>
