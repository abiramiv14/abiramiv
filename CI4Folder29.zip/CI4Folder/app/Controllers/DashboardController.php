<?php namespace App\Controllers;

use App\Models\CourseModel;

class DashboardController extends BaseController
{
    protected $courseModel;

    public function __construct()
    {
        $this->courseModel = new CourseModel();
    }

    public function index()
    {
        $courses = $this->courseModel->getCourses();

        $data['total'] = count($courses);
        $data['active'] = count(array_filter($courses, fn($c) => $c['status']=='Active'));
        $data['inactive'] = count(array_filter($courses, fn($c) => $c['status']=='Inactive'));

        $dept = [];
        $sem = [];
        foreach($courses as $c){
            $dept[$c['department']] = ($dept[$c['department']] ?? 0)+1;
            $sem[$c['semester']] = ($sem[$c['semester']] ?? 0)+1;
        }
        $data['dept'] = $dept;
        $data['sem'] = $sem;

        echo view('dashboard/index', $data);
    }
}
