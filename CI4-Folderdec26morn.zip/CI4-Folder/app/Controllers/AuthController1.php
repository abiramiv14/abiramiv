<?php namespace App\Controllers;

use App\Models\UserModel;

class AuthController1 extends BaseController {
    public function login() {
        return view('login');
    }

    public function loginPost() {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $userModel = new UserModel();
        $user = $userModel->where('email', $email)->first();

        if(!$user || $password != $user['password']) {
            return redirect()->back()->with('error','Invalid credentials');
        }

        session()->set([
            'user_id' => $user['id'],
            'role' => $user['role'],
            'name' => $user['name']
        ]);

        return redirect()->to('/allocations');
    }

    public function logout() {
        session()->destroy();
        return redirect()->to('/login');
    }
}
