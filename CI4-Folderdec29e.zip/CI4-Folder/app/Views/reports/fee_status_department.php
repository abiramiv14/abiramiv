<!DOCTYPE html>
<html>
<head>
    <title>Fee Payment Status by Department</title>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
</head>
<body>

<h2>Fee Payment Status by Department</h2>
<div id="chart"></div>

<script>
var departments = [];
var paidData = [];
var notPaidData = [];

<?php foreach($feeData as $row){ ?>
    departments.push("<?= $row['department_name'] ?>");
    paidData.push(<?= $row['paid'] ?>);
    notPaidData.push(<?= $row['not_paid'] ?>);
<?php } ?>

var options = {
    series: [
        {
            name: 'Paid',
            data: paidData
        },
        {
            name: 'Not Paid',
            data: notPaidData
        }
    ],
    chart: {
        type: 'bar',
        stacked: true,
        height: 400
    },
    xaxis: {
        categories: departments,
        title: {
            text: 'Departments'
        }
    },
    yaxis: {
        title: {
            text: 'Number of Students'
        }
    },
    legend: {
        position: 'top'
    },
    tooltip: {
        y: {
            formatter: function(val){
                return val + " students";
            }
        }
    }
};

var chart = new ApexCharts(document.querySelector("#chart"), options);
chart.render();
</script>

</body>
</html>
