<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold text-dark">Dashboard Overview</h2>
        <p class="text-muted">Welcome back, <?= session()->get('admin_name') ?></p>
    </div>
    <div class="text-end">
        <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill">
            <i class="bi bi-calendar3 me-1"></i> <?= date('D, M d, Y') ?>
        </span>
    </div>
</div>

<!-- Stats Cards -->
<div class="row g-4 mb-5">
    <!-- Total Courses -->
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100 bg-white border-start border-4 border-primary">
            <div class="card-body d-flex align-items-center">
                <div class="rounded-circle bg-primary bg-opacity-10 p-3 me-3">
                    <i class="bi bi-book fs-3 text-primary"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase mb-1 fw-bold" style="font-size: 0.75rem;">Total Courses</h6>
                    <h3 class="fw-bold mb-0"><?= $total ?></h3>
                </div>
            </div>
        </div>
    </div>
    <!-- Active Courses -->
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100 bg-white border-start border-4 border-success">
            <div class="card-body d-flex align-items-center">
                <div class="rounded-circle bg-success bg-opacity-10 p-3 me-3">
                    <i class="bi bi-check-circle fs-3 text-success"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase mb-1 fw-bold" style="font-size: 0.75rem;">Active Courses</h6>
                    <h3 class="fw-bold mb-0"><?= $active ?></h3>
                </div>
            </div>
        </div>
    </div>
    <!-- Inactive Courses -->
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100 bg-white border-start border-4 border-danger">
            <div class="card-body d-flex align-items-center">
                <div class="rounded-circle bg-danger bg-opacity-10 p-3 me-3">
                    <i class="bi bi-x-circle fs-3 text-danger"></i>
                </div>
                <div>
                    <h6 class="text-muted text-uppercase mb-1 fw-bold" style="font-size: 0.75rem;">Inactive Courses</h6>
                    <h3 class="fw-bold mb-0"><?= $inactive ?></h3>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts Section -->
<div class="row g-4">
    <!-- Department Distribution -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 pt-4 px-4">
                <h5 class="fw-bold mb-0">Department Distribution</h5>
            </div>
            <div class="card-body">
                <canvas id="deptChart"></canvas>
            </div>
        </div>
    </div>
    <!-- Semester Distribution -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 pt-4 px-4">
                <h5 class="fw-bold mb-0">Semester Distribution</h5>
            </div>
            <div class="card-body">
                <canvas id="semChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Script for Charts -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Common Chart Options
        Chart.defaults.font.family = "'Inter', sans-serif";
        Chart.defaults.color = '#64748b';

        // Data passed from PHP to JS
        const deptData = <?= json_encode($dept) ?>;
        const semData = <?= json_encode($sem) ?>;

        // Department Chart
        new Chart(document.getElementById('deptChart'), {
            type: 'doughnut',
            data: {
                labels: Object.keys(deptData),
                datasets: [{
                    data: Object.values(deptData),
                    backgroundColor: ['#4361ee', '#3a0ca3', '#7209b7', '#f72585', '#4cc9f0'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });

        // Semester Chart
        new Chart(document.getElementById('semChart'), {
            type: 'bar',
            data: {
                labels: Object.keys(semData).map(s => 'Sem ' + s),
                datasets: [{
                    label: 'Courses',
                    data: Object.values(semData),
                    backgroundColor: '#4361ee',
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true, grid: { borderDash: [2, 4] } },
                    x: { grid: { display: false } }
                }
            }
        });
    });
</script>

<?= $this->endSection() ?>