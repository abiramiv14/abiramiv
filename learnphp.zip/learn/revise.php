<?php
$studentname="abi";
$regno=101;
$dep="ece";
echo "student name: " . $studentname ."<br>";
echo $regno."<br>";
echo $dep;  

$username="abi";
$password=1243;
if($username=='abi' && $password=1243){
    echo'login';
    }else{
        echo'fail';
    }
$attendance=75;

$test1=87;
$test2=65;
$test3=90;
$total=$test1+$test2+$test3;
echo "$total";

$subjects=["maths","science","social","english"];
foreach($subjects as $subject){
    echo $subject;
}


?>


