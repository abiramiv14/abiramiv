<?php
namespace App\Controllers;

use App\Models\DepartmentReportModel;

class reports extends BaseController
{
    public function departmentStudentStrength()
    {
        $model = new DepartmentReportModel();
        $data['chartData'] = $model->getDepartmentWiseCount();

        return view('reports/department_student_strength', $data);
    }
    public function attendanceCategoryDistribution()
{
    $model = new \App\Models\AttendanceReportModel();
    $data['attendanceData'] = $model->getAttendanceCategoryCount();

    return view('reports/attendance_category', $data);
}

}
