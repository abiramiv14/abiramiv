<?php
namespace App\Models;

use CodeIgniter\Model;

class ResultReportModel extends Model
{
    public function getPassPercentageBySemester()
    {
        return $this->db->table('results')
            ->select("
                semester,
                ROUND(SUM(CASE WHEN result_status='Pass' THEN 1 ELSE 0 END) * 100.0 / COUNT(student_id),2) AS pass_percentage
            ")
            ->groupBy('semester')
            ->orderBy('semester', 'ASC')
            ->get()
            ->getResultArray();
    }
}
