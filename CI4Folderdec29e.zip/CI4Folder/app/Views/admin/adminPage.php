<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        /* Background & font */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Card container */
        .admin-card {
            background: #ffffff;
            border-radius: 15px;
            padding: 40px;
            width: 450px;
            text-align: center;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .admin-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
        }

        h2 {
            margin-bottom: 20px;
            font-size: 28px;
            color: #333;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        p {
            font-size: 16px;
            margin-bottom: 30px;
            color: #555;
        }

        .logout-btn {
            text-decoration: none;
            display: inline-block;
            padding: 12px 25px;
            font-size: 16px;
            background: #007bff;
            color: #fff;
            border-radius: 50px;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .logout-btn:hover {
            background: #0056b3;
            transform: translateY(-3px);
        }

        /* Responsive */
        @media screen and (max-width: 500px) {
            .admin-card {
                width: 90%;
                padding: 30px;
            }
        }
    </style>
</head>

<body>

<div class="admin-card">
    <h2>Admin Dashboard</h2>
    <p>
        Welcome, <b><?= session()->get('email') ?></b><br>
        (Role: <?= session()->get('role') ?>)
    </p>
    <a href="<?= base_url('roll/login') ?>" class="logout-btn">Logout</a>
</div>

</body>
</html>
