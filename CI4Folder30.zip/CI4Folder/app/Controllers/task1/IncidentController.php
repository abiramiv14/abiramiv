<?php

namespace App\Controllers\task1;

use CodeIgniter\Controller;
use App\Models\task1\IncidentModel;

class IncidentController extends Controller
{
    
    public function add()
    {
        return view('task1/incident_form');
    }

    
    public function saveIncident()
    {
        $model = new IncidentModel();

        $data = [
            'title'         => $this->request->getPost('title'),
            'description'   => $this->request->getPost('description'),
            'department'    => $this->request->getPost('department'),
            'priority'      => $this->request->getPost('priority'),
            'incident_date' => $this->request->getPost('incident_date')
        ];

        $model->insert($data);   

        return redirect()->to('/incidents');
    }

    
    public function viewIncidents()
    {
        $model = new IncidentModel();
        $data['incidents'] = $model->findAll();   

        return view('task1/incident_list', $data);
    }
    public function update($incident_id)
    {
        $model= new IncidentModel();
        $model->update($incident_id,[
            'title'=> $this->request->getPost('title'),
            'description'=> $this->request->getPost('description'),
            'department'=> $this->request->getPost('department'),
            'priority'=> $this->request->getPost('priority'),
            'incident_date'=> $this->request->getPost('incident_date')
        ]);
        return redirect()->to('/incidents');
    }
    public function delete($incident_id)
    {
        $model= new IncidentModel();
        $model->delete($incident_id);
        return redirect()->to('/incidents');
    }
}
