<?php
namespace App\Controllers;

use App\Models\UserModel;

class AuthController extends BaseController
{
    public function login()
    {
        return view('auth/login');
    }

    public function loginPost()
    {
        $userModel = new UserModel();

        $user = $userModel->where('username',$this->request->getPost('username'))->first();

        if(!$user || $user['password'] != $this->request->getPost('password')){
            return redirect()->back()->with('error','Invalid Login');
        }

        session()->set([
            'user_id' => $user['id'],
            'role' => $user['role'],
            'student_id' => $user['student_id'],
            'logged_in' => true
        ]);

        return ($user['role']=='admin')
            ? redirect()->to('/admin/fees')
            : redirect()->to('/student/fees');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}
