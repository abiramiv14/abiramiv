<?php

namespace App\Controllers\task1;

use CodeIgniter\Controller;
use App\Models\task1\ProductModel;

class ProductController extends Controller
{
    
    public function create()
    {
        return view('task1/product_form');
    }

    
    public function store()
    {
        $model = new ProductModel();

        $data = [
            'product_name' => $this->request->getPost('product_name'),
            'category'     => $this->request->getPost('category'),
            'price'        => $this->request->getPost('price'),
            'stock_quantity'    => $this->request->getPost('stock_quantity'),
            'description'  => $this->request->getPost('description')
        ];

        
        if (!$model->insert($data)) {
            return view('task1/product_form', [
                'errors' => $model->errors()
            ]);
        }

        return redirect()->to('/products');
    }

    
    public function index()
    {
        $model = new ProductModel();
        $data['products'] = $model->findAll(); 
        return view('task1/product_list', $data);
    }
}
