<!DOCTYPE html>
<html>
<head>
    <title>Course Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 400px;
            margin: 50px auto;
            background: #fff;
            padding: 30px 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        form input {
            width: 100%;
            padding: 12px 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }

        form button {
            width: 100%;
            padding: 12px;
            background: #ffc107;
            color: #000;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 15px;
            transition: background 0.3s;
        }

        form button:hover {
            background: #e0a800;
        }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Common validation JS -->
    <script src="<?= base_url('assets/js/jqueryvalidation.js') ?>"></script>
</head>
<body>
    <div class="container">
        <script>
            $(document).ready(function () {
                $("#name").focus();
            });
        </script>

        <form method="post" action="<?= base_url('/courses/store') ?>">
            <h2>Course Registration</h2>

            <input type="text" name="student_name" placeholder="Student Name" class="name" id="name" required>
            <input type="text" name="course_name" placeholder="Course Name" class="name" required>
            <input type="text" name="semester" placeholder="Semester" class="semester-range">
            <input type="text" name="fees" placeholder="Fees" class="salary-range">
            <input type="email" name="email" placeholder="Email" class="email">

            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>
