<?php
namespace App\Models\task1;
use  CodeIgniter\Model;
class EmployeeModel extends Model

{
    protected $table = 'employees';
    protected $primaryKey = 'emp_id';

    protected $allowedFields = [
        'emp_name',
        'department',
        'salary',
        'email',
        'date_of_joining'
    ];
}

