<?php
namespace App\Controllers\incident;
use CodeIgniter\Controller;
use App\Models\incident\Usermodel;
class AuthController extends Controller
{
    public function login(){
        return view("inc/login");
    }
    public function loginPost(){
        $session=session();
        $UserModel=new Usermodel();
        $email=$this->request->getPost('email');
        $password=$this->request->getPost('password');
        $user=$UserModel->where('email',$email)->first();
        if(!$user ||$password !==$user->password){
            return redirect()->back()->with('error','Invalid email or password');
        }
    
    $session->set([
        'user_id'=> $user['id'],
        'role'=>$user['role'],
        'isLoggedIn' => 'true'
    ]);
    return redirect()->to('/incident');
}
    public function Logout(){
        session()->destroy();
    }
}