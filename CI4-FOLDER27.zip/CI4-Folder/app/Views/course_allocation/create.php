<!DOCTYPE html>
<html>
<head>
    <title>Add Allocation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Add New Allocation</h2>
    <form method="post" action="/course_allocation/store">
        <div class="mb-3">
            <label>Course:</label>
            <select name="course_id" class="form-select" required>
                <option value="">Select Course</option>
                <?php foreach($courses as $c): ?>
                    <option value="<?= $c['id'] ?>"><?= $c['course_name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Faculty:</label>
            <select name="faculty_id" class="form-select" required>
                <option value="">Select Faculty</option>
                <?php foreach($faculty as $f): ?>
                    <option value="<?= $f['id'] ?>"><?= $f['name'] ?> (<?= $f['department'] ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Academic Year:</label>
            <select name="academic_year" class="form-select" required>
                <option value="2025-2028">2025-2028</option>
                
            </select>
        </div>
        <div class="mb-3">
            <label>Semester:</label>
            <select name="semester" class="form-select" required>
                <option value="1">1</option>
                <option value="2">2</option>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Save Allocation</button>
        <a href="/course_allocation" class="btn btn-secondary">Back</a>
    </form>
</div>
</body>
</html>
