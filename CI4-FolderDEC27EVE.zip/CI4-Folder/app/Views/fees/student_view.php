<h2>My Payments</h2>
<table border="1">
<tr>
    <th>Receipt</th><th>Semester</th><th>Fee</th><th>Paid</th><th>Due</th><th>Date</th>
</tr>
<?php foreach($payments as $pay): ?>
<tr>
    <td><?= $pay['receipt_no'] ?></td>
    <td><?= $pay['semester'] ?></td>
    <td><?= $pay['fee_formatted'] ?></td>
    <td><?= $pay['paid_formatted'] ?></td>
    <td><?= $pay['due_formatted'] ?></td>
    <td><?= $pay['payment_date'] ?></td>
</tr>
<?php endforeach; ?>
</table>
