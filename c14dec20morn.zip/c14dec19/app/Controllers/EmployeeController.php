<?php
namespace App\Controllers;

use App\Models\EmployeeModel;
use CodeIgniter\Controller;

class EmployeeController extends Controller
{
    protected $employeeModel;

    public function __construct()
    {
        $this->employeeModel = new EmployeeModel();
    }

    // ================= LIST =================
    public function index()
 {
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');

        if ($role === 'HR') {
            $employees = $this->employeeModel
                ->where('department', $department)
                ->findAll();
        } else {
            $employees = $this->employeeModel->findAll();
        }

        return view('employees/index', [
            'employees' => $employees,
            'role'      => $role
        ]);
    }

    // ================= CREATE FORM =================
    public function create()
    {
        $session = session();

        return view('employees/create', [
            'role'       => $session->get('role'),
            'department' => $session->get('department')
        ]);
    }

    // ================= STORE =================
    public function store()
{
    $session = session();
    $role = $session->get('role');
    $department = $session->get('department');

    $data = $this->request->getPost();

    // 🔒 FORCE values for HR (IMPORTANT)
    if ($role === 'HR') {
        $data['role'] = 'Staff';
        $data['department'] = ucfirst(strtolower(trim($department)));
    }

    // Admin safety check
    if ($role === 'Admin' && !in_array($data['role'], ['Staff', 'Manager'])) {
        return redirect()->back()->with('error', 'Invalid role selection');
    }

    if (!$this->employeeModel->insert($data)) {
        return redirect()->back()
            ->withInput()
            ->with('errors', $this->employeeModel->errors());
    }

    return redirect()->to('/employees')->with('success', 'Employee added successfully');
}


    // ================= EDIT FORM =================
    public function edit($id)
    {
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');

        $employee = $this->employeeModel->find($id);
        if (!$employee) {
            return redirect()->to('/employees')->with('error', 'Employee not found');
        }

        if ($role === 'HR' && $employee['department'] !== $department) {
            return redirect()->to('/employees')->with('error', 'Unauthorized');
        }

        return view('employees/edit', [
            'employee'   => $employee,
            'role'       => $role,
            'department' => $department
        ]);
    }

    // ================= UPDATE =================
    public function update($id)
    {
        $data = $this->request->getPost();
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');

        $employee = $this->employeeModel->find($id);
        if (!$employee) {
            return redirect()->to('/employees')->with('error', 'Employee not found');
        }

        if ($role === 'HR' && $employee['department'] !== $department) {
            return redirect()->to('/employees')->with('error', 'Unauthorized');
        }

        // 🔐 ADMIN can update ONLY Staff or Manager
        if ($role === 'Admin' && !in_array($data['role'], ['Staff', 'Manager'])) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Invalid role update');
        }

        // 🔐 HR cannot change role or department
        if ($role === 'HR') {
            $data['role'] = 'Staff';
            $data['department'] = $employee['department'];
        }

        // Validation (NO Admin role allowed)
        $this->employeeModel->setValidationRules([
            'emp_name'   => 'required|min_length[3]|max_length[100]',
            'email'      => 'required|valid_email|is_unique[employees.email,id,' . $id . ']',
            'department' => 'required|in_list[Sales,Finance]',
            'role'       => 'required|in_list[Staff,Manager]'
        ]);

        if (!$this->employeeModel->update($id, $data)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->employeeModel->errors());
        }

        return redirect()->to('/employees')
            ->with('success', 'Employee updated successfully');
    }

    // ================= DELETE =================
    public function delete($id)
    {
        $session = session();
        $role = $session->get('role');
        $department = $session->get('department');

        $employee = $this->employeeModel->find($id);
        if (!$employee) {
            return redirect()->to('/employees')->with('error', 'Employee not found');
        }

        if ($role !== 'Admin') {
        return redirect()->to('/employees')->with('error', 'Unauthorized: Only Admin can delete employees');
    }

        $this->employeeModel->delete($id);

        return redirect()->to('/employees')
            ->with('success', 'Employee deleted successfully');
    }
}
