<?php namespace App\Models;

use CodeIgniter\Model;

class CourseModel extends Model
{
    protected $table = 'courses';
    protected $primaryKey = 'id';
    protected $allowedFields = ['course_code','course_name','department','semester','credits','status','created_at','deleted_at'];
    protected $updatedField  = 'updated_at';
    protected $returnType = 'array';
   protected $useTimestamps = true;
  protected $useSoftDeletes = true;
  protected $createdField = 'created_at';
  protected $deletedField = 'deleted_at';

    public function getCourses()
    {
        return $this->where('deleted_at', null)->orderBy('id','DESC')->findAll();
    }
}
