<?php

namespace App\Models;

use CodeIgniter\Model;

class DepartmentReportModel extends Model
{
    public function getDepartmentWiseStudentCount()
    {
        return $this->db->table('departments d')
            ->select('d.department_name, COUNT(s.id) AS student_count')
            ->join('students s', 's.department_id = d.id', 'left')
            ->groupBy('d.id')
            ->get()
            ->getResultArray();
    }
}
