<?php
namespace App\Controllers;

use App\Models\ProductModel;
use CodeIgniter\Controller;

class CartController extends Controller
{
    // Show products page
    public function showForm()
    {
        helper(['form','url']);

        $model = new ProductModel();
        $data['products'] = $model->findAll();

        return view('cart_form', $data);
    }

    // Add product to cart (SESSION SAFE)
    public function addToCart()
    {
        helper(['form','url']);
        $session = session();

        $item = [
            'name'     => $this->request->getPost('product_name'),
            'price'    => (int) $this->request->getPost('price'),
            'quantity' => (int) $this->request->getPost('quantity')
        ];

        // Get existing cart
        $cart = $session->get('cart');

        // If cart is not array, create new
        if (!is_array($cart)) {
            $cart = [];
        }

        // Add item to cart
        $cart[] = $item;

        // Save back to session
        $session->set('cart', $cart);

        return redirect()->to('/cart');
    }

    // View cart
    public function viewCart()
    {
        helper(['url']);

        $data['cart'] = session()->get('cart') ?? [];

        return view('cart_view', $data);
    }

    // Remove item from cart
    public function removeItem($key)
    {
        $session = session();
        $cart = $session->get('cart');

        if (is_array($cart) && isset($cart[$key])) {
            unset($cart[$key]);
            $cart = array_values($cart); // reindex
            $session->set('cart', $cart);
        }

        return redirect()->to('/cart');
    }

    // 🔥 RUN THIS ONCE ONLY (then remove)
    public function clearCart()
    {
        session()->destroy();
        return redirect()->to('/cart');
    }
}
