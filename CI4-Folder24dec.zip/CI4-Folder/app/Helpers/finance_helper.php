<?php

if (!function_exists('formatINR')) {
    function formatINR($amount) {
        return '₹' . number_format($amount, 0, '.', ',');
    }
}

if (!function_exists('calculateDue')) {
    function calculateDue($fee, $paid) {
        return max($fee - $paid, 0);
    }
}

if (!function_exists('generateReceiptNo')) {
    function generateReceiptNo($studentId) {
        $prefix = "REC-" . date('Y') . "-";
        $rand = str_pad($studentId, 4, "0", STR_PAD_LEFT);
        return $prefix . $rand;
    }
}
