<?php
namespace App\Models\inventory;

use CodeIgniter\Model;
use App\Models\inventory\StockLogModel;
class ProductModel extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'product_name',
        'sku',
        'price',
        'stock'
    ];

    protected $useTimestamps = true;


// ProductModel.php
protected $afterUpdate = ['logStockChange'];

protected function logStockChange(array $data)
{
    if (!isset($data['data']['stock'])) return;

    $oldStock = $data['old']['stock'] ?? 0;
    $newStock = $data['data']['stock'];

    if ($oldStock == $newStock) return;

    $stockLog = new StockLogModel();
    $stockLog->insert([
        'product_id'   => $data['id'][0],
        'change_qty'   => $newStock - $oldStock,
        'stock_before' => $oldStock,
        'stock_after'  => $newStock,
        'changed_by'   => session()->get('user_id')
    ]);
}
}