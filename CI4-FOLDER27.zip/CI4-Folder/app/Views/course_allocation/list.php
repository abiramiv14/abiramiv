<!DOCTYPE html>
<html>
<head>
    <title>Course Allocations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Course Allocations</h2>
    <div class="mb-3">
        <?php if(session()->get('role') == 'admin'): ?>
            <a href="/course_allocation/create" class="btn btn-primary">Add New Allocation (2025-2028)</a>
        <?php endif; ?>
        <a href="/logout" class="btn btn-secondary float-end">Logout</a>
    </div>

    <div class="mb-3">
        <label>Filter by Academic Year:</label>
        <select id="yearFilter" class="form-select w-25">
            <option value="">All</option>
            <?php
            $years = array_unique(array_column($allocations,'academic_year'));
            foreach($years as $y){
                echo "<option value='$y'>$y</option>";
            }
            ?>
        </select>
    </div>

    <table id="allocationsTable" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Course Name</th>
                <th>Faculty Name</th>
                <th>Academic Year</th>
                <th>Semester</th>
                <?php if(session()->get('role') == 'admin'): ?>
                    <th>Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach($allocations as $alloc): ?>
            <tr>
                <td><?= $alloc['id'] ?></td>
                <td><?= $alloc['course_name'] ?></td>
                <td><?= $alloc['faculty_name'] ?></td>
                <td><?= $alloc['academic_year'] ?></td>
                <td><?= $alloc['semester'] ?></td>
                <?php if(session()->get('role') == 'admin'): ?>
                <td>
                    <?php if($alloc['academic_year'] == '2025-2028'): ?>
                        <a href="/course_allocation/edit/<?= $alloc['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="/course_allocation/delete/<?= $alloc['id'] ?>" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</a>
                    <?php else: ?>
                        <span class="text-muted">View Only</span>
                    <?php endif; ?>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    var table = $('#allocationsTable').DataTable();

    $('#yearFilter').on('change', function(){
        var val = $(this).val();
        table.column(3).search(val).draw();
    });
});
</script>
</body>
</html>
