<?php
namespace App\Controllers\inventory;

use CodeIgniter\Controller;
use App\Models\inventory\ProductModel;
use App\Models\inventory\StockLogModel;

class ProductController extends Controller
{
    protected $productModel;
    protected $stockLogModel;

    public function __construct()
    {
        $this->productModel = new ProductModel();
        $this->stockLogModel = new StockLogModel();
    }

    // =====================
    // PRODUCT LIST
    // =====================
    public function index()
    {
        return view('products/index', [
            'products' => $this->productModel->findAll(),
            'role'     => session()->get('role')
        ]);
    }

    // =====================
    // CREATE FORM
    // =====================
    public function create()
    {
        return view('products/create');
    }

    // =====================
    // STORE PRODUCT
    // =====================
    public function store()
    {
        $data = $this->request->getPost();

        if (!$this->productModel->insert($data)) {
            return redirect()->back()->with('error', 'Failed to create product');
        }

        return redirect()->to('/products')->with('success', 'Product created successfully');
    }

    // =====================
    // EDIT FORM
    // =====================
    public function edit($id)
    {
        $product = $this->productModel->find($id);

        if (!$product) {
            return redirect()->to('/products')->with('error', 'Product not found');
        }

        return view('products/edit', ['product' => $product]);
    }

    // =====================
    // UPDATE PRODUCT (TRANSACTION SAFE)
    // =====================
    public function update($id)
{
    $db = \Config\Database::connect();
    $db->transStart(); // start transaction

    // Load product using same DB
    $product = $db->table('products')
                  ->where('id', $id)
                  ->get()
                  ->getRowArray();

    if (!$product) {
        $db->transRollback();
        return redirect()->back()->with('error', 'Product not found');
    }

    $newStock = (int)$this->request->getPost('stock');

    if ($newStock < 0) {
        $db->transRollback();
        return redirect()->back()->with('error', 'Stock cannot be negative');
    }

    $userId = session()->get('user_id');
    if (!$userId) {
        $db->transRollback();
        return redirect()->back()->with('error', 'Session expired');
    }

    // Update product
    $update = $db->table('products')
                 ->where('id', $id)
                 ->update([
                     'product_name' => $this->request->getPost('product_name'),
                     'sku'          => $this->request->getPost('sku'),
                     'price'        => $this->request->getPost('price'),
                     'stock'        => $newStock
                 ]);

    if (!$update) {
        $db->transRollback();
        return redirect()->back()->with('error', 'Update failed (product)');
    }

    // Log stock change in same transaction
    $insert = $db->table('stock_logs')->insert([
        'product_id'   => $id,
        'change_qty'   => $newStock - $product['stock'],
        'stock_before' => $product['stock'],
        'stock_after'  => $newStock,
        'changed_by'   => $userId,
        'created_at'   => date('Y-m-d H:i:s')
    ]);

    if (!$insert) {
        $db->transRollback();
        return redirect()->back()->with('error', 'Update failed (stock log)');
    }

    $db->transComplete(); // commit

    return redirect()->to('/products')->with('success', 'Product updated successfully');
}

    // =====================
    // DELETE PRODUCT
    // =====================
    public function delete($id)
    {
        if (session()->get('role') !== 'Admin') {
            return redirect()->to('/products')->with('error', 'Unauthorized');
        }

        $this->productModel->delete($id);
        return redirect()->to('/products')->with('success', 'Product deleted');
    }

    // =====================
    // STOCK HISTORY
    // =====================
    public function history($id)
    {
        $logs = $this->stockLogModel
                     ->where('product_id', $id)
                     ->findAll();

        return view('products/stock_history', ['logs' => $logs]);
    }

    // =====================
    // ADD TO CART (VIEWER)
    // =====================
    public function addToCart($id)
    {
        $cart = session()->get('cart') ?? [];

        if (!in_array($id, $cart)) {
            $cart[] = $id;
        }

        session()->set('cart', $cart);

        return redirect()->back()->with('success', 'Added to cart');
    }
    public function viewCart()
{
    $cart = session()->get('cart') ?? [];
    $products = $this->productModel->whereIn('id', $cart)->findAll();

    return view('products/cart', ['products' => $products]);
}

}

