<?php namespace App\Controllers;

use App\Models\StudentFeeModel;
use App\Models\StudentModel;

class FeeController extends BaseController
{
    // List all fees
    public function index()
{
    $model = new StudentFeeModel();

    if (session('role') == 'student') {

        $fees = $model
            ->where('student_id', session('student_id'))
            ->orderBy('id', 'DESC')
            ->findAll();

    } else { // admin

        $fees = $model
            ->orderBy('id', 'DESC')   // ✅ THIS LINE FIXES IT
            ->findAll();
    }

    return view('fees/list', ['fees' => $fees]);
}

    // Show create payment form
    public function create()
    {
        if(session('role') != 'admin') return redirect()->to('/login');

        $studentModel = new StudentModel();
        $students = $studentModel->findAll();

        // Pass empty fees to avoid undefined variable in create view
        $fees = [];

        return view('fees/create', [
            'students' => $students,
            'fees' => $fees
        ]);
    }

    // Store new payment
    public function store()
    {
        if(session('role') != 'admin') return redirect()->to('/login');

        $student_id = $this->request->getPost('student_id');
        $fee = $this->request->getPost('fee_amount');
        $paid = $this->request->getPost('paid_amount');

        if($paid > $fee){
            return redirect()->back()->with('error','Paid amount cannot exceed total fee');
        }

        $due = calculateDue($fee, $paid);

        $model = new StudentFeeModel();
        $model->insert([
            'student_id' => $student_id,
            'semester' => $this->request->getPost('semester'),
            'fee_amount' => $fee,
            'paid_amount' => $paid,
            'due_amount' => $due,
            'payment_mode' => $this->request->getPost('payment_mode'),
            'payment_date' => date('Y-m-d'),
            'created_by' => session('user_id')
        ]);

        $lastId = $model->getInsertID();

        // If fully paid, generate receipt
        if($due == 0){
            $receipt = generateReceiptNo($student_id);
            $model->update($lastId, ['receipt_no' => $receipt]);
        }

        return redirect()->to('/fees')->with('success','Payment recorded successfully');
    }

    // Edit payment
    public function edit($id)
    {
        $model = new StudentFeeModel();
        $fee = $model->find($id);

        if(!$fee) return redirect()->to('/fees')->with('error','Payment not found');

        if($fee['due_amount'] == 0){
            return redirect()->to('/fees')->with('error','Payment completed. Cannot edit.');
        }

        $studentModel = new StudentModel();
        $students = $studentModel->findAll();

        return view('fees/edit', [
            'fee' => $fee,
            'students' => $students
        ]);
    }

    // Update payment
    public function update($id)
    {
        $model = new StudentFeeModel();
        $feeData = $model->find($id);

        if(!$feeData) return redirect()->to('/fees')->with('error','Payment not found');

        if($feeData['due_amount'] == 0){
            return redirect()->to('/fees')->with('error','Payment completed. Cannot update.');
        }

        $fee = $this->request->getPost('fee_amount');
        $paid = $this->request->getPost('paid_amount');

        if($paid > $fee){
            return redirect()->back()->with('error','Paid amount cannot exceed total fee');
        }

        $due = calculateDue($fee, $paid);

        $model->update($id, [
            'student_id' => $this->request->getPost('student_id'),
            'semester' => $this->request->getPost('semester'),
            'fee_amount' => $fee,
            'paid_amount' => $paid,
            'due_amount' => $due,
            'payment_mode' => $this->request->getPost('payment_mode')
        ]);

        // Generate receipt if fully paid and no previous receipt
        if($due == 0 && !$feeData['receipt_no']){
            $receipt = generateReceiptNo($this->request->getPost('student_id'));
            $model->update($id, ['receipt_no' => $receipt]);
        }

        return redirect()->to('/fees')->with('success','Payment updated successfully');
    }

    // Delete payment
    public function delete($id)
    {
        $model = new StudentFeeModel();
        $fee = $model->find($id);

        if(!$fee) return redirect()->to('/fees')->with('error','Payment not found');

        if($fee['due_amount'] == 0){
            return redirect()->to('/fees')->with('error','Payment completed. Cannot delete.');
        }

        $model->delete($id);
        return redirect()->to('/fees')->with('success','Payment deleted successfully');
    }

    // Show receipt
    public function receipt($id)
{
    $model = new StudentFeeModel();
    $studentModel = new StudentModel();

    $fee = $model->find($id);
    $student = $studentModel->find($fee['student_id']);

    // Generate receipt for partial payment if not already generated
    if (!$fee['receipt_no']) {
        $receipt = generateReceiptNo($fee['student_id']);
        $model->update($id, ['receipt_no' => $receipt]);
        $fee['receipt_no'] = $receipt; // update for view
    }

    return view('fees/receipt', [
        'fee' => $fee,
        'student' => $student
    ]);
}

}
