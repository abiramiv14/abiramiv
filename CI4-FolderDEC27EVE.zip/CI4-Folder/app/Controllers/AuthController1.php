<?php namespace App\Controllers;

use App\Models\LoginModel;

class AuthController1 extends BaseController {

    // Show login form
    public function login() {
        helper(['form']);
        echo view('login');
    }

    // Process login
    public function loginPost() {
        $session = session();
        $model = new LoginModel();

        $email = $this->request->getPost('email');
        $password = md5($this->request->getPost('password'));

        $user = $model->where('email',$email)->where('password',$password)->first();

        if($user){
            $session->set([
                'id' => $user['id'],
                'name' => $user['name'],
                'role' => $user['role'],
                'department' => $user['department'],
                'isLoggedIn' => true
            ]);
            return redirect()->to('/course_allocation');
        } else {
            $session->setFlashdata('error','Invalid Email or Password');
            return redirect()->to('/');
        }
    }

    // Logout
    public function logout() {
        session()->destroy();
        return redirect()->to('/');
    }
}
