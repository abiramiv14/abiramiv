<?php
namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AdminAuth implements FilterInterface
{
    public function before(RequestInterface $request, $args=null)
    {
        if(!session('logged_in') || session('role')!='admin'){
            return redirect()->to('/');
        }
    }
    public function after(RequestInterface $request, ResponseInterface $response, $args=null){}
}
