<?php
namespace App\Models;

use CodeIgniter\Model;

class FeeReportModel extends Model
{
    public function getFeeStatusByDepartment()
    {
        return $this->db->table('departments d')
            ->select("
                d.department_name,
                SUM(CASE WHEN f.status = 'Paid' THEN 1 ELSE 0 END) as paid,
                SUM(CASE WHEN f.status = 'Not Paid' THEN 1 ELSE 0 END) as not_paid
            ")
            ->join('students s', 's.department_id = d.id')
            ->join('fees f', 'f.student_id = s.id')
            ->groupBy('d.department_name')
            ->get()
            ->getResultArray();
    }
}
