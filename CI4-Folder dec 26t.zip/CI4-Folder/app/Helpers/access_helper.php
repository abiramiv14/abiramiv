<?php

function isAdmin() {
    return session()->get('role') === 'admin';
}

function currentAcademicYear() {
    return '2025-2028';
}

function canEditAllocation($allocationYear) {
    return isAdmin() && $allocationYear === currentAcademicYear();
}
