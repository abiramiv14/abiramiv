<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/', 'AuthController::login');
$routes->post('login', 'AuthController::loginPost');
$routes->get('logout', 'AuthController::logout');

/* ADMIN ROUTES */
$routes->group('admin', ['filter' => 'adminAuth'], function($routes){
    $routes->get('fees', 'FeeController::index');
    $routes->get('fees/create', 'FeeController::create');
    $routes->post('fees/store', 'FeeController::store');
});

/* STUDENT ROUTES */
$routes->group('student', ['filter' => 'studentAuth'], function($routes){
    $routes->get('fees', 'FeeController::studentView');
});
