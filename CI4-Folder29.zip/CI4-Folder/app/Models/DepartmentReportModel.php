<?php
namespace App\Models;

use CodeIgniter\Model;

class DepartmentReportModel extends Model
{
    protected $table = 'students';
    protected $allowedFields = ['name','department_id'];

    public function getDepartmentWiseCount()
    {
        return $this->db->table('students s')
            ->select('d.department_name, COUNT(s.id) as total')
            ->join('departments d','d.id = s.department_id')
            ->groupBy('d.department_name')
            ->get()
            ->getResultArray();
    }
}
