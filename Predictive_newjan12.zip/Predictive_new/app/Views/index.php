<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>KASC Risk Predictions | Dashboard</title>
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <!-- Libraries -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <style>
        /* --- Global Styles & Font --- */
        :root {
            --primary-color: #4318FF;      /* Vibrant Blue */
            --secondary-color: #6AD2FF;    /* Light Blue */
            --text-main: #2B3674;          /* Dark Navy */
            --text-light: #A3AED0;         /* Grey */
            --bg-body: #F4F7FE;            /* Light Greyish Blue */
            --card-bg: #FFFFFF;
            --success: #05CD99;
            --warning: #FFCE20;
            --danger: #EE5D50;
        }

        body {
            background-color: var(--bg-body);
            color: var(--text-main);
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* --- Scrollbar --- */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: transparent;
        }
        ::-webkit-scrollbar-thumb {
            background: #CBD5E0;
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #A0AEC0;
        }

        /* --- Components --- */
        .card {
            background-color: var(--card-bg);
            border-radius: 20px;
            box-shadow: 0 18px 40px rgba(112, 144, 176, 0.12);
            padding: 20px;
            transition: transform 0.2s ease;
            height: 100%;
        }
        
        .card:hover {
            transform: translateY(-2px);
        }

        .text-brand {
            color: var(--primary-color);
        }
        .bg-brand {
            background-color: var(--primary-color);
        }

        /* --- Header --- */
        header {
            background-color: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid #E0E5F2;
            position: sticky;
            top: 0;
            z-index: 50;
        }

        /* --- Table Styling --- */
        #riskTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: transparent;
        }

        #riskTable thead th {
            background: #f0f0f0;
            color: black;
            font-weight: 500;
            font-size: 14px;
            padding: 12px 10px;
            border-bottom: 1px solid #E0E5F2;
            text-align: left;
        }

        #riskTable tbody td {
            padding: 16px 10px;
            border-bottom: 1px solid #E0E5F2;
            color: var(--text-main);
            font-size: 14px;
            background: transparent;
            vertical-align: middle;
        }
        
        #riskTable tbody tr:hover td {
            background-color: #F8F9FC;
        }

        /* Risk Badges */
        .badge {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            text-align: center;
            display: inline-block;
            min-width: 60px;
        }
        .badge-low { background: rgba(5, 205, 153, 0.1); color: var(--success); }
        .badge-medium { background: rgba(255, 206, 32, 0.30); color: var(--warning); }
        .badge-high { background: rgba(238, 93, 80, 0.1); color: var(--danger); }

        /* DataTable Overrides */
        .dataTables_filter input {
            border: 1px solid #E0E5F2;
            border-radius: 10px;
            padding: 8px 12px;
            color: var(--text-main);
            outline: none;
            margin-left: 10px;
        }
        .dataTables_length select {
            border: 1px solid #E0E5F2;
            border-radius: 8px;
            padding: 5px 10px;
            color: var(--text-main);
            outline: none;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button {
            padding: 6px 12px !important;
            border-radius: 8px !important;
            border: none !important;
            background: transparent !important;
            color: var(--text-main) !important;
            font-weight: 600;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: var(--primary-color) !important;
            color: white !important;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: #F4F7FE !important;
        }

        /* --- Form Elements --- */
        select, input {
            font-family: 'Poppins', sans-serif;
        }
        
        /* --- Stats Card Special Styling --- */
        .stats-icon-box {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: white;
        }

        /* --- Modal Animation --- */
        .modal-overlay {
            transition: opacity 0.3s ease;
        }
        .modal-content {
            transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        /* Custom scrollbar for student list */
#studentList::-webkit-scrollbar {
    width: 6px;
}

#studentList::-webkit-scrollbar-track {
    background: #F4F7FE;
    border-radius: 10px;
}

#studentList::-webkit-scrollbar-thumb {
    background: #CBD5E0;
    border-radius: 10px;
}

#studentList::-webkit-scrollbar-thumb:hover {
    background: #A3AED0;
}
    </style>
</head>
<body>

    <!-- Header -->
    <header class="h-20">
        <div class="max-w-full mx-auto px-6 h-full flex items-center justify-between">
            <!-- Logo & Nav -->
            <div class="flex items-center space-x-10">
                <div class="flex items-center gap-2">
                    <img src="https://portal.kongunaducollege.ac.in//uploads/banner/logo.png" alt="Logo" class="h-10 w-auto object-contain">
                    <span class="text-2xl font-bold text-[#2B3674] tracking-wide">KASC</span>
                </div>
            </div>

            <!-- Right Actions -->
            <div class="flex items-center space-x-6">
                <!-- Search -->
                <div class="hidden sm:flex items-center bg-white border border-[#E0E5F2] rounded-full px-4 h-10 shadow-sm">
                    <span class="material-icons text-[#A3AED0] text-[18px]">search</span>
                    <input type="text" placeholder="Search..." class="ml-2 w-40 bg-transparent outline-none text-sm text-[#2B3674] placeholder-[#A3AED0]">
                </div>

                <!-- Icons -->
                <button class="relative p-2 rounded-full hover:bg-[#F4F7FE] transition">
                    <span class="material-icons text-[#A3AED0]">dark_mode</span>
                </button>
                <button class="relative p-2 rounded-full hover:bg-[#F4F7FE] transition">
                    <span class="material-icons text-[#A3AED0]">notifications</span>
                    <span class="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
                </button>

                <!-- Profile Dropdown -->
                <!-- <div class="relative group">
                    <button id="accountBtn" class="flex items-center gap-3 focus:outline-none">
                        <div class="text-right hidden sm:block">
                            <p class="text-sm font-bold text-[#2B3674] leading-none">Principal</p>
                            <p class="text-xs text-[#A3AED0] mt-1">Admin</p>
                        </div>
                        <img src="https://ui-avatars.com/api/?name=Matt+Dickson&background=4318FF&color=fff" class="w-10 h-10 rounded-full border-2 border-white shadow-sm">
                    </button> -->
                    <div class="relative">
          <button
            id="accountBtn"
            class="relative flex items-center justify-center
                   w-7 h-7 sm:w-9 sm:h-9
                   rounded-full overflow-hidden
                   border-2 border-[#1e35a3]
                   bg-white
                   transition-all duration-200
                   hover:bg-[#f5f7ff]
                   hover:scale-105
                   active:scale-95
                   focus:outline-none
                   focus:ring-2 focus:ring-[#1e35a3]/40">

            <span
              class="material-symbols-outlined absolute inset-0
                     flex items-center justify-center
                     text-[1.6rem] sm:text-[2.1rem]
                     leading-none text-[#1e35a3]"
              style="font-variation-settings: 'wght' 300;">
              person
            </span>
          </button>
                    <!-- Dropdown -->
                    <div id="accountDropdown" class="hidden absolute right-0 mt-3 w-48 bg-white rounded-20 shadow-xl border border-[#E0E5F2] py-2 z-50">
                        <a href="#" class="block px-4 py-2 text-sm text-[#2B3674] hover:bg-[#F4F7FE]">Profile</a>
                        <a href="#" class="block px-4 py-2 text-sm text-[#2B3674] hover:bg-[#F4F7FE]">Settings</a>
                        <div class="h-px bg-[#E0E5F2] my-1"></div>
                        <a href="#" class="block px-4 py-2 text-sm text-[#EE5D50] hover:bg-[#FFF5F5]">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main class="px-6 py-6 max-w-full">
        
<!-- COMBINED HEADER & CARDS CONTAINER -->
<div class="rounded-[20px] p-5 mb-6 shadow-sm bg-[#b0e2ff]">

    <div class="flex flex-col xl:flex-row items-center justify-between gap-4">

        <!-- LEFT: Greeting -->
        <div class="flex-shrink-0 text-center xl:text-left">
            <h2 class="text-2xl font-bold text-[#2B3674]">Hello, Principal 👋</h2>
            <p class="text-sm text-[#2B3674] font-medium mt-2 max-w-[260px]">
                Here's an overview of today's student risk analytics
            </p>
        </div>

        <!-- CENTER: Compact Stats Cards -->
        <div class="flex-1 grid grid-cols-2 lg:grid-cols-4 gap-3">

            <!-- Card 1 -->
            <div class="card relative flex flex-col items-start justify-center px-3 py-4 min-h-[100px] max-w-[250px] overflow-hidden">

                <div class="stats-icon-box absolute top-3 right-3 bg-orange-100"
                     style="width:38px;height:38px;font-size:20px;color:#F97316;">
                    <span class="material-icons">people</span>
                </div>

                <p class="text-[11px] text-[#F97316] font-semibold uppercase mt-2">Total Students</p>
                <h4 class="text-xl font-bold text-[#2B3674]" id="totalStudentsVal">
                    <?php 
                    $totalStudents = array_sum(array_column($students_by_department, 'total'));
                    echo esc($totalStudents); 
                    ?>
                </h4>

                <!-- Light Blue Half Circle -->
                <div class="absolute -bottom-6 -right-6 w-16 h-16 bg-[#D6ECFF] rounded-full"></div>
            </div>

            <!-- Card 2 -->
            <div class="card relative flex flex-col items-start justify-center px-3 py-4 min-h-[100px] max-w-[250px] overflow-hidden">

                <div class="stats-icon-box absolute top-3 right-3 bg-orange-100"
                     style="width:38px;height:38px;font-size:20px;color:#F97316;">
                    <span class="material-icons">warning</span>
                </div>

                <p class="text-[11px] text-[#F97316] font-semibold uppercase mt-2">High Risk</p>
                <h4 class="text-xl font-bold text-[#2B3674]" id="highRiskVal">
                    <?php 
                    $highRisk = 0;
                    foreach ($lowHigh as $i) {
                        if ($i['risk_level'] === 'HIGH') {
                            $highRisk = $i['COUNT(*)'];
                            break;
                        }
                    }
                    echo esc($highRisk); 
                    ?>
                </h4>

                <div class="absolute -bottom-6 -right-6 w-16 h-16 bg-[#D6ECFF] rounded-full"></div>
            </div>

            <!-- Card 3 -->
            <div class="card relative flex flex-col items-start justify-center px-3 py-4 min-h-[100px] max-w-[250px] overflow-hidden">

                <div class="stats-icon-box absolute top-3 right-3 bg-orange-100"
                     style="width:38px;height:38px;font-size:20px;color:#F97316;">
                    <span class="material-icons">error_outline</span>
                </div>

                <p class="text-[11px] text-[#F97316] font-semibold uppercase mt-2">Medium Risk</p>
                <h4 class="text-xl font-bold text-[#2B3674]" id="medRiskVal">
                    <?php 
                    $mediumRisk = 0;
                    foreach ($lowHigh as $i) {
                        if ($i['risk_level'] === 'MEDIUM') {
                            $mediumRisk = $i['COUNT(*)'];
                            break;
                        }
                    }
                    echo esc($mediumRisk); 
                    ?>
                </h4>

                <div class="absolute -bottom-6 -right-6 w-16 h-16 bg-[#D6ECFF] rounded-full"></div>
            </div>

            <!-- Card 4 -->
            <div class="card relative flex flex-col items-start justify-center px-3 py-4 min-h-[100px] max-w-[250px] overflow-hidden">

                <div class="stats-icon-box absolute top-3 right-3 bg-orange-100"
                     style="width:38px;height:38px;font-size:20px;color:#F97316;">
                    <span class="material-icons">domain</span>
                </div>

                <p class="text-[11px] text-[#F97316] font-semibold uppercase mt-2">Top Dept</p>
                <h4 class="text-lg font-bold text-[#2B3674]" id="topDeptVal">
                    <?php 
                    $topDept = $topCount = 0;
                    foreach ($dropout_by_department as $d) {
                        if ($d['total'] > $topCount) {
                            $topCount = $d['total'];
                            $topDept  = $d['department_name'];
                        }
                    }
                    echo esc($topDept); 
                    ?>
                </h4>

                <div class="absolute -bottom-6 -right-6 w-16 h-16 bg-[#D6ECFF] rounded-full"></div>
            </div>

        </div>

        <!-- RIGHT: Add Student Button -->
        <div class="flex-shrink-0">
            <button id="openModalBtn"
                class="bg-[#f97316] hover:bg-[#D65A0F] text-white px-5 py-3 
                       rounded-xl font-semibold shadow-lg shadow-[#D65A0F]/30 
                       transition flex items-center gap-2 whitespace-nowrap">
                <span class="material-icons text-[20px]">add</span>
                Add Student
            </button>
        </div>

    </div>
</div>



        <!-- Charts Row 1 -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            
            <!-- Pie Chart -->
            <div class="card p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-bold text-[#000000]">Risk Distribution</h3>
                </div>
                <div id="myPieChart" class="w-full h-64"></div>
            </div>

            <!-- Bar Chart 1 -->
            <div class="card p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-bold text-[#000000]">High Risk by Dept</h3>
                </div>
                <div class="w-full h-64 relative">
                    <canvas id="deptBarChart"></canvas>
                </div>
            </div>

            <!-- Bar Chart 2 -->
            <div class="card p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-bold text-[#000000]">Incident Analysis</h3>
                </div>
                <div class="w-full h-64 relative">
                    <canvas id="incidentChart"></canvas>
                </div>
            </div>
        </div>

            <!-- Fee Payment & Student Details Container -->
<!-- Fee Payment & Student Details Container -->
<div class="card p-6 mb-6">

    <!-- Header -->
    <h3 class="text-lg font-bold text-[#000000] mb-6">
        Department Fee Payment Status
    </h3>

    <!-- Chart + List Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- LEFT: Chart (2 columns) -->
        <div class="lg:col-span-2 border-r border-[#cccccc] pr-4">
            <!-- Give this a fixed height -->
            <div id="deptChart" class="w-full h-[420px]"></div>
        </div>

        <!-- RIGHT: Student List (1 column) -->
        <div class="flex flex-col h-[420px]"> <!-- Same fixed height -->

            <div class="flex justify-between items-center mb-4">
                <div>
                    <h3 class="text-lg font-bold text-[#000000]" id="studentCardTitle">
                        Department List
                    </h3>
                    <p class="text-xs text-[#A3AED0] mt-1" id="studentCardSub">
                        Fee Status
                    </p>
                </div>

                <div class="w-8 h-8 rounded-full bg-[#F4F7FE] flex items-center justify-center text-[#000000]">
                    <span class="material-icons text-[18px]">receipt_long</span>
                </div>
            </div>

            <!-- Student list with fixed height and scroll -->
            <div id="studentList" class="flex-1 overflow-y-auto pr-2 space-y-3 bg-[#F8F9FC] rounded-xl p-3 border border-[#E0E5F2]">
                <!-- Dynamic Content -->
                <div class="text-center text-[#A3AED0] py-10">Select a department to view pending fees</div>
            </div>
        </div>

    </div>
</div>

        <!-- Data Table -->
        <div class="card p-6">
            <div class="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                <h3 class="text-lg font-bold text-[#000000]">Overall Risk Analysis</h3>
                <div class="flex items-center gap-3">
                    <label class="text-sm text-[#A3AED0]">Filter Dept:</label>
                    <select id="departments" class="bg-[#F4F7FE] border-none rounded-lg px-3 py-2 text-sm text-[#2B3674] font-medium outline-none cursor-pointer">
                        <option value="">All Departments</option>
                        <?php foreach($dropout_by_department as $d): ?>
                            <option value="<?= esc($d['department_name']) ?>" <?= $d['department_name']==$defaultDept?'selected':'' ?>>
                                <?= esc($d['department_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="overflow-x-hidden">
                <table id="riskTable" class="w-full">
                    <thead>
                        <tr>
                            <th>Roll No</th>
                            <th>Student Name</th>
                            <th>Department</th>
                            <th>Attendance</th>
                            <th>Internal Marks</th>
                            <th>Fee Due</th>
                            <th>Incidents</th>
                            <th>Risk Score</th>
                            <th>Risk Level</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Populated via JS with PHP data -->
                        <?php foreach($predictions as $r): ?>
                        <tr>
                            <td><?= esc($r['roll_no']) ?></td>
                            <td><?= esc($r['student_name']) ?></td>
                            <td><?= esc($r['department_name']) ?></td>
                            <td>
                                <div class="flex items-center gap-2">
                                    
                                    <span class="text-sm"><?= intval(esc($r['attendance_percentage'])) ?>%</span>
                                </div>
                            </td>
                            <td><?= intval(esc($r['avg_internal_marks'])) ?></td>
                            <td>
                                <?php if(intval(esc($r['fee_due_amount'])) > 0): ?>
                                    <span class="text-[#EE5D50] font-bold">₹<?= number_format(intval(esc($r['fee_due_amount']))) ?></span>
                                <?php else: ?>
                                    <span class="text-[#05CD99] font-bold">Paid</span>
                                <?php endif; ?>
                            </td>
                            <td><?= esc($r['incident_count']) ?></td>
                            <td><?= esc($r['risk_score']) ?></td>
                            <td>
                                <?php 
                                $riskLevel = strtoupper(esc($r['risk_level']));
                                $cls = $riskLevel === 'LOW' ? 'badge-low' : ($riskLevel === 'MEDIUM' ? 'badge-medium' : 'badge-high');
                                ?>
                                <span class="badge <?= $cls ?>"><?= $riskLevel ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <!-- Modal -->
    <div id="addStudentModal" class="fixed inset-0 bg-black/60 hidden flex items-center justify-center z-[100] backdrop-blur-sm opacity-0 transition-opacity duration-300">
        <div class="bg-white rounded-[20px] shadow-2xl w-full max-w-lg p-8 relative transform scale-95 transition-transform duration-300">
            <button id="closeAddStudentModal" class="absolute top-5 right-5 text-[#A3AED0] hover:text-[#2B3674]">
                <span class="material-icons text-2xl">close</span>
            </button>
            <h3 class="text-2xl font-bold text-[#2B3674] mb-6">Add New Student</h3>
            
            <form id="formAddStudent" action="Addstudent" method="post" class="space-y-4">
                <div>
                    <label class="block text-sm font-semibold text-[#2B3674] mb-1">Student Name <span class="text-red-500">*</span></label>
                    <input type="text" id="inputStudentName" name="student_name" class="w-full bg-[#F4F7FE] border border-transparent focus:bg-white focus:border-[#4318FF] rounded-xl px-4 py-3 outline-none transition" placeholder="John Doe">
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-[#2B3674] mb-1">Department <span class="text-red-500">*</span></label>
                    <select id="department" name="department_name" class="w-full bg-[#F4F7FE] border border-transparent focus:bg-white focus:border-[#4318FF] rounded-xl px-4 py-3 outline-none transition">
                        <option value="">--- Select ---</option>
                        <?php foreach($all_departments as $d): ?>
                            <option value="<?= esc($d['department_name']) ?>" data-fee="<?= esc($d['department_fees_amount']) ?>">
                                <?= esc($d['department_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div id="deptFeeDisplay" class="text-xs text-[#4318FF] mt-2 font-medium"></div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-[#2B3674] mb-1">Incidents <span class="text-red-500">*</span></label>
                        <input type="number" id="inputIncidents" name="incident_count" class="w-full bg-[#F4F7FE] border border-transparent focus:bg-white focus:border-[#4318FF] rounded-xl px-4 py-3 outline-none transition" placeholder="0">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-[#2B3674] mb-1">Internal Marks <span class="text-red-500">*</span></label>
                        <input type="number" id="inputInternalMarks" name="avg_internal_marks" class="w-full bg-[#F4F7FE] border border-transparent focus:bg-white focus:border-[#4318FF] rounded-xl px-4 py-3 outline-none transition" placeholder="0-50">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-[#2B3674] mb-1">Attendance % <span class="text-red-500">*</span></label>
                        <input type="number" id="inputAttendance" name="attendance_percentage" class="w-full bg-[#F4F7FE] border border-transparent focus:bg-white focus:border-[#4318FF] rounded-xl px-4 py-3 outline-none transition" placeholder="0-100">
                    </div>
                    <div class="col-span-2" id="paidSection" style="display: none;">
                        <label class="block text-sm font-semibold text-[#2B3674] mb-1">Amount Paid <span class="text-red-500">*</span></label>
                        <input type="number" id="paidAmount" name="paid_amount" class="w-full bg-[#F4F7FE] border border-transparent focus:bg-white focus:border-[#4318FF] rounded-xl px-4 py-3 outline-none transition" placeholder="₹">
                    </div>
                </div>

                <div class="col-span-2" id="remainingSection" style="display: none;">
                    <label class="block text-sm font-semibold text-[#2B3674] mb-1">Amount Remaining <span class="text-red-500">*</span></label>
                    <input type="number" id="remainingAmount" name="remaining_amount" class="w-full bg-[#F4F7FE] border border-transparent focus:bg-white focus:border-[#4318FF] rounded-xl px-4 py-3 outline-none transition" readonly>
                </div>
                
                <div class="pt-4 flex justify-end gap-3">
                    <button type="button" id="cancelAddStudentModal" class="px-6 py-2 rounded-xl border border-[#E0E5F2] text-[#2B3674] font-semibold hover:bg-[#F4F7FE] transition">Cancel</button>
                    <button type="submit" id="formSubmitBtn" class="px-6 py-2 rounded-xl bg-[#4318FF] text-white font-semibold shadow-lg shadow-[#4318FF]/40 hover:bg-[#3311DB] transition disabled:opacity-50 disabled:cursor-not-allowed">Submit</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="fixed top-6 right-6 z-[110] hidden px-6 py-4 rounded-2xl shadow-2xl text-white font-medium transform translate-x-10 transition-all duration-300 flex items-center gap-3">
        <span id="toastIcon" class="material-icons">check_circle</span>
        <span id="toastMsg"></span>
    </div>

    <!-- Scripts -->
    <script>
        // 1. Dropdown Toggle
        const accountBtn = document.getElementById('accountBtn');
        const accountDropdown = document.getElementById('accountDropdown');
        accountBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            accountDropdown.classList.toggle('hidden');
        });
        document.addEventListener('click', (e) => {
            if (!accountBtn.contains(e.target) && !accountDropdown.contains(e.target)) {
                accountDropdown.classList.add('hidden');
            }
        });

        // 2. Toast Notification
        function showToast(msg, type = 'success') {
            const toast = document.getElementById('toast');
            const text = document.getElementById('toastMsg');
            const icon = document.getElementById('toastIcon');
            
            text.textContent = msg;
            toast.className = `fixed top-6 right-6 z-[110] px-6 py-4 rounded-2xl shadow-2xl text-white font-medium transition-all duration-300 flex items-center gap-3 transform translate-x-0`;
            
            if (type === 'success') {
                toast.classList.add('bg-[#05CD99]');
                icon.textContent = 'check_circle';
            } else if (type === 'error') {
                toast.classList.add('bg-[#EE5D50]');
                icon.textContent = 'error';
            } else {
                toast.classList.add('bg-[#FFCE20]');
                icon.textContent = 'warning';
            }

            setTimeout(() => {
                toast.classList.add('translate-x-10', 'opacity-0');
                setTimeout(() => toast.classList.add('hidden'), 300);
            }, 3000);
        }

        // 3. Charts Initialization with PHP Data
        
        // Chart A: Incident Analysis (Bar - Chart.js)
        const incidentAnalysisData = <?= json_encode($incident_analysis); ?>;
        const ctxIncident = document.getElementById('incidentChart').getContext('2d');

        new Chart(ctxIncident, {
            type: 'bar',
            data: {
                labels: incidentAnalysisData.map(d => d.department_name),
                datasets: [{
                    label: 'Incidents',
                    data: incidentAnalysisData.map(d => d.total_incidents),
                    backgroundColor: '#f97316',
                    borderRadius: 6,
                    barThickness: 30
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,

                plugins: {
                    legend: { display: true }
                },

                scales: {
                    x: {
                        grid: { display: false },
                        ticks: {
                            font: { family: 'Poppins' }
                        },
                        title: {
                            display: true,
                            text: 'Departments',
                            font: {
                                family: 'Poppins',
                                size: 14,
                                weight: '400'
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: '#F4F7FE' },
                        ticks: {
                            font: { family: 'Poppins' }
                        },
                        title: {
                            display: true,
                            text: 'Number of Incidents',
                            font: {
                                family: 'Poppins',
                                size: 14,
                                weight: '400'
                            }
                        }
                    }
                }
            }
        });

        // Chart B: High Risk by Dept (Bar - Chart.js)
        const deptBarData = <?= json_encode($dropout_by_department); ?>;
        const ctxDept = document.getElementById('deptBarChart').getContext('2d');

        new Chart(ctxDept, {
            type: 'bar',
            data: {
                labels: deptBarData.map(d => d.department_name),
                datasets: [{
                    label: 'Students',
                    data: deptBarData.map(d => d.total),
                    backgroundColor: '#4318FF',
                    borderRadius: 6,
                    barThickness: 30
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,

                plugins: {
                    legend: { display: true }
                },

                scales: {
                    x: {
                        grid: { display: false },
                        ticks: {
                            font: { family: 'Poppins' }
                        },
                        title: {
                            display: true,
                            text: 'Departments',
                            font: {
                                family: 'Poppins',
                                size: 14,
                                weight: '400'
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: '#F4F7FE' },
                        ticks: {
                            font: { family: 'Poppins' }
                        },
                        title: {
                            display: true,
                            text: 'Number of Students',
                            font: {
                                family: 'Poppins',
                                size: 14,
                                weight: '400'
                            }
                        }
                    }
                }
            }
        });

        // Chart C: Risk Distribution (Donut - ApexCharts)
       // Chart C: Risk Distribution (Donut - ApexCharts)
const lowHighData = <?= json_encode($lowHigh); ?>;
new ApexCharts(document.querySelector("#myPieChart"), {
    chart: { 
        type: 'donut', 
        height: 260, 
        fontFamily: 'Poppins, sans-serif' 
    },
    series: lowHighData.map(i => +i["COUNT(*)"]),
    labels: lowHighData.map(i => i.risk_level + " Level"),
    colors: ['#f97316', '#1e35a3', '#dc2626'], // Colors from old file
    plotOptions: { 
        pie: { 
            donut: { 
                size: '75%' 
            } 
        } 
    },
    dataLabels: { enabled: false },
    legend: { 
        position: 'bottom', 
        fontFamily: 'Poppins',
        horizontalAlign: 'center',
        fontSize: '12px',
        offsetY: -5
    },
    stroke: { show: false }
}).render();

        // Chart D: Fee Payment (Stacked Horizontal Bar - ApexCharts)
        const stackedBarData = <?= json_encode($stacked_bar); ?>;
        const feeOptions = {
            chart: {
                type: 'bar',
                height: 420,
                stacked: true,
                toolbar: { show: false },
                fontFamily: 'Poppins, sans-serif',
                events: {
                    dataPointSelection: function(event, chartContext, config) {
                        const dept = stackedBarData[config.dataPointIndex];
                        showStudentCard(dept);
                    }
                }
            },

            plotOptions: {
                bar: {
                    horizontal: true,
                    borderRadius: 4,
                    barHeight: 30
                    
                }
            },

            fill: {
                type: 'solid',
                opacity: 1
            },

            states: {
                normal: { filter: { type: 'none' } },
                hover:  { filter: { type: 'none' } },
                active: { filter: { type: 'none' } }
            },

            dataLabels: { enabled: false },

            series: [
                { name: 'Paid', data: stackedBarData.map(d => parseInt(d.paid_count)) },
                { name: 'Unpaid', data: stackedBarData.map(d => parseInt(d.unpaid_count)) }
            ],

            colors: ['#05CD99', '#E8610F'],

            xaxis: {
                categories: stackedBarData.map(d => {
                    const words = d.department_name.split(' ');
                    if (words.length > 1) {
                        return words.map(w => w[0].toUpperCase()).join('');
                    }
                    return d.department_name;
                })
            },

            yaxis: {
                labels: { style: { colors: '#2B3674', fontWeight: 600 } }
            },

            grid: { show: false },

            legend: {
                position: 'top',
                horizontalAlign: 'right'
            },

            tooltip: { theme: 'light' }
        };

        const deptChart = new ApexCharts(document.querySelector("#deptChart"), feeOptions);
        deptChart.render();

        // Chart E: Data Table (DataTables)
        const table = $('#riskTable').DataTable({
            pageLength: 5,
            lengthMenu: [5, 10, 25],
            language: { search: "", searchPlaceholder: "Search..." },
            dom: '<"flex justify-between items-center mb-4"fl>rt<"flex justify-between items-center mt-4"ip>',
            drawCallback: function() { $('.dataTables_filter input').addClass('focus:ring-0'); }
        });

        // Filter Table
        $('#departments').on('change', function() {
            const dept = $(this).val();
            $.post('getStudentsByDept', { department: dept }, res => {
                table.clear();
                res.forEach(r => {
                    const riskLevel = r.risk_level.toUpperCase();
                    const cls = riskLevel === 'LOW' ? 'badge-low' : (riskLevel === 'MEDIUM' ? 'badge-medium' : 'badge-high');
                    
                    table.row.add([
                        r.roll_no,
                        r.student_name,
                        r.department_name,
                        `<div class="flex items-center gap-2">
                            <div class="h-2 bg-gray-200 rounded-full overflow-hidden w-16">
                                <div class="h-full bg-[#4318FF]" style="width: ${r.attendance_percentage}%"></div>
                            </div>
                            <span class="text-sm">${r.attendance_percentage}%</span>
                        </div>`,
                        r.avg_internal_marks,
                        r.fee_due_amount > 0 ? `<span class="text-[#EE5D50] font-bold">₹${Number(r.fee_due_amount).toLocaleString()}</span>` : `<span class="text-[#05CD99] font-bold">Paid</span>`,
                        r.incident_count,
                        r.risk_score,
                        `<span class="badge ${cls}">${riskLevel}</span>`
                    ]);
                });
                table.draw();
            }, 'json');
        });

        /* --- INTERACTION LOGIC --- */

        // Show Student Card (Right side of Fee Chart)
        function showStudentCard(dept) {
    const container = document.getElementById('studentList');
    const title = document.getElementById('studentCardTitle');
    const sub = document.getElementById('studentCardSub');
    
    container.innerHTML = '';
    title.innerText = dept.department_name;
    sub.innerText = `Fee: ₹${parseFloat(dept.department_fees_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

    if (!dept.unpaid_students || dept.unpaid_students.length === 0) {
        container.innerHTML = `
            <div class="text-center text-[#A3AED0] py-10">
                <span class="material-icons text-4xl mb-2">check_circle</span>
                <p class="font-medium">No pending fees!</p>
                <p class="text-xs mt-1">All fees are cleared</p>
            </div>`;
        return;
    }

    // Show count badge
    const countBadge = document.createElement('div');
    countBadge.className = 'mb-3 px-3 py-1 bg-[#4318FF]/10 text-[#4318FF] text-xs font-bold rounded-full inline-block';
    countBadge.textContent = `${dept.unpaid_students.length} students pending`;
    container.appendChild(countBadge);

    dept.unpaid_students.forEach(s => {
        const pending = parseFloat(s.amount);
        const paid = parseFloat(dept.department_fees_amount) - pending;
        const el = document.createElement('div');
        el.className = 'flex items-center justify-between p-3 rounded-xl bg-white border border-[#E0E5F2] hover:shadow-sm transition-shadow';
        el.innerHTML = `
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-full bg-gradient-to-br from-[#4318FF] to-[#6AD2FF] text-white flex items-center justify-center text-sm font-bold shadow-sm">
                    ${s.name.charAt(0)}
                </div>
                <div class="min-w-0">
                    <p class="text-sm font-bold text-[#2B3674] truncate">${s.name}</p>
                    <div class="flex gap-2 mt-1">
                        <span class="text-xs text-[#05CD99] bg-[#05CD99]/10 px-2 py-0.5 rounded">
                            Paid: ₹${paid.toLocaleString()}
                        </span>
                        <span class="text-xs text-[#EE5D50] bg-[#EE5D50]/10 px-2 py-0.5 rounded">
                            Due: ₹${pending.toLocaleString()}
                        </span>
                    </div>
                </div>
            </div>
            <div class="text-[#EE5D50] text-xs font-bold bg-white px-3 py-1.5 rounded-lg border border-[#EE5D50]/20 shadow-sm whitespace-nowrap">
                Pending
            </div>
        `;
        container.appendChild(el);
    });

    // Add scroll indicator at the bottom if many items
    if (dept.unpaid_students.length > 5) {
        const scrollIndicator = document.createElement('div');
        scrollIndicator.className = 'text-center text-xs text-[#A3AED0] mt-3 py-2 border-t border-[#E0E5F2]';
        scrollIndicator.innerHTML = '<span class="material-icons text-sm animate-bounce">expand_more</span> Scroll for more';
        container.appendChild(scrollIndicator);
    }
}

        // Initialize with default max unpaid
        const maxUnpaid = stackedBarData.reduce((prev, current) => {
            const prevCount = parseInt(prev.unpaid_count || 0);
            const currCount = parseInt(current.unpaid_count || 0);
            return (currCount > prevCount) ? current : prev;
        });
        showStudentCard(maxUnpaid);

        /* --- MODAL LOGIC --- */
        const modal = document.getElementById('addStudentModal');
        const modalContent = modal.querySelector('div');
        const openModalBtn = document.getElementById('openModalBtn');
        const closeModalBtn = document.getElementById('closeAddStudentModal');
        const cancelModalBtn = document.getElementById('cancelAddStudentModal');

        function openModal() {
            modal.classList.remove('hidden');
            setTimeout(() => {
                modal.classList.remove('opacity-0');
                modalContent.classList.remove('scale-95');
                modalContent.classList.add('scale-100');
            }, 10);
        }

        function closeModal() {
            modal.classList.add('opacity-0');
            modalContent.classList.remove('scale-100');
            modalContent.classList.add('scale-95');
            setTimeout(() => {
                modal.classList.add('hidden');
            }, 300);
        }

        openModalBtn.addEventListener('click', openModal);
        closeModalBtn.addEventListener('click', closeModal);
        cancelModalBtn.addEventListener('click', closeModal);
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });

        // Form Validation & Submission
        const form = document.getElementById('formAddStudent');
        const submitBtn = document.getElementById('formSubmitBtn');
        const inputs = form.querySelectorAll('input, select');
        
        function validateForm() {
            let valid = true;
            inputs.forEach(i => {
                if(i.hasAttribute('required') && !i.value) valid = false;
            });
            submitBtn.disabled = !valid;
        }
        inputs.forEach(i => i.addEventListener('input', validateForm));

        // Form submission with AJAX
        $(form).on('submit', function(e){
            e.preventDefault();

            $.ajax({
                url: form.action,
                type: 'POST',
                data: $(form).serialize(),
                dataType: 'json',
                success: function(res){
                    if(res.status === 'success'){
                        closeModal();
                        showToast(res.message || 'Student added successfully','success');
                        form.reset();
                        submitBtn.innerHTML = 'Submit';
                        $('#formSubmitBtn').prop('disabled', true);
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        showToast(res.message || 'Something went wrong','error');
                    }
                },
                error: function(){
                    showToast('Server error. Try again','error');
                }
            });
        });

        // Department Fee Logic
        const deptSelect = document.getElementById('department');
        const feeDisplay = document.getElementById('deptFeeDisplay');
        const paidSection = document.getElementById('paidSection');
        const remainingSection = document.getElementById('remainingSection');
        const paidInput = document.getElementById('paidAmount');
        const remainingInput = document.getElementById('remainingAmount');
        let departmentFee = 0;
        
        deptSelect.addEventListener('change', function() {
            const opt = this.options[this.selectedIndex];
            const fee = opt.getAttribute('data-fee');
            departmentFee = fee ? parseFloat(fee) : 0;
            
            if(departmentFee > 0){
                feeDisplay.textContent = `Department Fee: ₹${departmentFee.toLocaleString('en-IN', {minimumFractionDigits:2,maximumFractionDigits:2})}`;
                paidSection.style.display = 'block';
                remainingSection.style.display = 'block';
            } else {
                feeDisplay.textContent = '';
                paidSection.style.display = 'none';
                remainingSection.style.display = 'none';
            }
            
            paidInput.value = '';
            remainingInput.value = '';
            validateForm();
        });

        paidInput.addEventListener('input', function() {
            let p = this.value.replace(/[^0-9]/g,'');
            if(p === '') p = '0';
            p = parseInt(p);
            if(p > departmentFee) p = departmentFee;
            this.value = p;
            remainingInput.value = (departmentFee - p).toFixed(2);
            validateForm();
        });

        paidInput.addEventListener('keypress', e => {
            if(['e','E','+','-'].includes(e.key)) e.preventDefault();
        });

        // Input validation functions from old file
        function vName(n) {
            return /^[A-Za-z\s.]*$/.test(n) && 
                   ((n.match(/\./g)||[]).length <= 1) && 
                   ((n.match(/ /g)||[]).length <= 2) && 
                   n.trim() !== '';
        }

        function vForm() {
            let s = $('#inputStudentName').val().trim(),
                d = $('#department').val(),
                i = parseInt($('#inputIncidents').val()) || 0,
                m = parseInt($('#inputInternalMarks').val()) || 0,
                a = parseInt($('#inputAttendance').val()) || 0,
                p = parseFloat($('#paidAmount').val()) || 0,
                r = parseFloat($('#remainingAmount').val()) || 0,
                f = true;
            
            if(!vName(s) || d === '' || i > 10 || i < 0 || m > 50 || m < 0 || a > 100 || a < 0) f = false;
            if($('#paidSection').is(':visible') && (p < 0 || r < 0)) f = false;
            
            $('#formSubmitBtn').prop('disabled', !f);
        }

        $('#formAddStudent input, #formAddStudent select').on('input change', vForm);
        
        $('#inputStudentName').on('keypress', function(e) {
            let c = e.key,
                t = $(this).val();
            if(!/^[A-Za-z .]$/.test(c) || 
               (c === '.' && (t.match(/\./g)||[]).length >= 1) || 
               (c === ' ' && (t.match(/ /g)||[]).length >= 2)) e.preventDefault();
        });

        $('#inputAttendance').on('input', function() {
            if(this.value > 100) this.value = 100;
        });

        $('#inputIncidents').on('input', function() {
            if(this.value > 10) this.value = 10;
        });

        $('#inputInternalMarks').on('input', function() {
            if(this.value > 50) this.value = 50;
        });

    </script>
</body>
</html>