<?php namespace App\Controllers;

use App\Models\CourseAllocationModel;
use App\Models\FacultyModel;
use App\Models\CourseModel;

class CourseAllocationController extends BaseController
{
    public function index()
    {
        $allocationModel = new CourseAllocationModel();
        $facultyModel = new FacultyModel();
        $courseModel = new CourseModel();

        $allocations = $allocationModel->findAll();
        $data['allocations'] = [];

        foreach ($allocations as $alloc) {
            $faculty = $facultyModel->find($alloc['faculty_id']);
            $course = $courseModel->find($alloc['course_id']);

            $data['allocations'][] = [
                'id' => $alloc['id'],
                'course_name' => $course ? $course['course_name'] : '-',
                'course_code' => $course ? $course['course_code'] : '-',
                'faculty_name' => $faculty ? $faculty['user_id'] : '-', // can replace with name if joined with users table
                'academic_year' => $alloc['academic_year'],
                'semester' => $alloc['semester']
            ];
        }

        return view('allocations/list', $data);
    }

    public function create()
    {
        if (!isAdmin()) return redirect()->to('/login');

        $facultyModel = new FacultyModel();
        $courseModel = new CourseModel();

        $data = [
            'faculties' => $facultyModel->findAll(),
            'courses' => $courseModel->findAll(),
            'currentYear' => currentAcademicYear()
        ];

        return view('allocations/create', $data);
    }

    public function store()
    {
        if (!isAdmin()) return redirect()->to('/login');

        $model = new CourseAllocationModel();
        $model->insert([
            'course_id' => $this->request->getPost('course_id'),
            'faculty_id' => $this->request->getPost('faculty_id'),
            'academic_year' => $this->request->getPost('academic_year'),
            'semester' => $this->request->getPost('semester'),
            'created_by' => session('user_id')
        ]);

        return redirect()->to('/allocations')->with('success','Course allocated successfully.');
    }

    public function edit($id)
    {
        $model = new CourseAllocationModel();
        $allocation = $model->find($id);

        if (!canEditAllocation($allocation['academic_year'])) {
            return redirect()->to('/allocations')->with('error','Cannot edit past or unauthorized allocation.');
        }

        $facultyModel = new FacultyModel();
        $courseModel = new CourseModel();

        $data = [
            'allocation' => $allocation,
            'faculties' => $facultyModel->findAll(),
            'courses' => $courseModel->findAll()
        ];

        return view('allocations/edit', $data);
    }

    public function update($id)
    {
        $model = new CourseAllocationModel();
        $allocation = $model->find($id);

        if (!canEditAllocation($allocation['academic_year'])) {
            return redirect()->to('/allocations')->with('error','Cannot update past or unauthorized allocation.');
        }

        $model->update($id, [
            'course_id' => $this->request->getPost('course_id'),
            'faculty_id' => $this->request->getPost('faculty_id'),
            'semester' => $this->request->getPost('semester'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to('/allocations')->with('success','Allocation updated successfully.');
    }

    public function delete($id)
    {
        $model = new CourseAllocationModel();
        $allocation = $model->find($id);

        if (!isAdmin() || $allocation['academic_year'] !== currentAcademicYear()) {
            return redirect()->to('/allocations')->with('error','Cannot delete past or unauthorized allocation.');
        }

        $model->delete($id);
        return redirect()->to('/allocations')->with('success','Allocation deleted successfully.');
    }
}
