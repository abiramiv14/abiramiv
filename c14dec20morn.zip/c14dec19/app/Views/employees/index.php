<?php helper('form'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee List</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            padding: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th {
            background: #007bff;
            color: #fff;
        }
        a {
            text-decoration: none;
        }
        a:hover i {
            opacity: 0.7;
        }
        .flash-success {
            color: green;
            text-align: center;
            margin-bottom: 10px;
        }
        .flash-error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
        .add-btn {
            display: inline-block;
            margin-bottom: 10px;
            padding: 8px 15px;
            background: #28a745;
            color: #fff;
            border-radius: 4px;
        }
        .add-btn:hover {
            background: #218838;
        }
    </style>
</head>
<body>
    <h1>Employee List</h1>
<?php
$session = session();
?>

<p>User ID: <?= esc($session->get('role')) ?></p>

    <!-- Flash Messages -->
    <?php if(session()->getFlashdata('success')): ?>
        <div class="flash-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>
    <?php if(session()->getFlashdata('error')): ?>
        <div class="flash-error"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <!-- Add Employee Link (Admin/HR only) -->
    <?php if($role == 'Admin' || $role == 'HR'): ?>
        <a class="add-btn" href="/employees/create">Add Employee</a>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Role</th>
            <?php if($role == 'Admin' || $role == 'HR'): ?>
                <th>Actions</th>
            <?php endif; ?>
        </tr>

        <?php foreach($employees as $emp): ?>
        <tr>
            <td><?= $emp['id'] ?></td>
            <td><?= $emp['emp_name'] ?></td>
            <td><?= $emp['email'] ?></td>
            <td><?= $emp['department'] ?></td>
            <td><?= $emp['role'] ?></td>

            <?php if($role == 'Admin' || ($role == 'HR' && session()->get('department') == $emp['department'])): ?>
                <td>
                    <!-- Edit icon -->
                    <a href="/employees/edit/<?= $emp['id'] ?>" title="Edit">
                        <i class="fas fa-edit"></i>
                    </a>

                    &nbsp;

                    <!-- Delete icon only for Admin -->
                    <?php if($role == 'Admin'): ?>
                        <a href="/employees/delete/<?= $emp['id'] ?>" onclick="return confirm('Are you sure?')" title="Delete">
                            <i class="fas fa-trash-alt" style="color:red"></i>
                        </a>
                    <?php endif; ?>
                </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
    </table>

    <br><a href="/logout">Logout</a>
</body>
</html>
