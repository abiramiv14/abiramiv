<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<h3>Edit Course</h3>
<hr>

<?php if(session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <?php foreach(session()->getFlashdata('errors') as $error) echo $error.'<br>'; ?>
    </div>
<?php endif; ?>

<form id="editCourseForm" action="/admin/courses/update/<?= $course['id'] ?>" method="POST">

    <!-- Course Code (Readonly as per requirement) -->
    <div class="mb-3">
        <label>Course Code</label>
        <input type="text"
               id="course_code"
               class="form-control"
               value="<?= esc($course['course_code']) ?>"
               readonly
               maxlength="6">
    </div>

    <!-- Course Name -->
    <div class="mb-3">
        <label>Course Name</label>
        <input type="text"
               id="course_name"
               name="course_name"
               class="form-control"
               required
               maxlength="15"
               value="<?= old('course_name', $course['course_name']) ?>">
    </div>

    <!-- Department Dropdown -->
    <div class="mb-3">
        <label>Department</label>
        <select name="department" class="form-control" required>
            <option value="">-- Select Department --</option>
            <?php 
            $departments = ['ECE','EEE','MECH','CSE','CIVIL'];
            foreach($departments as $dept):
            ?>
                <option value="<?= $dept ?>"
                    <?= old('department', $course['department']) == $dept ? 'selected' : '' ?>>
                    <?= $dept ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- Semester Dropdown -->
    <div class="mb-3">
        <label>Semester</label>
        <select name="semester" class="form-control" required>
            <option value="">-- Select Semester --</option>
            <?php for($i = 1; $i <= 8; $i++): ?>
                <option value="<?= $i ?>"
                    <?= old('semester', $course['semester']) == $i ? 'selected' : '' ?>>
                    <?= $i ?>
                </option>
            <?php endfor; ?>
        </select>
    </div>

    <!-- Credits Dropdown -->
    <div class="mb-3">
        <label>Credits</label>
        <select name="credits" class="form-control" required>
            <option value="">-- Select Credits --</option>
            <?php for($i = 1; $i <= 10; $i++): ?>
                <option value="<?= $i ?>"
                    <?= old('credits', $course['credits']) == $i ? 'selected' : '' ?>>
                    <?= $i ?>
                </option>
            <?php endfor; ?>
        </select>
    </div>

    <!-- Status -->
    <div class="mb-3">
        <label>Status</label>
        <select name="status" class="form-control">
            <option value="Active" <?= $course['status'] == 'Active' ? 'selected' : '' ?>>
                Active
            </option>
            <option value="Inactive" <?= $course['status'] == 'Inactive' ? 'selected' : '' ?>>
                Inactive
            </option>
        </select>
    </div>

    <button class="btn btn-primary">Update</button>
    <a href="/admin/courses" class="btn btn-secondary">Cancel</a>
</form>

<!-- JS Validation and Focus -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Focus on course code field
    document.getElementById('course_code').focus();

    // Course Name: only letters, max 15 characters
    const courseNameInput = document.getElementById('course_name');
    courseNameInput.addEventListener('input', function() {
        // Remove numbers and special characters
        this.value = this.value.replace(/[^a-zA-Z ]/g,'');
        // Limit to 15 characters
        if(this.value.length > 15) this.value = this.value.slice(0,15);
    });
});
</script>

<?= $this->endSection() ?>
