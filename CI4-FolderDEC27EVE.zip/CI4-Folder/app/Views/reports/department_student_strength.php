<!DOCTYPE html>
<html>
<head>
    <title>Department-wise Student Strength</title>

    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

    <style>
        #chartdiv { width: 100%; height: 400px; }
    </style>
</head>
<body>

<h3 align="center">Department-wise Student Strength</h3>
<div id="chartdiv"></div>

<script>
am5.ready(function () {

    var root = am5.Root.new("chartdiv");
    root.setThemes([ am5themes_Animated.new(root) ]);

    var chart = root.container.children.push(
        am5xy.XYChart.new(root, {})
    );

    var xAxis = chart.xAxes.push(
        am5xy.CategoryAxis.new(root, {
            categoryField: "department",
            renderer: am5xy.AxisRendererX.new(root)
        })
    );

    var yAxis = chart.yAxes.push(
        am5xy.ValueAxis.new(root, {})
    );

    var series = chart.series.push(
        am5xy.ColumnSeries.new(root, {
            xAxis: xAxis,
            yAxis: yAxis,
            valueYField: "count",
            categoryXField: "department",
            tooltip: am5.Tooltip.new(root, {
                labelText: "{department}: {count}"
            })
        })
    );

    var data = <?= json_encode(
        array_map(fn($r) => [
            'department' => $r['department_name'],
            'count' => (int)$r['student_count']
        ], $chartData)
    ); ?>;

    xAxis.data.setAll(data);
    series.data.setAll(data);
});
</script>

</body>
</html>
