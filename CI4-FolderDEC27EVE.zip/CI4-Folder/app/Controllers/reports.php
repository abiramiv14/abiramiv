<?php

namespace App\Controllers;

use App\Models\DepartmentReportModel;

class Reports extends BaseController
{
    public function departmentStudentStrength()
    {
        $model = new DepartmentReportModel();

        $data['chartData'] = $model->getDepartmentWiseStudentCount();

        return view('reports/department_student_strength', $data);
    }
}
