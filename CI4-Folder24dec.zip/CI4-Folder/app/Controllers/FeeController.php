<?php
namespace App\Controllers;

use App\Models\FeePaymentModel;
use App\Models\StudentModel;

helper(['finance']);

class FeeController extends BaseController
{
    protected $feeModel;
    protected $studentModel;

    public function __construct()
    {
        $this->feeModel = new FeePaymentModel();
        $this->studentModel = new StudentModel();
    }

    // Admin: Show all payments
    public function index()
    {
        $data['payments'] = $this->feeModel->findAll();
        return view('fees/index', $data);
    }

    // Admin: Create payment form
    public function create()
    {
        $data['students'] = $this->studentModel->findAll();
        return view('fees/create', $data);
    }

    // Admin: Save payment
    public function store()
    {
        $student_id   = $this->request->getPost('student_id');
        $semester     = $this->request->getPost('semester');
        $fee_amount   = (float)$this->request->getPost('fee_amount');
        $paid_amount  = (float)$this->request->getPost('paid_amount');
        $payment_mode = $this->request->getPost('payment_mode');
        $payment_date = $this->request->getPost('payment_date');

        // Business rule
        if ($paid_amount > $fee_amount) {
            return redirect()->back()
                ->with('error', 'Paid amount cannot exceed total fee');
        }

        $receipt_no = generateReceiptNo($student_id);

        $this->feeModel->save([
            'student_id'   => $student_id,
            'semester'     => $semester,
            'fee_amount'   => $fee_amount,
            'paid_amount'  => $paid_amount,
            'payment_mode' => $payment_mode,
            'payment_date' => $payment_date,
            'receipt_no'   => $receipt_no
        ]);

        return redirect()->to('/admin/fees')
            ->with('success', 'Payment recorded successfully. Receipt No: ' . $receipt_no);
    }

    // Student View
    public function studentView()
    {
        $student_id = session('student_id');

        $payments = $this->feeModel
            ->where('student_id', $student_id)
            ->findAll();

        foreach ($payments as &$p) {
            $p['due'] = calculateDue($p['fee_amount'], $p['paid_amount']);
            $p['status'] = ($p['due'] == 0)
                ? 'Payment Successful'
                : 'Pending';
        }

        return view('fees/student_view', ['payments' => $payments]);
    }
}
